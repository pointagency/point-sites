(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 468,
	height: 60,
	fps: 18,
	color: "#FFFFFF",
	manifest: [
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/grap.png", id:"grap"}
	]
};



// symbols:



(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib.grap = function() {
	this.initialize(img.grap);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,153,47);


(lib.t3 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AL0BHIgNgEIAFgOQAEACAGABQAEACAGAAQAKAAAFgFQAEgEAAgIIAAgIQgEAEgFADQgFACgGAAQgPAAgJgKQgIgLAAgRIAAgCQAAgRAIgLQAJgMAPAAQAGAAAGADQAGADADAGIACgKIAOAAIAABNQAAAPgJAIQgKAJgRAAIgMgCgAL2gQQgFAIAAAKIAAACQAAALAFAGQADAHAKAAQAFAAAEgDQAEgCADgEIAAghQgDgEgEgDQgEgCgFAAQgJAAgEAHgAmEBIIgEgBIABgNIADAAIADAAQAEAAAEgDIAEgIIADgHIgdhMIATAAIARA1IABAAIARg1IATAAIggBZQgDAIgGAGQgFAGgLAAIgFgBgAjABHIAAhrIAPAAIABAJQAEgFAGgDQAFgDAHAAQAPAAAIAMQAJALAAARIAAACQAAARgJALQgIAKgPAAQgGAAgGgCQgFgDgEgEIAAAmgAiogVQgEACgDAFIAAAhQADAFAEACQAEACAGAAQAJAAAEgHQAEgGABgLIAAgCQgBgKgEgIQgEgHgJAAQgGAAgEACgAPjAfQgJgLAAgSIAAgCQAAgPAJgMQALgLAQAAQASAAAJALQAKAMAAAPIAAACQAAASgKALQgJALgSAAQgQAAgLgLgAPxgQQgFAHAAAJIAAACQAAALAFAIQAEAHAJAAQAKAAAFgHQAEgIAAgLIAAgCQAAgJgEgHQgFgIgKAAQgJAAgEAIgAGsAlQgFgGAAgNIAAgpIgNAAIAAgNIANAAIAAgUIASAAIAAAUIANAAIAAANIgNAAIAAApQAAAFACADQABACAFAAIACgBIADAAIABANIgFACIgHAAQgJAAgGgFgACdAiQgIgIAAgKIAAAAIAQAAQABAHAFADQAFADAGAAQAHAAADgDQAEgCABgFQAAgEgEgDQgEgCgJgCQgOgDgIgFQgHgEAAgKQAAgKAIgHQAJgHAOAAQAOAAAIAHQAJAHAAALIgBAAIgRAAQAAgFgDgDQgEgEgGAAQgHAAgDADQgEADAAAEQABAFADACQADACAJACQAPADAIAEQAHAGAAAJQAAALgJAHQgIAGgPAAQgPAAgKgIgAgKAfQgKgLAAgSIAAgCQAAgPAKgMQAKgLAPAAQARAAAJALQAKAMAAAPIAAACQAAASgKALQgJALgRAAQgPAAgKgLgAABgQQgDAHAAAJIAAACQAAALADAIQAFAHAJAAQAKAAAEgHQAFgIgBgLIAAgCQABgJgFgHQgEgIgKAAQgJAAgFAIgAhhAlQgFgGgBgNIAAgpIgMAAIAAgNIAMAAIAAgUIASAAIAAAUIAOAAIAAANIgOAAIAAApQAAAFACADQACACAEAAIACgBIAEAAIABANIgGACIgGAAQgJAAgGgFgAkPAfQgKgLAAgSIAAgCQAAgPAKgMQAKgLARAAQARAAAJALQAKAMAAAPIAAACQAAASgKALQgJALgRAAQgRAAgKgLgAkCgQQgFAHAAAJIAAACQAAALAFAIQAFAHAJAAQAKAAAEgHQAFgIgBgLIAAgCQABgJgFgHQgEgIgKAAQgJAAgFAIgAoJAkQgGgGAAgMQgBgLAKgGQAJgFAQAAIAOAAIAAgHQAAgGgDgEQgEgDgHAAQgGAAgEADQgDADgBAEIgRAAIAAAAQAAgJAJgIQAIgHAPAAQAOAAAIAHQAJAHAAANIAAAiIAAAJIADAJIgSAAIgCgGIgBgGQgDAGgHAEQgFADgIAAQgMAAgHgGgAn6AJQgDAEAAAFQAAAFACACQADADAFAAQAIAAAFgDQAFgEACgEIAAgMIgOAAQgIAAgFAEgAtVAfQgKgLAAgRIAAgDQAAgPAKgMQAJgLAPAAQARAAAIAKQAIAJAAARIAAAIIgxAAIAAABQABAJAEAGQAGAGAJAAQAGAAAGgCIAJgFIAHAMQgFAEgHADQgIACgJAAQgSAAgJgLgAtIgSQgEAFgBAIIABAAIAfAAIAAgCQAAgHgEgFQgEgFgIAAQgGAAgFAGgAutAgQgIgLAAgRIAAgCQAAgRAIgLQAJgMAOAAQAGAAAGADQAEACAFAFIAAgsIARAAIAABxIgPAAIgBgKQgEAGgFACQgGADgHAAQgOAAgJgKgAufgQQgEAIAAAKIAAACQAAALAEAGQAEAHAJAAQAGAAAEgDQAEgCADgFIAAggQgDgEgEgDQgEgCgGAAQgJAAgEAHgAwAAkQgGgGgBgMQAAgLAJgGQAKgFAQAAIAOAAIAAgHQAAgGgEgEQgDgDgHAAQgGAAgEADQgEADAAAEIgRAAIAAAAQAAgJAJgIQAJgHAOAAQAOAAAIAHQAJAHAAANIAAAiIAAAJIADAJIgSAAIgCgGIgBgGQgDAGgHAEQgFADgIAAQgMAAgHgGgAvxAJQgEAEAAAFQAAAFADACQADADAFAAQAIAAAFgDQAFgEACgEIAAgMIgOAAQgIAAgFAEgARxApIgQg0IgBgBIAAABIgQA0IgOAAIgXhNIASAAIANA1IAAAAIARg1IANAAIAQA2IABAAIAMg2IARAAIgVBNgAOPApIAAhpIASAAIAABaIAwAAIAAAPgANoApIAAgvQAAgJgEgEQgDgEgIAAQgFAAgEACQgEACgDAEIAAA4IgSAAIAAhxIASAAIAAAuQAEgGAFgDQAHgDAGAAQANAAAHAIQAHAIAAAQIAAAvgAK9ApIAAhNIASAAIAABNgAKUApIAAgsIgvAAIAAAsIgSAAIAAhpIASAAIAAAvIAvAAIAAgvIASAAIAABpgAIHApIAAgvQAAgJgEgEQgDgEgIAAQgFAAgEACQgEACgDAEIAAA4IgSAAIAAhxIASAAIAAAuQAEgGAGgDQAFgDAHAAQANAAAHAIQAHAIAAAQIAAAvgAF8ApIAAhNIASAAIAABNgAFKApIgQg0IAAgBIAAABIgRA0IgPAAIgVhNIARAAIAMA1IABAAIARg1IAMAAIARA2IAAAAIANg2IARAAIgWBNgAB0ApIAAgwQAAgJgEgEQgEgDgHAAQgFAAgEACQgFACgDAEIAAA4IgSAAIAAhNIARAAIABALQAEgGAGgEQAGgDAHAAQAMAAAIAIQAGAHABAQIAAAwgAg2ApIAAhNIASAAIAABNgAm7ApIAAhNIAQAAIACALQADgGAEgEQAFgDAGAAIAEAAIACABIgCARIgIgBQgFAAgDACQgEADgCAEIAAA1gAoxApIAAgwQABgJgEgEQgEgDgHAAQgGAAgDACQgFACgCAEIAAA4IgSAAIAAhNIAQAAIABALQAEgGAGgEQAGgDAHAAQANAAAGAIQAIAHgBAQIAAAwgAqHApIAAhNIASAAIAABNgArmApIAAhpIAjAAQASAAAKAHQAKAIAAAOQAAAHgEAGQgEAGgIADQAKACAFAHQAGAFAAAJQgBAPgJAIQgKAIgRAAgArUAaIAXAAQAIAAAFgEQAFgEABgIQAAgIgFgDQgEgFgIAAIgZAAgArUgTIATAAQAJAAAFgEQAEgEAAgHQAAgIgEgEQgGgEgKAAIgRAAgAw3ApIAAhNIAQAAIACALQADgGAEgEQAFgDAGAAIADAAIACABIgCARIgIgBQgEAAgEACQgEADgBAEIAAA1gAx1ApIAAhbIggAAIAAgOIBSAAIAAAOIggAAIAABbgAK9g4IAAgQIASAAIAAAQgAF8g4IAAgQIASAAIAAAQgAg2g4IAAgQIASAAIAAAQgAqHg4IAAgQIASAAIAAAQg");
	this.shape.setTransform(26.7,14.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-92.5,1,238.6,23.8);


(lib.t2 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmKCjIAAgOQgNgBgJgIQgIgJAAgPIAAgBIARAAQAAALAFAEQAGAFAHAAQAIAAAFgEQAEgEAAgHQAAgGgEgEQgEgFgJgDQgQgFgIgIQgHgHAAgNQAAgMAHgIQAHgIANgBIAAgQIAMAAIAAAQQAMACAHAJQAIAJAAAOIgSAAQAAgJgEgFQgEgGgIAAQgHAAgEAEQgEAEAAAHQAAAGAEAEQAEAEAKAEQAQAFAHAIQAIAHAAANQAAAMgIAIQgHAIgOABIAAAOgAGeCKQgKgLAAgSIAAgCQAAgRAKgMQAJgLARAAQAPAAAJAIQAIAJAAAMIAAABIgQAAQAAgHgEgEQgFgFgHAAQgKAAgEAIQgEAHAAALIAAACQAAAMAEAHQAEAHAKAAQAHAAAEgEQAFgEAAgFIAQAAIAAAAQAAALgJAIQgJAIgOAAQgRAAgJgLgAFJCPQgGgGAAgMQAAgLAJgGQAJgHAQAAIAOAAIAAgHQAAgGgDgEQgEgDgHAAQgGAAgEADQgDADAAAEIgRAAIAAAAQgBgJAJgIQAJgHAOAAQAOAAAJAHQAIAHAAANIAAAkIABAJIACAJIgSAAIgCgGIgBgGQgDAGgGAEQgGADgIAAQgMAAgHgGgAFZB0QgEAEAAAFQAAAFADACQACADAGAAQAHAAAFgDQAFgEACgEIAAgMIgOAAQgIAAgEAEgAELCSQgGgDgDgGIgCALIgPAAIAAhzIASAAIAAAtQAEgGAFgCQAFgDAHAAQAPAAAIAMQAIALAAATIAAACQAAARgIALQgIAKgPAAQgIAAgFgDgAEJBUQgEADgCAFIAAAhQACAFAEACQAEADAGAAQAKAAAEgHQAEgGAAgLIAAgCQAAgMgEgIQgFgHgJAAQgGAAgEACgAAjCNQgJgIABgKIAAAAIAQAAQABAHAEADQAFADAHAAQAHAAADgDQAEgCAAgFQAAgEgDgDQgEgCgJgCQgPgDgHgGQgHgFAAgKQAAgKAIgHQAJgHANAAQAPAAAIAHQAJAHAAALIgBAAIgRAAQAAgFgDgDQgEgEgHAAQgGAAgDADQgEADAAAEQAAAFADACQAEACAJACQAPADAHAGQAIAGAAAJQAAALgJAHQgJAGgOAAQgQAAgJgIgAgvCPQgGgGAAgMQAAgLAJgGQAJgHAQAAIAOAAIAAgHQAAgGgDgEQgEgDgHAAQgGAAgEADQgDADAAAEIgRAAIAAAAQgBgJAJgIQAJgHAOAAQAOAAAHAHQAIAHAAANIAAAkIABAJIACAJIgQAAIgCgGIgBgGQgDAGgGAEQgGADgIAAQgMAAgHgGgAgfB0QgEAEAAAFQAAAFADACQACADAGAAQAHAAAFgDQAFgEACgEIAAgMIgOAAQgIAAgEAEgAh6CKQgKgLAAgSIAAgCQAAgRAKgMQAJgLARAAQAPAAAJAIQAIAJAAAMIAAABIgQAAQAAgHgEgEQgFgFgHAAQgKAAgEAIQgEAHAAALIAAACQAAAMAEAHQAEAHAKAAQAHAAAEgEQAFgEAAgFIAQAAIAAAAQAAALgJAIQgJAIgOAAQgRAAgJgLgAj0CKQgJgLAAgUIAAgZQAAgUAJgLQAKgLAQAAQAQAAAJALQAKALAAAUIAAAZQAAAUgKALQgJALgQAAQgQAAgKgLgAjnA8QgEAGAAAOIAAAdQAAANAEAHQAFAGAIAAQAIAAAFgGQAEgHAAgNIAAgdQAAgOgEgGQgFgGgIAAQgJAAgEAGgAlHCOQgKgIABgOIAAgBIAQAAQAAAHAFAFQAEAEAIAAQAIAAAEgGQAFgGAAgJQAAgKgFgGQgEgGgIAAQgIAAgDACQgEADgCAEIgPgBIAGg7IA5AAIAAAPIgqAAIgDAbIAHgEQAEgBAGAAQAPAAAIAJQAJAKAAARQAAAPgJAKQgJAKgRAAQgOAAgKgHgAoaCPQgHgGAAgMQAAgLAJgGQAJgHARAAIAOAAIAAgHQAAgGgEgEQgEgDgGAAQgGAAgEADQgEADAAAEIgRAAIAAAAQAAgJAJgIQAIgHAPAAQAOAAAIAHQAJAHAAANIAAAkIAAAJIACAJIgSAAIgBgGIgBgGQgEAGgGAEQgGADgHAAQgMAAgHgGgAoLB0QgEAEAAAFQAAAFADACQADADAFAAQAHAAAGgDQAFgEACgEIAAgMIgOAAQgIAAgFAEgAIXCUIgXgjIgIAAIAAAjIgSAAIAAhzIASAAIAABCIAHAAIAUgeIAVAAIgaAkIAeArgACcCUIAAgxQAAgJgDgEQgEgEgIAAQgFAAgEACQgEACgDAEIAAA6IgSAAIAAhzIASAAIAAAuQAEgGAGgDQAGgDAGAAQANAAAHAIQAHAIAAAQIAAAxgAC8BuIAAgPIAnAAIAAAPgAFpgQIgEgBIABgOIADAAIADAAQAFAAADgDIAEgIIADgHIgdhOIAUAAIARA3IAAAAIARg3IAUAAIghBbQgDAJgGAFQgFAGgLAAIgFAAgAA8gRIgNgFIAEgOQAFADAFABQAFABAGAAQAKAAAEgEQAFgEAAgJIAAgIQgEAFgFACQgFADgHAAQgPAAgIgLQgIgKAAgSIAAgBQAAgTAIgMQAIgLAPAAQAHAAAGADQAFADAEAFIACgKIAOAAIAABPQAAAQgJAIQgKAIgRAAIgMgBgAA9hqQgEAHAAANIAAABQAAALAEAHQAEAGAKAAQAFAAAEgCQAEgCADgFIAAgjQgDgEgEgCQgEgDgFAAQgJAAgFAIgAIOg2QgHgIAAgSIAAgvIASAAIAAAwQAAAKADAEQAEAEAHAAQAGAAAEgCQAFgCACgFIAAg5IASAAIAABPIgQAAIgBgLQgEAGgFADQgGAEgIAAQgMAAgIgIgAG5g5QgKgMAAgSIAAgBQAAgSAKgLQAKgLARAAQARAAAJALQAKALAAASIAAABQAAASgKAMQgJALgRAAQgRAAgKgLgAHGhrQgFAIAAALIAAABQAAAMAFAHQAEAIAKAAQAJAAAFgIQAEgHAAgMIAAgBQAAgLgEgIQgFgHgJAAQgKAAgEAHgAD5g5QgKgLAAgSIAAgCQAAgSAKgLQAKgMAPABQAQAAAJAJQAIAKAAAQIAAALIgxAAIAAAAQAAAKAFAGQAFAGAJAAQAHAAAGgCIAJgFIAGALQgEAEgIADQgHADgKAAQgRAAgKgLgAEHhtQgEAFgBAIIAAABIAgAAIAAgCQAAgIgEgEQgEgFgIAAQgHAAgEAFgAitg5QgKgLAAgSIAAgCQAAgSAKgLQAKgMAPABQAQAAAIAJQAJAKAAAQIAAALIgyAAIAAAAQABAKAFAGQAFAGAJAAQAHAAAFgCIAKgFIAGALQgFAEgHADQgIADgJAAQgRAAgKgLgAifhtQgFAFgBAIIABABIAfAAIAAgCQAAgIgEgEQgEgFgHAAQgHAAgEAFgAmag5QgIgKAAgSIAAgBQAAgTAIgMQAIgLAPAAQAGAAAFACQAFADAEAFIAAgsIASAAIAAByIgPAAIgCgKQgEAGgFADQgFADgHAAQgPAAgIgLgAmMhqQgEAHAAANIAAABQAAALAEAHQAEAGAJAAQAGAAAEgCQAEgDACgEIAAgjQgCgEgEgCQgEgDgGAAQgJAAgEAIgApCg1QgHgGAAgLQAAgMAJgGQAJgGARAAIAOAAIAAgHQAAgHgEgDQgEgEgGAAQgGAAgEADQgEADAAAFIgRAAIAAgBQAAgJAJgHQAIgHAPAAQAOAAAIAHQAJAHAAANIAAAjIAAAJIACAJIgSAAIgBgGIgBgFQgEAFgGAEQgGAEgHAAQgMAAgHgHgAozhPQgEADAAAGQAAAEADADQADADAFAAQAHAAAGgEQAFgDACgFIAAgLIgOAAQgIAAgFAEgAC7gwIgchPIASAAIARA0IABAHIAAAAIACgHIAQg0IASAAIgcBPgACAgwIAAhPIASAAIAABPgAgfgwIAAhyIASAAIAABygAhGgwIAAhyIASAAIAABygAjlgwIgRg2IAAgBIAAABIgRA2IgOAAIgWhPIARAAIANA4IAAAAIARg4IANAAIAQA4IABAAIAMg4IARAAIgVBPgAnDgwIAAgxQAAgJgEgEQgEgEgHAAQgFAAgEACQgFADgCAEIAAA5IgSAAIAAhPIAQAAIABALQAEgGAGgDQAGgDAHAAQANAAAHAHQAHAIAAAPIAAAygAhqh6IAFgaIAAgOIAQAAIAAAOIgMAagACAiSIAAgQIASAAIAAAQg");
	this.shape.setTransform(-0.2,32.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-63,10,126.1,43.5);


(lib.t1 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjZBNIAAhsIAPAAIACAKQADgGAGgDQAFgCAHAAQAPAAAIALQAJAMAAARIAAABQAAASgJAKQgIALgPAAQgGAAgGgDQgEgCgFgFIAAAngAjBgQQgEADgDAEIAAAiQADAEAEACQAEADAGAAQAIAAAFgHQAEgHABgLIAAgBQgBgKgEgIQgFgIgIAAQgGAAgEACgAC4A+IAAgPQgNgBgJgIQgJgIAAgQIABAAIARAAQAAAKAFAFQAFAEAIAAQAIAAAFgEQAEgEAAgHQAAgGgEgEQgEgEgKgDQgPgEgIgHQgHgIAAgMQAAgMAHgIQAHgIANgCIAAgQIALAAIAAARQANABAHAJQAHAJAAAPIgSAAQAAgKgDgFQgFgFgHAAQgIAAgDAEQgEAEAAAGQAAAHAEAEQAEAEAKADQAPAGAIAHQAIAGAAAMQAAANgIAHQgIAIgNABIAAAPgAFNAlQgKgLAAgVIAAgWQAAgVAKgLQAKgLAPAAQAQAAAKALQAJALAAAVIAAAWQAAAVgJALQgJALgRAAQgPAAgKgLgAFagnQgFAGAAANIAAAcQAAANAFAGQAFAHAHAAQAJAAAFgHQAEgGAAgNIAAgcQAAgNgEgGQgFgHgJAAQgIAAgEAHgAD6AoQgKgIABgOIAAAAIARgBQAAAIAEAEQAFAFAHAAQAJAAADgGQAFgGAAgKQAAgJgFgEQgEgGgIAAQgIAAgDACQgDACgCADIgQAAIAHg6IA4AAIAAAPIgpAAIgEAbIAHgEQAEgCAGAAQAPAAAJAKQAIAJAAAPQAAAQgJAKQgJAKgRAAQgOAAgKgIgABNAqQgGgGAAgMIAAgqIgMAAIAAgNIAMAAIAAgTIARAAIAAATIAPAAIAAANIgPAAIAAAqQAAAFACACQADACADAAIAGgBIACANIgGACIgGABQgKAAgFgGgAgrAoQgIgIAAgKIAAgBIAQAAQABAHAFADQAEADAHAAQAHAAADgCQAFgDAAgEQgBgEgDgDQgDgDgKgCQgPgDgGgFQgIgFAAgIQAAgKAJgHQAIgHANAAQAPAAAHAHQAIAHAAAKIAAABIgPAAQAAgFgEgEQgEgDgHAAQgGAAgDADQgEADABAEQAAAEACACQAEADAJAAQAQADAFAGQAHAFAAAKQAAAKgJAHQgGAHgPAAQgPAAgKgIgAh/AlQgJgMAAgSIAAgBQAAgQAJgLQALgLAQAAQARAAAKALQAKALAAAQIAAABQAAASgKAMQgKALgRAAQgQAAgLgLgAhxgLQgFAIAAAJIAAABQAAAMAFAHQAEAIAJAAQAKAAAFgIQAEgHAAgMIAAgBQAAgJgEgIQgFgHgKAAQgJAAgEAHgAkhAlQgKgLAAgSIAAgCQAAgQAKgLQAKgMAPABQAQAAAJAJQAIAKAAAOIAAALIgyAAIAAAAQABAKAFAGQAFAGAJAAQAHAAAGgCIAJgFIAGALQgFAEgHADQgIADgJAAQgRAAgKgLgAkTgNQgEAFgCAIIABAAIAgAAIAAgBQgBgIgEgEQgDgFgIAAQgHAAgEAFgAAdAuIAAhNIASAAIAABNgAmIAuIAAhoIAiAAQAUAAANAMQANANAAAUIAAAOQAAAUgNANQgNAMgUAAgAl2AgIAPAAQAOAAAIgJQAHgIAAgOIAAgOQAAgOgHgIQgIgJgOAAIgPAAgAAdgyIAAgQIASAAIAAAQg");
	this.shape.setTransform(-1,17);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-43.7,4,84.9,23.8);


(lib.note_10 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AATA+QgFgDgFgHQgDgGAAgJIAAhKQAAgIADgHQAFgGAFgDQAHgDAIAAQAHAAAGADQAGADAEAGQAEAHAAAIIAABKQAAAJgEAGQgEAHgGADQgGADgHAAQgIAAgHgDgAAbgrQgDACABAEIAABKQgBAEADADQADADAEAAQADAAADgDQACgDABgEIAAhKQgBgEgCgCQgDgDgDAAQgEAAgDADgAguA+QgGgDgEgHQgDgGgBgJIAAgFIASAAIAAAFQABAEADADQACADAEAAQAEAAACgDQADgCAAgFIAAgeQAAgEgDgDQgCgBgEAAQgDAAgCABIgDACIgCACIgPAAIAAhDIA0AAIAAARIglAAIAAAjIAHgEIAJgCQAKAAAGAGQAFAGAAAJIAAAhQAAAJgDAGQgEAHgGADQgHADgHAAQgIAAgGgDg");
	this.shape.setTransform(52.5,20.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DB5A35").s().p("AiCCDQg2g3gBhMQABhMA2g2QA3g3BLAAQBMAAA3A3QA2A2AABMQAABNg2A2Qg3A3hMAAQhLAAg3g3g");
	this.shape_1.setTransform(52.6,20.5,0.66,0.66);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EDECEC").s().p("AoaD+QgKgYgUgQQgUgRgagFIAAl/QAagFAUgRQAUgQAKgYIQ1AAQAJAYAVARQATASAaAFIAAF9QgYAFgVARQgUAQgKAYg");
	this.shape_2.setTransform(52.6,20.5,0.66,0.66);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DB5A35").s().p("AqdE1IAApqIU7AAIAAJqg");
	this.shape_3.setTransform(52.7,20.5,0.66,0.66);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(8.5,0,88.5,41);


(lib.m2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AAUA+QgHgDgDgHQgEgGgBgJIAAhKQABgIAEgHQADgGAHgDQAGgDAHAAQAIAAAGADQAHADADAGQAEAHAAAIIAABKQAAAJgEAGQgDAHgHADQgGADgIAAQgHAAgGgDgAAbgrQgCACgBAEIAABKQABAEACADQACADAEAAQAFAAACgDQADgDgBgEIAAhKQABgEgDgCQgCgDgFAAQgEAAgCADgAguA+QgGgDgEgHQgEgGAAgJIAAgFIATAAIAAAFQAAAEACADQADADAEAAQAFAAABgDQADgCAAgFIAAgeQAAgEgDgDQgCgBgEAAQgDAAgCABIgDACIgBACIgQAAIAAhDIA1AAIAAARIglAAIAAAjIAGgEIAJgCQAKAAAFAGQAHAGAAAJIAAAhQAAAJgFAGQgDAHgHADQgFADgIAAQgHAAgHgDg");
	this.shape.setTransform(44.2,20.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DB5A35").s().p("AiCCDQg3g2ABhNQgBhMA3g2QA3g3BLAAQBNAAA2A3QA3A2gBBMQABBNg3A2Qg2A3hNAAQhLAAg3g3g");
	this.shape_1.setTransform(44.2,20.5,0.66,0.66);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EDECEC").s().p("AoaD+QgKgYgUgQQgUgRgagFIAAl/QAagFAUgRQAUgQAKgYIQ0AAQAKAYAUARQAVASAaAFIAAF9QgaAFgUARQgUAQgKAYg");
	this.shape_2.setTransform(44.2,20.5,0.66,0.66);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DB5A35").s().p("AqdE1IAAppIU7AAIAAJpg");
	this.shape_3.setTransform(44.2,20.5,0.66,0.66);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,88.5,41);


(lib.logo_mc = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2E").s().p("AAQAtQgaAAgGgCQgLgCgFgGQgFgFgBgKQgBgEAAgPQAAgPABgEQACgLAGgGQAGgGATgBIAagBQAeAAAIACQANADADAIQADAGAAALIgbAAQAAgDgCgEQgDgDgHAAIgnAAIgCABQgGACgBADQgCAEAAAPQAAAMACACQABAGAHABIAQABIAZgBQAKAAABgGIAAgGIgjAAIAAgPIA+AAIAAAKQAAATgDAFQgCAHgFADQgGAEgLABgACxAsIAAgiIg/AAIAAAiIgcAAIAAhWIAcAAIAAAgIA/AAIAAggIAcAAIAABWgAhLAsIAAhWIAcAAIAABWgAhxAsIAAgiIg/AAIAAAiIgcAAIAAhWIAcAAIAAAgIA/AAIAAggIAcAAIAABWg");
	this.shape.setTransform(23.9,12.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AhGArQgLgCgFgFQgEgEgCgLQgCgFAAgQIABgPIACgJQACgJAHgEQAHgFARgBIAZgBQAgAAAHABQALADAEAGQAGAGABAJIABATQAAAUgDAIQgEAHgGAEQgHADgDABIgPABIgXABQgfAAgHgCgAg1gVQgIABgCAFQgCADAAAMQAAAMACAEQACAFAIABQAGABAPAAQAUAAAFgBQAGgCABgDQABgEAAgGIAAgHQAAgMgBgEQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAQgDgCgFAAIgVAAQgTAAgDABgAjOAsIAAhXIAcAAIAABBIBLAAIAAAWgACGArIgQg1IgSA1IglAAIgihWIAfAAIAVA7IATg7IAjAAIATA7IAWg7IAeAAIgiBWg");
	this.shape_1.setTransform(73.4,17.3);

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E1E0DF").s().p("AAABLIjuAqIAAi/IDugqIDuAqIAAC/g");
	this.shape_2.setTransform(23.9,12.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6B6B6A").s().p("AjtBLIAAi/IDtAqIDvgqIAAC/IjvAqg");
	this.shape_3.setTransform(73.1,17.2);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,1,97,28);


(lib.laptop = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C1C1C0").s().p("AhbAHQgEAAAAgFIAAgIIC/AAIAAAIQAAAFgEAAg");
	this.shape.setTransform(0,109.2,2.478,2.53);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D0D0CF").s().p("AnHAOIAAgbIOOAAIAAAbg");
	this.shape_1.setTransform(0,111,2.478,2.53);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C1C1C0").s().p("AmhAGIgmgLIOOAAIgmALg");
	this.shape_2.setTransform(0,116.4,2.478,2.53);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E4E2E2").s().p("AiqinQAAgMAJgIQAJgJALAAIE4AAIgbAwIkIAAIAAEkIgyA1g");
	this.shape_3.setTransform(-49.9,50,2.478,2.53);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#303238").s().p("AlBCkIAAlHIKEAAIAAFHg");
	this.shape_4.setTransform(0,53.7,2.478,2.53);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C1C1C0").s().p("AgFAAQAAgBABgDQACgCACAAQAGAAAAAGQAAAGgGABQgGgBABgGg");
	this.shape_5.setTransform(0,5.4,2.478,2.53);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E0DDDD").s().p("Al0DcIAAmaQABgMAIgIQAJgJAMAAIKtAAQAMAAAJAJQAIAIAAAMIAAGag");
	this.shape_6.setTransform(0,55.8,2.478,2.53);

	this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-113,0,226,118.2);


(lib.lapshad = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.102)").s().p("A+O1KIAhgmIETgWIYfhOIBdszIBEijIYpYaIEAdtIh5XOg");
	this.shape.setTransform(193.6,247.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,387.2,495.1);


(lib.hand2 = function() {
	this.initialize();

	// flash0.ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#504F52").s().p("AtOlmIDhmuIVEJhIB4PIg");
	this.shape.setTransform(150.3,68.6,0.682,0.682);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#919396").s().p("AigCoIDrmRIBWAnIjgGsg");
	this.shape_1.setTransform(96.9,28.2,0.682,0.682);

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B1B1B1").s().p("AAYA4QguABgfgTQgPgQAAgWQAAgbAVgPQAYgSAuADQAbABAKAQQAJANAAAbQAAAvgaALg");
	this.shape_2.setTransform(9,26.9,0.66,0.66);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#656566").s().p("AElAFIlFB1Il3gsIk9gsQgwACgegTQgggSgDgmQgDgiAVgXQAagcA3gHQAhgDDGABQC9ABADgBQEah1E8h1IIrExIhuGug");
	this.shape_3.setTransform(58.5,28.3,0.66,0.66);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#656566").s().p("AiGCfIk9gsQgwABgfgTQgggUgDglQgCgiAVgVQAZgdA4gGQAggEDGACQC9ABADgCQDahbDagmQBsgTBBAAIAAEeIlHB1g");
	this.shape_4.setTransform(40.5,23,0.66,0.66);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#575858").s().p("AjgA2QATgVAUgIIEihwQAUgIAeAAQAegBAVAHIAhAiQAaAoghAfQgiAijiAbIjdAUQAGgWATgVg");
	this.shape_5.setTransform(22.2,18.3,0.66,0.66);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#656566").s().p("ApMCwIA+jFQAGgWATgVQATgUAVgJIEjhxQAVgJAeAAQAdgBAWAIIKHA1IAKF0g");
	this.shape_6.setTransform(38.9,14.3,0.66,0.66);

	this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,208.1,122.5);


(lib.hand = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B1B1B1").s().p("Ag4A6QgOgMADgrQADguAJgLQAPgSAxAHQAdAFAOAMQATARgCAfQgCAegTATQgPAPgUACIgZACQghAAgLgKg");
	this.shape.setTransform(140.6,72.4,0.66,0.66);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#656566").s().p("AhMB4Qg7gCg/gGIBAjnQAZgBAXABQCBAEBFAVQA2ARATAfQALARADAiQADAngfAcQgvAohyAHQgTABgdAAIgmAAg");
	this.shape_1.setTransform(133.5,71.7,0.66,0.66);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEFEFE").s().p("AizDVQA8iuBjiOQA/heBDhAIAAgBIBGAjQgrAag3BLQhsCUg3Dxg");
	this.shape_2.setTransform(49.6,50.7,0.66,0.66);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#303238").s().p("AqRjdICtitIIvAQQH1EYBSAoIjxHFg");
	this.shape_3.setTransform(-7.5,38);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#656566").s().p("AiuFyQiOgciLhlQiBhdjuhuQgXgLAJhIQAIhFAdhVQAfhZAjgyQApg5AeATQB7BKBWAiQBcAkBtAPQBPAKDvghQDyghA5AHQAVACAMAHQARALA/AwIB7BeQBIA1AVASQAuAnAMAgQANAlgNA7QA2ARAUAfQALARADAkQADAnggAcQguAohzAHQghACg3gBQg6gChAgGIh1gJQgqABiEAbQhqAVhZAAQhEAAg8gMgAEoBdQAuALApAGQAPACAlAAIBFgDQgKgPgOgNIgLgJQgjAKhjgKQgwgFg7gJIgxgJQAZAXBcAVg");
	this.shape_4.setTransform(91.2,56.6,0.66,0.66);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#575858").s().p("AjIEAQgpgCgNguQgEgPADgSQgoAKgWACQglACgWgPQgTgNgFgUIgLgTIgjhJIB/ibIEaiWIAvAJQA7AJAwAFQBjAKAjgKIALAxQAOA1AKAPIBYAdIBIBUQABA0gBADIgOBGQgtBFglAjQgxAugzgjQgyghANg8QADgNAGgOIgFgjQADAcgGAFIABAAIguAXQgJAFgfAXQgYARgTAGQgZAIg2AGQgzAGgZAIIhBAZQgmAPgZAAIgDgBg");
	this.shape_5.setTransform(105.6,71.5,0.66,0.66);

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-73.3,-1.6,220.1,90.1);


(lib.grap_1 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.grap();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,153,47);


(lib.buzz = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape.setTransform(89.7,160,0.384,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_1.setTransform(89.7,158,0.384,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_2.setTransform(89.7,156,0.384,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_3.setTransform(89.7,154,0.384,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_4.setTransform(89.7,152,0.384,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_5.setTransform(89.7,150,0.384,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_6.setTransform(89.7,148,0.384,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_7.setTransform(89.7,146,0.384,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_8.setTransform(89.7,144,0.384,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_9.setTransform(89.7,142,0.384,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_10.setTransform(89.7,140,0.384,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_11.setTransform(89.7,138,0.384,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_12.setTransform(89.7,136,0.384,1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_13.setTransform(89.7,134,0.384,1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_14.setTransform(89.7,132,0.384,1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_15.setTransform(89.7,130,0.384,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_16.setTransform(89.7,128,0.384,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_17.setTransform(89.7,126,0.384,1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_18.setTransform(89.7,124,0.384,1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_19.setTransform(89.7,122,0.384,1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_20.setTransform(89.7,120,0.384,1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_21.setTransform(89.7,118,0.384,1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_22.setTransform(89.7,116,0.384,1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_23.setTransform(89.7,114,0.384,1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_24.setTransform(89.7,112,0.384,1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_25.setTransform(89.7,110,0.384,1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_26.setTransform(89.7,108,0.384,1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_27.setTransform(89.7,106,0.384,1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_28.setTransform(89.7,104,0.384,1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_29.setTransform(89.7,102,0.384,1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_30.setTransform(89.7,100,0.384,1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_31.setTransform(89.7,98,0.384,1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_32.setTransform(89.7,96,0.384,1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_33.setTransform(89.7,94,0.384,1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_34.setTransform(89.7,92,0.384,1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_35.setTransform(89.7,90,0.384,1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_36.setTransform(89.7,88,0.384,1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_37.setTransform(89.7,86,0.384,1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_38.setTransform(89.7,84,0.384,1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_39.setTransform(89.7,82,0.384,1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_40.setTransform(89.7,80,0.384,1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_41.setTransform(89.7,78,0.384,1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_42.setTransform(89.7,76,0.384,1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_43.setTransform(89.7,74,0.384,1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_44.setTransform(89.7,72,0.384,1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_45.setTransform(89.7,70,0.384,1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_46.setTransform(89.7,68,0.384,1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_47.setTransform(89.7,66,0.384,1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_48.setTransform(89.7,64,0.384,1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_49.setTransform(89.7,62,0.384,1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_50.setTransform(89.7,60,0.384,1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_51.setTransform(89.7,58,0.384,1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_52.setTransform(89.7,56,0.384,1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_53.setTransform(89.7,54,0.384,1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_54.setTransform(89.7,52,0.384,1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_55.setTransform(89.7,50,0.384,1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_56.setTransform(89.7,48,0.384,1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_57.setTransform(89.7,46,0.384,1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_58.setTransform(89.7,44,0.384,1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_59.setTransform(89.7,42,0.384,1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_60.setTransform(89.7,40,0.384,1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_61.setTransform(89.7,38,0.384,1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_62.setTransform(89.7,36,0.384,1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_63.setTransform(89.7,34,0.384,1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_64.setTransform(89.7,32,0.384,1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_65.setTransform(89.7,30,0.384,1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_66.setTransform(89.7,28,0.384,1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_67.setTransform(89.7,26,0.384,1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_68.setTransform(89.7,24,0.384,1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_69.setTransform(89.7,22,0.384,1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_70.setTransform(89.7,20,0.384,1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_71.setTransform(89.7,18,0.384,1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_72.setTransform(89.7,16,0.384,1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_73.setTransform(89.7,14,0.384,1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_74.setTransform(89.7,12,0.384,1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_75.setTransform(89.7,10,0.384,1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_76.setTransform(89.7,8,0.384,1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_77.setTransform(89.7,6,0.384,1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_78.setTransform(89.7,4,0.384,1);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_79.setTransform(89.7,2,0.384,1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("rgba(255,255,255,0.498)").p("EgkfAAAMBI/AAA");
	this.shape_80.setTransform(89.7,0,0.384,1);

	this.addChild(this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-1,181.4,162);


(lib.btnbg2 = function() {
	this.initialize();

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlUClIAAlJIKpAAIAAFJg");
	this.shape.setTransform(34.2,16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FCCD2A").s().p("AlUAPIAAgcIKpAAIAAAcg");
	this.shape_1.setTransform(34.2,34.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,68.4,36);


(lib.bg2_1 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg2();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib.bgo = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("EgkjAEsIAApXMBJHAAAIAAJXg");
	this.shape.setTransform(234,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib._50 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#747577").s().p("AgGA+IAAg5IgzAAIAAgLIAzAAIAAg3IAMAAIAAA3IA0AAIAAALIg0AAIAAA5g");
	this.shape.setTransform(8.8,25.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FCCD2A").s().p("AiZCwIAAghQgRgDgOgJQgOgJgHgOQgIgOAAgTIAAgQIApAAIAAAPQAAAJAEAIQAFAIAKACIAAhbIgNgGQgSgFgKgLQgJgJgEgOQgEgOAAgSQAAgVAHgQQAGgRANgLQANgLATgCIAAgeIAVAAIAAAeQASADANAJQANAKAIANQAHAOAAAQIAAAUIgpAAIAAgKQAAgMgEgKQgEgJgKgEIAABRIAQAHQASAHAJAKQAKAIADAPQADAPAAAVQAAAXgGASQgFASgNALQgNALgWADIAAAhgAiEBlQAMgDADgKQAEgMgBgRQAAgNgBgIQgBgIgFgEQgEgEgHgDgAimhaQgEAKAAAMQAAAOADAJQADAHALAFIAAhIQgKAFgDAKgAB7CHQgOgHgIgOQgIgOgBgTIAAilQABgTAIgNQAIgOAOgIQAOgHAQAAQARAAANAHQAOAIAIAOQAJANAAATIAAClQAAATgJAOQgIAOgOAHQgNAIgRAAQgQAAgOgIgACLhiQgGAFAAAJIAAClQAAAJAGAFQAFAHAJgBQAJABAFgHQAGgFAAgJIAAilQAAgJgGgFQgFgGgJgBQgJABgFAGgAgYCHQgOgHgIgOQgIgOgBgTIAAgMIApAAIAAALQAAAKAGAGQAGAFAHAAQAJAAAFgFQAFgFAAgLIAAhDQAAgIgFgFQgGgEgIgBQgFABgEACIgHAEIgDAHIgkAAIAAiYIBzAAIAAAmIhPAAIAABOQAGgGAIgEQAHgDALgBQAVAAANANQANANAAAXIAABJQAAATgJAOQgIAOgOAHQgNAIgRAAQgOAAgOgIg");
	this.shape_1.setTransform(45.9,25.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,70.8,51.5);


(lib._10 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiYCwIAAghQgNgCgLgFQgLgHgIgJQgIgIgFgMQgEgMAAgNIAAgQIAoAAIAAAPQAAAKAFAHQAFAJAKABIAAhbIgOgGQgNgEgJgGQgIgIgFgJQgFgJgCgLQgCgKAAgOQAAgPADgOQAEgNAHgLQAIgKAKgHQALgGAPgCIAAgeIAUAAIAAAeQANACAMAFQALAGAIAKQAHAJAEAKQAFALAAALIAAAVIgpAAIAAgKQAAgNgFgJQgEgJgKgEIAABRIARAHQANAFAJAHQAIAFAFAKQAEAJACAMIACAcQAAARgDAPQgEAOgGALQgIAMgLAGQgMAHgQACIAAAhgAiEBlQAMgCAEgLQADgJAAgUQAAgVgEgHQgDgIgMgEgAimhaQgDAIAAAOQAAAQACAHQAEAHALAFIAAhIQgKAEgEALgACBCKQgLgEgIgIQgJgIgEgLQgFgMAAgOIAAilQAAgOAFgMQAEgKAJgJQAIgHALgFQAMgEAMAAQAMAAALAEQALAFAIAHQAJAJAFAKQAEAMAAAOIAAClQAAAOgEAMQgFALgJAIQgIAIgLAEQgLAFgMAAQgMAAgMgFgACKhiQgFAFAAAJIAAClQAAAJAFAFQAGAHAJgBQAIABAGgHQAGgFAAgJIAAilQAAgJgGgFQgGgHgIAAQgJAAgGAHgAgRCKQgLgEgIgIQgJgIgFgLQgFgMAAgOIAAgLIApAAIAAAKQAAAKAGAGQAGAFAHAAQAJAAAFgFQAFgFAAgKIAAhEQAAgIgFgFQgGgFgIAAQgHAAgGAFIgGAJIgkAAIAAiYIBzAAIAAAmIhPAAIAABOQAGgHAIgDQAIgEAKAAQALAAAIADQAJAEAGAGQAGAGAEAKQADAJAAALIAABJQAAAOgFAMQgFALgIAIQgJAIgLAEQgLAFgMAAQgKAAgLgFg");
	this.shape.setTransform(24,25.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.1,7.8,48.7,52.7);


(lib._bg = function() {
	this.initialize();

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu2AAAMAAAAnDg");
	this.shape.setTransform(234,30,1.56,0.24);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib._clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#070707").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.bussanim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.buzz();
	this.instance.setTransform(89.7,80,1,1,0,0,0,89.7,80);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:20},66).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,180.4,161);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{on:1,off:7});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6).call(this.frame_6).wait(6).call(this.frame_12).wait(1));

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhDAZQgKgKAAgPQAAgOALgKQAKgLAPAAQAPAAAKAJIgGAJQgEgEgEgBQgEgBgGAAQgKAAgIAHQgHAGAAAKQAAALAHAHQAHAGAKAAQAKAAAHgEIAAgTIAMAAIAAAYQgKALgTAAQgPAAgLgLgAAPAZQgLgKAAgPQAAgOALgKQALgLAPAAQAQAAAKALQALAKAAAOQAAAPgLAKQgKAKgQAAQgPAAgLgKgAAYgRQgHAIAAAJQAAAKAHAHQAHAIAKAAQALAAAHgIQAHgHAAgKQAAgJgHgIQgHgHgLAAQgKAAgHAHg");
	this.shape.setTransform(35.3,17.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13));

	// Layer 5
	this.instance = new lib.btnbg2();
	this.instance.setTransform(130,25.5,1,1,0,0,0,130,25.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},6).to({alpha:0},6).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FC9E09").s().p("AlUAPIAAgcIKpAAIAAAcg");
	this.shape_1.setTransform(34.2,34.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(13));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FCCD2A").s().p("AlUClIAAlJIKpAAIAAFJg");
	this.shape_2.setTransform(34.2,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,68.4,36);


(lib.f = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Am/QLIAAtAIY/AAIAANAg");
	var mask_graphics_133 = new cjs.Graphics().p("Am/QLIAAtAIY/AAIAANAg");
	var mask_graphics_134 = new cjs.Graphics().p("Am/QMIAAtAIY/AAIAANAg");
	var mask_graphics_135 = new cjs.Graphics().p("Am/QMIAAs/IY/AAIAAM/g");
	var mask_graphics_136 = new cjs.Graphics().p("Am/QNIAAs/IY/AAIAAM/g");
	var mask_graphics_137 = new cjs.Graphics().p("Am/QOIAAs/IY/AAIAAM/g");
	var mask_graphics_138 = new cjs.Graphics().p("Am/QOIAAs/IY/AAIAAM/g");
	var mask_graphics_139 = new cjs.Graphics().p("Am/QPIAAs/IY/AAIAAM/g");
	var mask_graphics_140 = new cjs.Graphics().p("Am/QPIAAs/IY/AAIAAM/g");
	var mask_graphics_141 = new cjs.Graphics().p("Am/QPIAAs/IY/AAIAAM/g");
	var mask_graphics_142 = new cjs.Graphics().p("Am/QQIAAtAIY/AAIAANAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:115.3,y:103.5}).wait(133).to({graphics:mask_graphics_133,x:115.3,y:103.5}).wait(1).to({graphics:mask_graphics_134,x:115.3,y:103.6}).wait(1).to({graphics:mask_graphics_135,x:115.3,y:103.7}).wait(1).to({graphics:mask_graphics_136,x:115.3,y:103.8}).wait(1).to({graphics:mask_graphics_137,x:115.3,y:103.8}).wait(1).to({graphics:mask_graphics_138,x:115.3,y:103.9}).wait(1).to({graphics:mask_graphics_139,x:115.3,y:103.9}).wait(1).to({graphics:mask_graphics_140,x:115.3,y:104}).wait(1).to({graphics:mask_graphics_141,x:115.3,y:104}).wait(1).to({graphics:mask_graphics_142,x:115.3,y:104}).wait(75));

	// grap
	this.instance = new lib.grap_1();
	this.instance.setTransform(152.5,240.5,1,1,0,0,0,76.5,23.5);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(133).to({_off:false},0).wait(1).to({y:228.1},0).wait(1).to({y:217.1},0).wait(1).to({y:207.4},0).wait(1).to({y:199.2},0).wait(1).to({y:192.3},0).wait(1).to({y:186.8},0).wait(1).to({y:182.6},0).wait(1).to({y:179.9},0).wait(1).to({y:178.5},0).wait(75));

	// 10
	this.instance_1 = new lib._50();
	this.instance_1.setTransform(177.9,162.5,1,1,0,0,0,35.4,25.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(97).to({_off:false},0).to({alpha:1},11).wait(26).to({regX:35.1,regY:25.4,x:177.6,y:149.9},0).wait(1).to({y:139},0).wait(1).to({y:129.5},0).wait(1).to({y:121.4},0).wait(1).to({y:114.6},0).wait(1).to({y:109.2},0).wait(1).to({y:105.1},0).wait(1).to({y:102.4},0).wait(1).to({regX:35.4,regY:25.8,x:177.9,y:101.5},0).to({_off:true},1).wait(74));

	// 10-s
	this.instance_2 = new lib._10();
	this.instance_2.setTransform(149.9,162.5,1,1,0,0,0,24.4,25.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(37).to({_off:false},0).to({alpha:1},9).wait(33).to({alpha:0},8).wait(10).to({x:113.9},0).to({alpha:1},11).wait(26).to({regX:24,regY:25.4,x:113.5,y:149.9},0).wait(1).to({y:139},0).wait(1).to({y:129.5},0).wait(1).to({y:121.4},0).wait(1).to({y:114.6},0).wait(1).to({y:109.2},0).wait(1).to({y:105.1},0).wait(1).to({y:102.4},0).wait(1).to({regX:24.4,regY:25.8,x:113.9,y:101.5},0).to({_off:true},1).wait(74));

	// buzz
	this.instance_3 = new lib.bussanim();
	this.instance_3.setTransform(150.7,196.3,1,1,0,0,0,89.7,80);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.instance_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(21).to({_off:false},0).to({alpha:1},8).wait(8).to({alpha:0},7).to({_off:true},1).wait(34).to({_off:false},0).to({alpha:1},8).wait(8).to({alpha:0},7).to({_off:true},1).wait(114));

	// Laptop\
	this.instance_4 = new lib.laptop();
	this.instance_4.setTransform(-364.5,170.9,1,1,0,0,0,0,59.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({_off:false},0).wait(1).to({x:-256.4},0).wait(1).to({x:-161},0).wait(1).to({x:-78.3},0).wait(1).to({x:-8.4},0).wait(1).to({x:48.8},0).wait(1).to({x:93.3},0).wait(1).to({x:125.1},0).wait(1).to({x:144.1},0).wait(1).to({x:150.5},0).wait(124).to({y:171.1},0).wait(1).to({y:171.2},0).wait(1).to({y:171.4},0).wait(1).to({y:171.5},0).wait(1).to({y:171.6},0).wait(1).to({y:171.7},0).wait(1).to({y:171.8},0).wait(2).to({y:171.9},0).wait(75));

	// oj mask
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("A1AJQIAAyfMAqBAAAIAASfg");
	this.shape.setTransform(516.4,151.3);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(73).to({_off:false},0).to({_off:true},31).wait(113));

	// m2-mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_74 = new cjs.Graphics().p("AbVPbIAAvmIPoAAIAAG3IglAPQgCABh9AAQiCgBgWACQglAEgQATQgOAPABAXQACAYAWAOIAKAFIAmAGIADAAIEzApIAAGHg");
	var mask_1_graphics_75 = new cjs.Graphics().p("AX3PbIAAvmIPoAAIAAG3IglAPQgCABh8AAQiDgBgVACQglAEgRATQgOAPACAXQACAYAVAOIALAFIAmAGIADAAIEyApIAAGHg");
	var mask_1_graphics_76 = new cjs.Graphics().p("AUvPbIAAvmIPoAAIAAG3IglAPQgCABh8AAQiDgBgVACQglAEgRATQgOAPACAXQACAYAVAOIALAFIAmAGIADAAIEyApIAAGHg");
	var mask_1_graphics_77 = new cjs.Graphics().p("AR+PbIAAvmIPoAAIAAG3IglAPQgCABh9AAQiCgBgWACQglAEgQATQgOAPABAXQACAYAWAOIAKAFIAmAGIADAAIEzApIAAGHg");
	var mask_1_graphics_78 = new cjs.Graphics().p("APiPbIAAvmIPoAAIAAG3IglAPQgCABh8AAQiDgBgVACQglAEgRATQgOAPACAXQACAYAVAOIALAFIAmAGIADAAIEyApIAAGHg");
	var mask_1_graphics_79 = new cjs.Graphics().p("ANdPbIAAvmIPoAAIAAG3IglAPQgCABh9AAQiCgBgWACQglAEgQATQgOAPABAXQACAYAWAOIAKAFIAmAGIADAAIEzApIAAGHg");
	var mask_1_graphics_80 = new cjs.Graphics().p("ALtPbIAAvmIPoAAIAAG3IglAPQgCABh8AAQiDgBgVACQglAEgRATQgOAPACAXQACAYAVAOIALAFIAmAGIADAAIEyApIAAGHg");
	var mask_1_graphics_81 = new cjs.Graphics().p("AKUPbIAAvmIPoAAIAAG3IglAPQgCABh9AAQiCgBgWACQglAEgQATQgOAPABAXQACAYAWAOIAKAFIAmAGIADAAIEzApIAAGHg");
	var mask_1_graphics_82 = new cjs.Graphics().p("AJQPbIAAvmIPoAAIAAG3IglAPQgCABh8AAQiDgBgVACQglAEgRATQgOAPACAXQACAYAVAOIALAFIAmAGIADAAIEyApIAAGHg");
	var mask_1_graphics_83 = new cjs.Graphics().p("AIjPbIAAvmIPoAAIAAG3IglAPQgCABh8AAQiDgBgVACQglAEgRATQgOAPACAXQACAYAVAOIALAFIAmAGIADAAIEyApIAAGHg");
	var mask_1_graphics_84 = new cjs.Graphics().p("AIMPbIAAvmIPoAAIAAG3IglAPQgCABh9AAQiCgBgWACQglAEgQATQgOAPABAXQACAYAWAOIAKAFIAmAGIADAAIEzApIAAGHg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(74).to({graphics:mask_1_graphics_74,x:274.9,y:98.8}).wait(1).to({graphics:mask_1_graphics_75,x:252.8,y:98.8}).wait(1).to({graphics:mask_1_graphics_76,x:232.8,y:98.8}).wait(1).to({graphics:mask_1_graphics_77,x:215,y:98.8}).wait(1).to({graphics:mask_1_graphics_78,x:199.5,y:98.8}).wait(1).to({graphics:mask_1_graphics_79,x:186.1,y:98.8}).wait(1).to({graphics:mask_1_graphics_80,x:175,y:98.8}).wait(1).to({graphics:mask_1_graphics_81,x:166,y:98.8}).wait(1).to({graphics:mask_1_graphics_82,x:159.3,y:98.8}).wait(1).to({graphics:mask_1_graphics_83,x:154.8,y:98.8}).wait(1).to({graphics:mask_1_graphics_84,x:152.4,y:98.8}).wait(14).to({graphics:null,x:0,y:0}).wait(119));

	// m2
	this.instance_5 = new lib.m2();
	this.instance_5.setTransform(501.7,156.7,1,1,0,0,0,44.2,20.4);
	this.instance_5._off = true;

	this.instance_5.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(74).to({_off:false},0).wait(1).to({regY:20.5,x:457.4,y:156.8},0).wait(1).to({x:417.4},0).wait(1).to({x:381.9},0).wait(1).to({x:350.8},0).wait(1).to({x:324.1},0).wait(1).to({x:301.8},0).wait(1).to({x:283.9},0).wait(1).to({x:270.4},0).wait(1).to({x:261.4},0).wait(1).to({regY:20.4,x:256.7,y:156.7},0).wait(2).to({x:196.7},11).to({_off:true},1).wait(119));

	// h2
	this.instance_6 = new lib.hand2();
	this.instance_6.setTransform(565.5,150.1,1,1,0,0,0,56.9,26.3);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(74).to({_off:false},0).wait(1).to({regX:104,regY:61.2,x:568.3,y:185},0).wait(1).to({x:528.3},0).wait(1).to({x:492.8},0).wait(1).to({x:461.7},0).wait(1).to({x:435},0).wait(1).to({x:412.7},0).wait(1).to({x:394.8},0).wait(1).to({x:381.3},0).wait(1).to({x:372.3},0).wait(1).to({regX:56.9,regY:26.3,x:320.5,y:150.1},0).wait(10).to({regX:104,regY:61.2,x:371.7,y:185},0).wait(1).to({x:379.6},0).wait(1).to({x:391.5},0).wait(1).to({x:407.2},0).wait(1).to({x:426.7},0).wait(1).to({x:450.2},0).wait(1).to({x:477.5},0).wait(1).to({x:508.6},0).wait(1).to({x:543.7},0).wait(1).to({regX:56.9,regY:26.3,x:535.5,y:150.1},0).to({_off:true},1).wait(113));

	// m (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_15 = new cjs.Graphics().p("A10PcIAAmFIAtACQAkABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgNgUgjgLQgugOhWgDQgQgBgQABIgHAaIAAnfIPoAAIAAPng");
	var mask_2_graphics_16 = new cjs.Graphics().p("AzNPcIAAmFIAtACQAkABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgQABIgHAaIAAnfIPoAAIAAPng");
	var mask_2_graphics_17 = new cjs.Graphics().p("AwxPcIAAmFIAtACQAkABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgQABIgHAaIAAnfIPoAAIAAPng");
	var mask_2_graphics_18 = new cjs.Graphics().p("AufPcIAAmFIAtACQAkABAXgBQBLgGAfgaQAVgSgCgaQgCgXgIgMQgNgUgjgLQgugOhWgDQgPgBgRABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_19 = new cjs.Graphics().p("AsXPcIAAmFIAtACQAkABAXgBQBLgGAfgaQAVgSgCgaQgCgXgIgMQgNgUgjgLQgugOhWgDQgPgBgRABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_20 = new cjs.Graphics().p("AqZPcIAAmFIAtACQAkABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgQABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_21 = new cjs.Graphics().p("AolPcIAAmFIAtACQAkABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgQABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_22 = new cjs.Graphics().p("AnyPcIAAmFIAtACQAjABAXgBQBLgGAfgaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgugOhVgDQgQgBgRABIgGAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_23 = new cjs.Graphics().p("AnzPcIAAmFIAtACQAkABAXgBQBMgGAegaQAVgSgCgaQgCgXgIgMQgNgUgjgLQgtgOhXgDQgPgBgQABIgIAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_24 = new cjs.Graphics().p("AnyPcIAAmFIAtACQAjABAXgBQBLgGAfgaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgRABIgGAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_25 = new cjs.Graphics().p("AnzPcIAAmFIAtACQAlABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgOgUgjgLQgugOhVgDQgQgBgRABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_26 = new cjs.Graphics().p("AnzPcIAAmFIAtACQAlABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgOgUgjgLQgugOhVgDQgQgBgQABIgIAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_27 = new cjs.Graphics().p("AnzPcIAAmFIAtACQAlABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgOgUgjgLQgugOhVgDQgQgBgRABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_28 = new cjs.Graphics().p("AnyPcIAAmFIAtACQAjABAXgBQBLgGAfgaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgRABIgGAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_29 = new cjs.Graphics().p("AnpPcIAAmFIAtACQAkABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgQABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_30 = new cjs.Graphics().p("AnRPcIAAmFIAtACQAkABAWgBQBMgGAegaQAVgSgCgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgQgBgQABIgHAaIAAnfIPmAAIAAPng");
	var mask_2_graphics_31 = new cjs.Graphics().p("AnDPcIAAmFIAtACQAkABAXgBQBLgGAegaQAWgSgDgaQgCgXgHgMQgNgUgkgLQgtgOhWgDQgPgBgRABIgHAaIAAnfIPmAAIAAPng");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_2_graphics_15,x:-139.7,y:98.8}).wait(1).to({graphics:mask_2_graphics_16,x:-123.1,y:98.8}).wait(1).to({graphics:mask_2_graphics_17,x:-107.5,y:98.8}).wait(1).to({graphics:mask_2_graphics_18,x:-92.8,y:98.8}).wait(1).to({graphics:mask_2_graphics_19,x:-79.2,y:98.8}).wait(1).to({graphics:mask_2_graphics_20,x:-66.7,y:98.8}).wait(1).to({graphics:mask_2_graphics_21,x:-55.1,y:98.8}).wait(1).to({graphics:mask_2_graphics_22,x:-39.1,y:98.8}).wait(1).to({graphics:mask_2_graphics_23,x:-20,y:98.8}).wait(1).to({graphics:mask_2_graphics_24,x:-2.9,y:98.8}).wait(1).to({graphics:mask_2_graphics_25,x:12.1,y:98.8}).wait(1).to({graphics:mask_2_graphics_26,x:25.1,y:98.8}).wait(1).to({graphics:mask_2_graphics_27,x:36,y:98.8}).wait(1).to({graphics:mask_2_graphics_28,x:44.9,y:98.8}).wait(1).to({graphics:mask_2_graphics_29,x:50.9,y:98.8}).wait(1).to({graphics:mask_2_graphics_30,x:53.3,y:98.8}).wait(1).to({graphics:mask_2_graphics_31,x:54.8,y:98.8}).wait(20).to({graphics:null,x:0,y:0}).wait(166));

	// note
	this.instance_7 = new lib.note_10();
	this.instance_7.setTransform(-234.5,154.3,1,1,0,0,0,48.5,20.4);
	this.instance_7._off = true;

	this.instance_7.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(15).to({_off:false},0).wait(1).to({regX:52.7,regY:20.5,x:-197,y:154.4},0).wait(1).to({x:-165.7},0).wait(1).to({x:-136.5},0).wait(1).to({x:-109.3},0).wait(1).to({x:-84.1},0).wait(1).to({x:-61},0).wait(1).to({x:-39.9},0).wait(1).to({x:-20.8},0).wait(1).to({x:-3.7},0).wait(1).to({x:11.3},0).wait(1).to({x:24.3},0).wait(1).to({x:35.2},0).wait(1).to({x:44.1},0).wait(1).to({x:51},0).wait(1).to({x:55.8},0).wait(1).to({regX:48.5,regY:20.4,x:54.5,y:154.3},0).wait(3).to({regX:52.7,regY:20.5,x:59.5,y:154.4},0).wait(1).to({x:61.2},0).wait(1).to({x:63.6},0).wait(1).to({x:66.9},0).wait(1).to({x:71},0).wait(1).to({x:75.9},0).wait(1).to({x:81.6},0).wait(1).to({x:88.2},0).wait(1).to({x:95.5},0).wait(1).to({regX:48.5,regY:20.4,x:99.5,y:154.3},0).to({_off:true},1).wait(173));

	// hand
	this.instance_8 = new lib.hand();
	this.instance_8.setTransform(-329.9,123.5,1,1,0,0,0,73.4,44.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(15).to({_off:false},0).wait(1).to({regX:36.7,regY:43.5,x:-333.3,y:122.8},0).wait(1).to({x:-302},0).wait(1).to({x:-272.8},0).wait(1).to({x:-245.6},0).wait(1).to({x:-220.4},0).wait(1).to({x:-197.3},0).wait(1).to({x:-176.2},0).wait(1).to({x:-157.1},0).wait(1).to({x:-140},0).wait(1).to({x:-125},0).wait(1).to({x:-112},0).wait(1).to({x:-101.1},0).wait(1).to({x:-92.2},0).wait(1).to({x:-85.3},0).wait(1).to({x:-80.4},0).wait(1).to({regX:73.4,regY:44.2,x:-40.9,y:123.5},0).wait(9).to({regX:36.7,regY:43.5,x:-81,y:122.8},0).wait(1).to({x:-87.4},0).wait(1).to({x:-96.9},0).wait(1).to({x:-109.5},0).wait(1).to({x:-125},0).wait(1).to({x:-143.7},0).wait(1).to({x:-165.4},0).wait(1).to({x:-190.1},0).wait(1).to({x:-217.9},0).wait(1).to({x:-248.7},0).wait(1).to({regX:73.4,regY:44.2,x:-245.9,y:123.5},0).to({_off:true},1).wait(166));

	// s
	this.instance_9 = new lib.lapshad();
	this.instance_9.setTransform(-333.6,289.2,1,1,0,0,0,144.1,175);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1).to({_off:false},0).wait(1).to({regX:193.6,regY:247.5,x:-181.1,y:361.7},0).wait(1).to({x:-89.5},0).wait(1).to({x:-9.4},0).wait(1).to({x:59.3},0).wait(1).to({x:116.5},0).wait(1).to({x:162.3},0).wait(1).to({x:196.6},0).wait(1).to({x:219.5},0).wait(1).to({regX:144.1,regY:175,x:181.4,y:289.2},0).wait(124).to({regX:193.6,regY:247.5,x:230.9,y:361.9},0).wait(1).to({y:362},0).wait(1).to({y:362.2},0).wait(1).to({y:362.3},0).wait(1).to({y:362.4},0).wait(1).to({y:362.5},0).wait(1).to({y:362.6},0).wait(2).to({regX:144.1,regY:175,x:181.4,y:290.2},0).wait(75));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


// stage content:



(lib.highlow_468x602b_USD = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.enableMouseOver(20);
		
		this.loopNumber = 0 ;
		
		// CLICKTHROUGH
		this.clickTagBtn.addEventListener("click", function () {
			console.log("clickthrough");
			window.open(window.clickTAG);
		});
		
		// CTA
		this.clickTagBtn.addEventListener("mouseover", function () {
			exportRoot.bt.gotoAndPlay("on");
		});
		
		this.clickTagBtn.addEventListener("mouseout", function () {
			exportRoot.bt.gotoAndPlay("off");
		});
	}
	this.frame_240 = function() {
		if(this.loopNumber >= 1){
			console.log("STOP BANNER");
			this.stop();
		} else {
			this.loopNumber++;
			console.log("RESTART: " + this.loopNumber);
		}
	}
	this.frame_251 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(240).call(this.frame_240).wait(11).call(this.frame_251).wait(1));

	// clickTagBtn
	this.clickTagBtn = new lib._clicktag();
	this.clickTagBtn.setTransform(0,0,2.925,0.1);
	new cjs.ButtonHelper(this.clickTagBtn, 0, 1, 2, false, new lib._clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickTagBtn).wait(252));

	// Border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EgkjgErMBJHAAAIAAJXMhJHAAAg");
	this.shape.setTransform(234,30);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(252));

	// bt
	this.bt = new lib.btn();
	this.bt.setTransform(385,82);

	this.timeline.addTween(cjs.Tween.get(this.bt).wait(193).to({y:13,alpha:0},0).to({alpha:1},9).wait(40).to({y:82},9,cjs.Ease.get(0.9)).wait(1));

	// logo
	this.instance = new lib.logo_mc();
	this.instance.setTransform(83.5,34.8,1,1,0,0,0,64.5,18.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(184).to({_off:false},0).to({alpha:1},9).wait(49).to({y:-43.2},9,cjs.Ease.get(0.9)).wait(1));

	// t3
	this.instance_1 = new lib.t3();
	this.instance_1.setTransform(396,136.9,1,1,0,0,0,0,29.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(133).to({_off:false},0).to({x:296,y:46.9},9,cjs.Ease.get(0.9)).wait(35).to({x:221},10,cjs.Ease.get(0.9)).wait(55).to({y:-33.1},9,cjs.Ease.get(0.9)).wait(1));

	// t2
	this.instance_2 = new lib.t2();
	this.instance_2.setTransform(386.2,27.7,1,1,0,0,0,0,29.9);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(57).to({_off:false},0).to({alpha:1},9).wait(67).to({x:296.2,y:-62.3},9,cjs.Ease.get(0.9)).to({_off:true},1).wait(109));

	// t1
	this.instance_3 = new lib.t1();
	this.instance_3.setTransform(390,31.2,1,1,0,0,0,0,17.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).to({alpha:1},7).wait(39).to({alpha:0},9).to({_off:true},1).wait(192));

	// bg-o
	this.instance_4 = new lib.bgo();
	this.instance_4.setTransform(468,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:301},9,cjs.Ease.get(0.9)).wait(124).to({x:179},9,cjs.Ease.get(0.9)).wait(35).to({x:0},10,cjs.Ease.get(0.9)).wait(55).to({x:488},9,cjs.Ease.get(0.9)).wait(1));

	// Layer 21
	this.instance_5 = new lib.f("synched",0);
	this.instance_5.setTransform(53,-65,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(133).to({startPosition:133},0).to({scaleX:0.47,scaleY:0.47,x:18,y:-49,startPosition:142},9,cjs.Ease.get(0.9)).wait(35).to({startPosition:177},0).to({x:-162,startPosition:187},10,cjs.Ease.get(0.9)).to({_off:true},3).wait(62));

	// bg2
	this.instance_6 = new lib.bg2_1();
	this.instance_6.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(252));

	// bg
	this.instance_7 = new lib._bg();
	this.instance_7.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(252));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(233,29,937,119);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;