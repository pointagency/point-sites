(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 320,
	height: 50,
	fps: 18,
	color: "#FFFFFF",
	manifest: [
		{src:"images/_320x50_mask.png", id:"_320x50_mask"},
		{src:"images/bg111.jpg", id:"bg111"},
		{src:"images/web.jpg", id:"web"}
	]
};



// symbols:



(lib._320x50_mask = function() {
	this.initialize(img._320x50_mask);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,50);


(lib.bg111 = function() {
	this.initialize(img.bg111);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,50);


(lib.web = function() {
	this.initialize(img.web);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,101);


(lib.webimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.web();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,320,101);


(lib.t6 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEwAoQgJgKAAgPIAAgCQAAgNAJgKQAIgKAPAAQANAAAIAIQAHAHAAAKIgRAAQAAgFgDgCQgDgDgFAAQgHAAgDAFQgDAEAAAJIAAACQAAAJADAGQADAFAHAAQAFAAADgDQADgCAAgFIARAAIAAAAQAAALgIAHQgIAHgMAAQgPAAgIgKgADnAsQgGgGAAgJQAAgKAIgGQAIgFAPAAIAKAAIAAgGQAAgDgDgCQgCgDgFAAQgFAAgCACQgDACAAACIgSAAIAAAAQAAgHAIgGQAIgHANAAQAMAAAIAHQAIAGAAAJIAAAdIAAAJIADAIIgTAAIgCgFIgBgFQgCAFgFADQgFAEgGAAQgLAAgGgGgAD3AVQgDADAAAEQAAAEACACQACACAEAAQAFAAAEgDQAEgCABgDIAAgKIgKAAQgGAAgDADgAC1AvQgFgCgDgFIgBAIIgQAAIAAhhIASAAIAAAmQADgEAFgCQAEgDAFAAQANAAAHAKQAHAKAAAOIAAACQAAAPgHAJQgHAKgNAAQgGAAgEgDgACzgEQgDACgCACIAAAdQACADADACQADABAEAAQAIAAACgFQADgFAAgJIAAgCQAAgKgDgEQgDgFgHAAQgEAAgDABgAgcArQgIgHAAgJIAAgBIARAAQABAGADACQADADAGAAQAFAAABgCQACgCAAgEQAAgDgCgCQgBgCgIgCQgNgCgGgFQgGgFAAgIQAAgHAIgGQAHgHAMAAQAMAAAHAGQAIAHAAAHIgSAAQAAgCgCgCQgBgDgGAAQgEAAgDACQgCACAAADQAAACADACQACACAIACQALACAGAFQAGAFAAAJQAAAJgHAGQgIAGgLAAQgOAAgIgHgAhkAsQgGgGAAgJQAAgKAIgGQAIgFAPAAIAKAAIAAgGQAAgDgDgCQgCgDgFAAQgFAAgCACQgDACAAACIgSAAIAAAAQAAgHAIgGQAIgHANAAQAMAAAIAHQAIAGAAAJIAAAdIAAAJIADAIIgTAAIgCgFIgBgFQgCAFgFADQgFAEgGAAQgLAAgGgGgAhUAVQgDADAAAEQAAAEACACQACACAEAAQAFAAAEgDQAEgCABgDIAAgKIgKAAQgGAAgDADgAikAoQgIgKAAgPIAAgCQAAgNAIgKQAIgKAQAAQAMAAAIAIQAIAHAAAKIgRAAQAAgFgDgCQgDgDgFAAQgIAAgDAFQgDAEAAAJIAAACQAAAJADAGQADAFAIAAQAFAAADgDQADgCAAgFIAQAAIABAAQAAALgIAHQgIAHgMAAQgQAAgIgKgAkMAoQgJgJAAgTIAAgSQAAgSAJgKQAIgKAPAAQAOAAAIAKQAJAKAAASIAAASQAAATgJAJQgIAKgOAAQgPAAgIgKgAj/gYQgDAFAAALIAAAWQAAALADAFQADAFAHAAQAGAAADgFQADgFAAgLIAAgWQAAgLgDgFQgDgFgGAAQgHAAgDAFgAlWArQgJgHABgNIASgBQAAAGADAEQAEADAFAAQAHAAADgEQADgFAAgHQAAgIgDgFQgEgFgGAAQgFAAgDACQgDACgBADIgRgBIAGgxIAzAAIAAAPIgkAAIgDAVIAHgDIAIgBQANgBAHAJQAHAGAAAPQAAANgIAJQgIAJgPAAQgMAAgKgHgAGYAwIgTgdIgFAAIAAAdIgTAAIAAhhIATAAIAAA2IAEAAIAQgXIAWAAIgWAdIAZAlgABJAwIAAgpQAAgHgDgCQgCgDgGAAIgHABIgFAEIAAAwIgSAAIAAhhIASAAIAAAnQAEgEAEgDQAFgDAGAAQALAAAGAHQAGAIAAAMIAAApgAmoAwIAAgOIAAAAQADgBACgFQABgFAAgGIAAgGIgKAAIAAgMIAJAAIAAgOQAAgNAIgIQAHgIANAAQAOAAAHAIQAIAHgBALIAAABIgSAAQAAgGgDgDQgDgDgEAAQgEAAgDAEQgDADAAAHIABAOIAXAAIAAAMIgWAAIAAAFQAAAFgCAFQgCAEgDAEIAtAAIAAAOgABpAQIAAgOIAkAAIAAAOg");
	this.shape.setTransform(-67.2,-13.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-112.8,-24,90.6,21.1);


(lib.t5 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ACMAeQgJgJAAgRIAAgpIARAAIAAApQAAAJAEAFQAEAGAIAAQAHAAAFgGQADgFAAgJIAAgpIARAAIAAApQABARgKAJQgJAJgOAAQgOAAgKgJgAiEAcQgMgLAAgRQAAgQAMgLQAMgLAQAAQARAAANAKIgJANQgGgEgEgCQgEgCgFAAQgKAAgHAHQgGAHgBAJQAAALAHAGQAGAHAJAAQAJAAAGgEIAAgUIARAAIAAAaQgLANgVAAQgQAAgMgLgAkqAaIAKgNQAMALAKAAQAGAAACgCQADgCAAgEQAAgDgDgCQgDgCgJgCQgNgDgGgEQgGgFAAgLQAAgLAHgFQAJgGALAAQAIAAAIACQAHADAGAFIgJAMQgJgHgMAAQgDAAgDACQgCACgBADQAAADADACQAEACAKADQALADAHADQAFAGABAKQAAAKgIAHQgIAGgNAAQgSAAgOgNgADvAmIAAhLIAbAAQARAAAJAHQAHAHAAAOQABANgJAGQgIAHgRAAIgKAAIAAAVgAEAACIALAAQAIAAAEgCQADgDAAgHQAAgGgEgDQgEgDgIAAIgKAAgAATAmIgjguIAAAuIgRAAIAAhLIAQAAIAkAwIAAgwIARAAIAABLgAjHAmIAAhLIARAAIAABLg");
	this.shape.setTransform(-80,-6.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-112.4,-15,62.4,17.4);


(lib.t3c = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#EE683A").ss(1,0,1).p("AAAhjIAADH");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-11,2,22);


(lib.t3b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAUBMQgHgCgFgDIAEgLQAEACAGABIALABQALAAAGgEQAFgGAAgKIAAgKQgFAGgFADQgGACgIAAQgPAAgJgLQgHgLAAgSIAAgCQAAgTAHgMQAJgNAQAAQAIABAGADQAGADAEAGIACgLIAMAAIAABTQAAAQgJAJQgKAJgSAAIgNgCgAATgTQgGAKAAAMIAAACQAAAMAGAIQAFAIALAAQAHAAAFgEQAFgCADgHIAAglQgDgFgFgDQgFgDgHAAQgLAAgFAJgAj/BOIgFgBIACgNIADAAIAEAAQAFAAADgDIAFgKIAEgJIgghRIARAAIAVA+IAVg+IARAAIgjBfQgDAJgGAGQgGAHgKAAIgFAAgAHJAiQgJgLAAgSIAAgCQAAgTAJgMQAJgNAQAAQAHAAAGADQAFADAFAFIAAgvIAPAAIAAB5IgNAAIgBgLQgFAGgGADQgGADgIAAQgPAAgJgLgAHVgTQgFAJAAANIAAACQAAANAFAHQAFAIALAAQAHAAAFgEQAFgDADgFIAAgmQgDgFgFgDQgFgDgHAAQgLAAgFAJgAF2AiQgKgNAAgSIAAgDQAAgQALgMQAKgNAPAAQARAAAJALQAJAKAAARIAAAIIg3AAQAAANAGAHQAGAIALAAQAHAAAGgCQAGgDAEgDIAGAJQgEAFgIADQgHADgKAAQgSAAgLgLgAGDgWQgGAHgBAJIAnAAIAAgCQAAgJgEgGQgFgFgKAAQgIAAgFAGgAFCAoQgFgGAAgMIAAgxIgOAAIAAgMIAOAAIAAgVIAPAAIAAAVIAQAAIAAAMIgQAAIAAAxQAAAGADACQACACAEABIADgBIADAAIACAKIgFACIgHABQgJAAgGgFgADkAmQgHgGAAgMQAAgNAKgGQAKgFAQAAIARAAIAAgIQAAgIgEgEQgFgFgIABQgIAAgEADQgFAEAAAFIgPAAIAAAAQAAgKAJgHQAJgIAPAAQAOAAAJAIQAJAHAAAOIAAAmIAAAJQAAAFACAEIgQAAIgBgHIgBgGQgEAGgHAEQgHAEgIAAQgNAAgHgHgADyAJQgGAEAAAHQAAAFAEAEQADADAHAAQAJAAAGgEQAHgFACgFIAAgNIgRAAQgJgBgGAFgABkAkQgIgIAAgTIAAgwIAQAAIAAAwQAAAOADAEQAEAGAJAAQAIAAAGgEQAFgDADgGIAAg7IAPAAIAABTIgOAAIgBgNQgEAHgGAEQgGADgJAAQgNAAgIgJgAhKAiQgLgNAAgSIAAgDQAAgQALgMQALgNAPAAQARAAAJALQAIAKAAARIAAAIIg3AAQAAANAGAHQAGAIALAAQAIAAAGgCQAGgDAEgDIAGAJQgFAFgHADQgHADgLAAQgSAAgKgLgAg+gWQgFAHgBAJIAnAAIAAgCQAAgJgFgGQgFgFgJAAQgIAAgGAGgAmlAkQgIgIAAgTIAAgwIAQAAIAAAwQAAAOADAEQAEAGAJAAQAIAAAGgEQAFgDADgGIAAg7IAPAAIAABTIgOAAIgBgNQgEAHgGAEQgGADgJAAQgNAAgIgJgAC5AsIAAh5IAPAAIAAB5gAiIAsIAAhTIAOAAIABANQAEgHAFgEQAFgEAHAAIADAAIADACIgCANIgIAAQgGAAgEADQgEADgDAFIAAA7gAkoAsIAAh5IAQAAIAAB5gAlQAsIAAh5IAPAAIAAB5gAoHAsIAAhwIBMAAIAAAMIg8AAIAAAnIA0AAIAAAMIg0AAIAAAxg");
	this.shape.setTransform(93.4,11.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(38,-3,110.3,25.1);


(lib.t3a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhyBNIAAhzIAMAAIADALQAEgFAGgEQAGgDAIAAQAQAAAJAMQAIANAAASIAAACQAAASgIALQgJAMgPAAQgIAAgGgDQgGgDgEgFIAAApgAhbgXQgEACgDAGIAAAmQADAFAEADQAFADAHAAQALAAAFgIQAGgHAAgNIAAgCQAAgMgGgKQgFgIgLgBQgHAAgFAEgADdAiQgKgMAAgSIAAgCQAAgRAKgMQAKgMASAAQARAAAKAMQALAMAAARIAAACQAAASgLAMQgKANgRAAQgSAAgKgNgADogSQgGAIAAAMIAAACQAAANAGAJQAGAJALgBQALABAFgJQAGgJAAgNIAAgCQAAgMgGgIQgFgJgLAAQgLAAgGAJgAByApQgFgGAAgMIAAgxIgOAAIAAgMIAOAAIAAgUIAPAAIAAAUIAQAAIAAAMIgQAAIAAAxQAAAGADACQACADAEAAIADgBIADAAIACAKIgFADIgHABQgJAAgGgGgAAUAoQgHgHAAgLQAAgNAKgGQAKgGAQABIARAAIAAgJQAAgIgEgDQgFgFgIAAQgIAAgEAEQgFADAAAGIgPAAIAAAAQAAgKAJgHQAJgIAPAAQAOAAAJAIQAJAGAAAOIAAAnIAAAJQAAAEACAEIgQAAIgBgGIgBgHQgEAHgHADQgHAFgIAAQgNAAgHgHgAAiALQgGAEAAAHQAAAFAEAEQADACAHAAQAJAAAGgDQAHgFACgFIAAgOIgRAAQgJAAgGAFgAjHApQgFgGAAgMIAAgxIgOAAIAAgMIAOAAIAAgUIAPAAIAAAUIAQAAIAAAMIgQAAIAAAxQAAAGADACQACADAEAAIADgBIADAAIACAKIgFADIgHABQgJAAgGgGgAkeAnQgKgJABgKIAAgBIAPAAQAAAIAGAEQAFAEAIgBQAIAAAFgDQAFgDAAgFQAAgFgEgEQgEgDgLgDQgPgDgIgFQgIgEAAgKQAAgLAJgHQAJgHAOAAQAOAAAJAIQAJAHgBALIAAABIgOAAQAAgGgFgEQgFgFgHAAQgJAAgEAEQgDADAAAGQAAAFADACQAEADAKACQAQACAIAFQAIAHAAAKQAAAKgJAIQgJAGgPABQgQgBgJgHgAlyAjQgLgMAAgTIAAgDQAAgQALgMQALgMAPAAQARAAAJAKQAIAKAAARIAAAIIg3AAQAAANAGAHQAGAIALAAQAIAAAGgCQAGgCAEgEIAGAKQgFAEgHADQgHAEgLAAQgSAAgKgMgAlmgUQgFAGgBAKIAnAAIAAgCQAAgJgFgGQgFgGgJAAQgIAAgGAHgAHPAtIAAgwQAAgNgFgFQgEgFgJgBQgHAAgFAGQgFAGgBAHIAAA1IgQAAIAAgwQAAgMgEgGQgEgGgJAAQgHAAgEAEQgFACgCAGIAAA8IgQAAIAAhTIAOAAIABALQAEgFAHgEQAGgDAJAAQAIAAAGAEQAGADADAJQAEgIAHgEQAGgEAJAAQANAAAHAJQAIAJAAASIAAAwgAExAtIAAhTIAOAAIACANQADgGAGgFQAFgDAHAAIADAAIADABIgDAOIgHAAQgHAAgEADQgEACgCAGIAAA6gACmAtIAAhHIgNAAIAAgMIANAAIAAgKQAAgNAHgIQAHgHANAAIAFAAIAGABIgCAMIgDgBIgEAAQgHAAgDAEQgEAEAAAIIAAAKIASAAIAAAMIgSAAIAABHgAgVAtIAAh4IAPAAIAAB4gAndAtIAAhvIAlAAQASAAAKAHQAKAIAAAPQAAAHgEAHQgFAGgIADQAKABAGAJQAGAFAAALQAAAQgKAIQgKAIgSAAgAnNAhIAaAAQALAAAGgFQAGgGAAgJQAAgKgFgEQgFgFgKAAIgdAAgAnNgTIAZAAQAIABAGgFQAFgFAAgJQAAgIgGgFQgGgEgLgBIgVAAg");
	this.shape.setTransform(76.2,11.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(25,-3,101.9,25.1);


(lib.t22 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AHPEhQgZgKgTgTQgTgTgKgZQgLgaAAgcIAAnIIBVAAIAAHAQAAAeAPAQQANAPAYAAQAXAAAOgPQAPgQAAgeIAAnAIBVAAIAAHIQAAAcgLAaQgKAZgTATQgTATgZAKQgZALgcAAQgcAAgZgLgABvEjQgagKgTgRQgVgTgMgaQgMgcAAgkIAAk1QAAgkAMgbQAMgbAVgSQATgTAagJQAZgJAaAAQAbAAAZAJQAZAJAUATQAVASAMAbQAMAbAAAkIAAE1QAAAkgMAcQgMAagVATQgUARgZAKQgZAJgbAAQgaAAgZgJgAB6jHQgRAQAAAdIAAE1QAAAeARAPQAQAPAYAAQAZAAAQgPQARgPAAgeIAAk1QAAgdgRgQQgQgPgZgBQgYABgQAPgAMUEnIAAn+IhiAAIAAhPIEZAAIAABPIhiAAIAAH+gAjYEnIAAj6Ih0lTIBaAAIBEDrIABAAIBFjrIBZAAIh0FTIAAD6gAmkEnIgZh/Ih0AAIgYB/IhVAAICEpNIBHAAICDJNgAnNBZIgpjVIgCAAIgqDVIBVAAgAvKEnIAApNICAAAQAjAAAaAJQAbAKAVAXQAWAWAIAgQAIAfAAA1QAAAqgEAZQgFAcgPAWQgSAegdAPQgeAQgtAAIgsAAIAADngAt1gOIApAAQAZAAAPgGQAOgHAGgOQAKgSAAg2QAAg1gJgTQgGgOgOgHQgOgJgYAAIgsAAg");
	this.shape.setTransform(99.6,34.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.5,2.8,202.2,102.5);


(lib.t2roll = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgBeBxwIBej4IAAgBIgMAEQgJACgOAAQgXAAgSgLQgTgKgLgRQgHgLgEgOQgFgOgBgaQgBgaAAguQAAgmABgWQABgWAFgNQAEgNAIgNQAQgbAcgPQAbgPAiAAQAiABAbAPQAcAOARAbQAIANAEANQAEANACAWQACAWAAAmQAAAkgCAVQgCAUgDAPQgDAOgGAPIhuEpgEgAbBp9QgMALgBATIAABuQABATAMAMQAMALAPAAQAQAAAMgLQANgMAAgTIAAhuQAAgTgNgLQgMgMgQAAQgPAAgMAMgEgA9BmGQgagOgOgXQgJgMgFgOQgFgNgCgVQgCgVAAglQgBgrADgbQACgaAJgRQAJgRAUgPQgUgPgJgQQgJgQgCgWQgDgWABgjQAAgfACgVQAEgTAHgOQAGgPALgNQARgWAZgMQAZgMAbAAQAcAAAZAMQAZAMARAWQALANAHAPQAHAOADATQADAVAAAfQAAAjgCAWQgCAWgKAQQgJAQgTAPQATAPAJARQAKARACAaQACAbAAArQAAAkgCAWQgDAVgFANQgFAOgIAMQgPAXgaAOQgZAPglABQgjgBgagPgEgAbBiGQgMAMgBARIAAB1QABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAh1QAAgRgNgMQgMgMgQAAQgPAAgMAMgEgAbBeeQgMAMgBARIAABXQABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAhXQAAgRgNgMQgMgMgQAAQgPAAgMAMgEgBpBayICSn/IhbAAIAABEIhKAAIAAiUID6AAIAABVIiOH6gEgA8BPIQgcgPgRgbQgIgMgEgNQgEgNgCgWQgBgWAAgmQAAgkABgVQACgUADgOQAEgPAFgPIBtkpIBfAAIhfD4IAAACQAFgDAIgCQAJgCAOAAQAXAAASALQAUAKAKARQAIAKAEAOQAEAPABAaQACAaAAAuQAAAmgCAWQgBAWgFANQgEANgHAMQgRAdgcAOQgbAPgjAAQghgBgbgPgEgAbBLMQgMAMgBATIAABuQABAUAMALQAMALAPAAQAQAAAMgLQANgLAAgUIAAhuQAAgTgNgMQgMgLgQAAQgPAAgMALgEgA9BDpQgdgPgRgcQgRgdgBgnIAAgZIBVAAIAAAWQAAAWAMALQAMAMARAAQATAAAKgMQALgLAAgVIAAiLQAAgSgLgLQgLgNgSAAQgMAAgJAGQgJAGgEAIIgHAMIhLAAIAAk+IDxAAIAABQIimAAIAACfQAMgMASgHQAQgIAWgBQAsAAAbAbQAaAbABAzIAACZQgBAngRAdQgSAcgcAPQgcAQgiAAQghAAgcgQgEAAVA4VIAAhYIimAAIAAhQIB6mnIBYAAIh+GnIBSAAIAAioIBVAAIAACoIAoAAIAABQIgoAAIAABYgEgA3AsuQgdgMgUgcQgUgbAAguIAAgxIBUAAIAAAsQAAAVALAMQALANASAAQATAAALgNQALgMAAgXIAAhUQABghgOgMQgOgMgmACIAAhLQAjABAPgLQAPgKAAgfIAAhNQAAgSgLgLQgLgMgTAAQgVABgJANQgKAOAAANIAAAwIhUAAIAAgwQAAgkARgcQARgcAdgRQAdgQAhgBQAjABAXANQAXANALAPQAMANAHAOQAHAPADAXQAEAXAAAlQAAAogDAWQgDAWgMAMQgLANgYAOQAaAQALAPQALAPADAYQACAZAAApQAAAmgCAWQgCAWgFANQgFAOgJAMQgPAXgaAPQgZAPglABIgBAAQgbAAgbgNgEgB8AhXIAAhQICWkfQALgWACgQQACgSAAgXQAAgPgCgPQgBgPgJgKQgJgJgUgBQgRAAgLALQgLAKgBAVIAAAxIhUAAIAAgvQAAgkARgcQARgeAcgRQAdgRAhgBQAsAAAcAWQAcAUANAhQANAiAAAoQAAAbgCATQgCASgGARQgFARgOAZIh6DvICXAAIAABVgAgYV4IAAn2IhVA/IAAhaIBVg+IBSAAIAAJPgAg9KOQgcgPgSgdQgRgcAAgnIAAlbQAAgnARgcQASgdAcgPQAdgQAgAAQAiAAAcAQQAcAPASAdQARAcABAnIAAFbQgBAngRAcQgSAdgcAPQgcAQgiAAQggAAgdgQgAgcCmQgLAMgBASIAAFbQABATALALQALAMARAAQASAAALgMQAMgLAAgTIAAlbQAAgSgMgMQgLgMgSAAQgRAAgLAMgAhehEIBej4IAAgBIgMAEQgJADgOAAQgXgBgSgLQgTgKgLgRQgHgKgEgOQgFgPgBgaQgBgaAAguQAAgmABgWQABgWAFgMQAEgNAIgNQAQgcAcgPQAbgPAiAAQAiABAbAOQAcAPARAcQAIANAEANQAEAMACAWQACAWAAAmQAAAkgCAVQgCAUgDAPQgDAOgGAPIhuEpgAgbo4QgMAMgBATIAABuQABAUAMAKQAMAMAPAAQAQAAAMgMQANgKAAgUIAAhuQAAgTgNgMQgMgLgQAAQgPAAgMALgAg9stQgagPgOgWQgJgMgFgOQgFgOgCgVQgCgWAAgjQgBgtADgaQACgaAJgRQAJgRAUgPQgUgPgJgQQgJgQgCgWQgDgWABgjQAAggACgTQAEgVAHgNQAGgPALgNQARgWAZgMQAZgMAbAAQAcAAAZAMQAZAMARAWQALANAHAPQAHANADAVQADATAAAgQAAAjgCAWQgCAWgKAQQgJAQgTAPQATAPAJARQAKARACAaQACAaAAAtQAAAjgCAWQgDAVgFAOQgFAOgIAMQgPAWgaAPQgZAPglAAQgjAAgagPgAgbwuQgMALgBATIAAB0QABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAh0QAAgTgNgLQgMgMgQAAQgPAAgMAMgAgb0WQgMALgBATIAABVQABATAMALQAMALAPABQAQgBAMgLQANgLAAgTIAAhVQAAgTgNgLQgMgLgQgBQgPABgMALgAhp4CICSn/IhbAAIAABEIhKAAIAAiUID6AAIAABVIiOH6gEgA8gjsQgcgPgRgaQgIgNgEgNQgEgOgCgVQgBgWAAgmQAAgjABgWQACgVADgOQAEgOAFgPIBtkpIBfAAIhfD4IAAACQAFgDAIgDQAJgBAOAAQAXAAASAKQAUALAKAQQAIAMAEAOQAEAOABAaQACAaAAAuQAAAmgCAWQgBAVgFAOQgEANgHANQgRAcgcAOQgbAPgjAAQghAAgbgQgEgAbgnoQgMAMgBATIAABuQABATAMAMQAMALAPAAQAQAAAMgLQANgMAAgTIAAhuQAAgTgNgMQgMgKgQgBQgPABgMAKgEgA9gvKQgdgQgRgcQgRgcgBgoIAAgZIBVAAIAAAVQAAAXAMAMQAMALARAAQATAAAKgLQALgMAAgVIAAiKQAAgTgLgLQgLgMgSgBQgMAAgJAHQgJAGgEAGIgHAOIhLAAIAAk/IDxAAIAABQIimAAIAACfQAMgMASgHQAQgIAWAAQAsAAAbAbQAaAaABAzIAACZQgBAogRAcQgSAcgcAQQgcAPgiAAQghAAgcgPgEAAVg6fIAAhYIimAAIAAhQIB6mnIBYAAIh+GnIBSAAIAAioIBVAAIAACoIAoAAIAABQIgoAAIAABYgEgA3hGFQgdgNgUgcQgUgbAAguIAAgwIBUAAIAAAsQAAATALANQALANASAAQATAAALgNQALgMAAgXIAAhUQABghgOgMQgOgLgmABIAAhLQAjABAPgKQAPgLAAgfIAAhNQAAgSgLgMQgLgLgTAAQgVABgJANQgKANAAAOIAAAxIhUAAIAAgyQAAgjARgcQARgcAdgRQAdgQAhgBQAjABAXANQAXANALAPQAMAMAHAPQAHAPADAXQAEAXAAAlQAAAogDAWQgDAWgMANQgLANgYAOQAaAPALAPQALAQADAXQACAYAAAqQAAAmgCAWQgCAWgFANQgFAOgJAMQgPAXgaAPQgZAQglAAIgBAAQgbAAgbgMgEgB8hRdIAAhQICWkgQALgUACgRQACgRAAgYQAAgPgCgPQgBgPgJgKQgJgJgUgBQgRAAgLALQgLALgBAUIAAAwIhUAAIAAgvQAAgjARgcQARgeAcgRQAdgSAhAAQAsABAcAUQAcAVANAhQANAiAAAoQAAAcgCASQgCASgGARQgFARgOAZIh6DwICXAAIAABUgEgAYhc8IAAn1IhVA+IAAhZIBVg/IBSAAIAAJPgEgA9homQgcgPgSgcQgRgdAAgnIAAlbQAAgnARgcQASgdAcgQQAdgPAgAAQAiAAAcAPQAcAQASAdQARAcABAnIAAFbQgBAngRAdQgSAcgcAPQgcAQgiAAQggAAgdgQgEgAchwOQgLAMgBASIAAFbQABASALAMQALAMARAAQASAAALgMQAMgMAAgSIAAlbQAAgSgMgMQgLgMgSAAQgRAAgLAMg");
	this.shape.setTransform(98.5,748.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(55,0,621.2,1476.3);


(lib.t1d = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ACsAmIAAgeIgfAAIAAAeIgQAAIAAhLIAQAAIAAAgIAfAAIAAggIASAAIAABLgAArAmIAAg8IgWAAIAAgPIA9AAIAAAPIgWAAIAAA8gAglAmIAAhLIARAAIAABLgAhzAmIgRg0IgRA0IgMAAIgbhLIATAAIAOArIAOgrIASAAIANArIAQgrIASAAIgbBLg");
	this.shape.setTransform(-57,9.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-76,1,38,17.4);


(lib.t1c = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEbAaIAKgNQANALAKAAQAFAAADgCQADgCAAgEQAAgDgDgCQgDgCgJgCQgNgDgGgEQgGgFAAgLQAAgLAHgFQAIgGAMAAQAIAAAHACQAIADAGAFIgJAMQgKgHgLAAQgEAAgCACQgDACAAADQAAADADACQADACALADQALADAGADQAGAGAAAKQAAAKgHAHQgIAGgNAAQgSAAgPgNgAA3AcQgMgMAAgQQAAgQAMgLQAMgLARAAQARAAALALQAMALAAAQQAAAQgMAMQgLALgRAAQgRAAgMgLgABEgQQgHAHAAAJQAAAKAHAHQAGAHAKAAQAJAAAHgHQAHgHAAgKQAAgJgHgHQgHgHgJAAQgKAAgGAHgAlMAcQgLgMAAgQQAAgQALgLQAMgLARAAQARAAAMALQAMALAAAQQAAAQgMAMQgMALgRAAQgRAAgMgLgAk/gQQgHAHAAAJQAAAKAHAHQAHAHAJAAQAKAAAGgHQAHgHAAgKQAAgJgHgHQgGgHgKAAQgJAAgHAHgADfAmIglguIAAAuIgRAAIAAhLIAQAAIAmAwIAAgwIARAAIAABLgAgQAmIAAhLIAQAAIAABLgAhiAmIAAg8IgWAAIAAgPIA9AAIAAAPIgWAAIAAA8gAjaAmIAAhLIAbAAQASAAAIAHQAIAHAAAOQAAANgIAGQgIAHgRAAIgLAAIAAAVgAjJACIAMAAQAIAAAEgCQADgDAAgHQAAgGgEgDQgEgDgJAAIgKAAg");
	this.shape.setTransform(-41.5,9.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-76,1,69,17.4);


(lib.t1b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ADzAmIAAgeIgbgtIATAAIAQAdIARgdIASAAIgaAtIAAAegACjAmIgRgZIgMAAIAAAZIgRAAIAAhLIAdAAQASAAAHAGQAIAGAAANQAAARgPAFIAUAcgACGAAIAMAAQAJAAADgCQAEgDAAgHQAAgGgEgCQgDgCgIAAIgNAAgAA7AmIgHgRIggAAIgHARIgQAAIAfhLIARAAIAhBLgAAbAHIATAAIgKgVgAg7AmIglguIAAAuIgRAAIAAhLIAQAAIAmAvIAAgvIARAAIAABLgAizAmIAAhLIARAAIAABLgAkdAmIAAhLIAeAAQAHAAAGACQAGACADADQAFAGAAAIQAAAJgGAEIgDACIgDABQAIAAAEAEQAEAGAAAHQAAAHgFAHQgHAHgQAAgAkMAYIAMAAQAHgBAEgCQADgBAAgFQAAgGgEgBQgDgCgJAAIgKAAgAkMgGIAIAAQAHAAAEgBQADgCAAgFQAAgFgDgCQgDgCgIAAIgIAAg");
	this.shape.setTransform(-23,9.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-51.6,1,57.4,17.4);


(lib.t1a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("AC/AmIAAhLIA4AAIAAAPIgnAAIAAAQIAjAAIAAANIgjAAIAAAQIAoAAIAAAPgABNAmIAAhLIAbAAQAUAAALAKQALAKAAARQAAARgKAKQgLALgWAAgABeAXIALAAQAMAAAGgGQAGgGAAgLQAAgJgGgHQgGgGgOAAIgJAAgAATAmIgHgRIgeAAIgHARIgSAAIAhhLIAPAAIAhBLgAgLAHIARAAIgIgVgAhhAmIgRgZIgMAAIAAAZIgRAAIAAhLIAdAAQASAAAHAGQAIAGAAANQAAARgPAFIAUAcgAh+AAIAMAAQAJAAADgCQAEgDAAgHQAAgGgEgCQgDgCgIAAIgNAAgAjhAmIAAg8IgWAAIAAgPIA9AAIAAAPIgWAAIAAA8g");
	this.shape.setTransform(-7.7,9.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-32.5,1,49.7,17.4);


(lib.Symbol1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQEaQgRgRAAgdIAAg1QAAgfARgSQASgSAigBQAgABATASQATASAAAfIAAA1QAAAdgTARQgTASggAAQgiAAgSgSgAA1CrQgGAHAAAJIAAApQAAAKAGAFQAGAHAJAAQAIAAAGgHQAGgFAAgKIAAgpQAAgJgGgHQgGgFgIgBQgJABgGAFgAh/EnIDIpNIA3AAIjJJNgAh2iEQgTgQAAgdIAAg2QAAgfATgSQASgSAhgBQAhABATASQARASAAAfIAAA2QAAAdgRAQQgTARghABQghgBgSgRgAhRjyQgGAFgBAKIAAApQABAJAGAHQAGAGAIAAQAJAAAGgGQAGgHAAgJIAAgpQAAgKgGgFQgGgHgJAAQgIAAgGAHg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-13.8,-30,27.8,60.1);


(lib.logo_mc = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AgeApQgeAAgGgBQgLgBgDgGQgGgDgBgKIgBgUIAAgOIACgIQACgIAGgEQAHgFAQgBIAYgBQAeAAAGABQAMADADAFQAFAGACAJIABASQgBASgDAIQgDAHgGADIgKADIgNABgAgygUQgHABgDAFQgCAEAAAKQAAALACAEQADAEAIACIASABQAUAAAFgBQAFgCABgDQABgDAAgGIABgHQAAgKgCgEQAAgDgCgCQgDgBgFAAIgUAAIgUAAgAjDApIAAhRIAbAAIAAA9IBHAAIAAAUgAB/ApIgQgyIgQAyIgkAAIgfhRIAcAAIAVA3IASg3IAiAAIARA3IAVg3IAdAAIggBRg");
	this.shape.setTransform(41.6,3.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2E").s().p("AAPAqQgYAAgGgBQgLgDgEgFQgFgFgBgKIAAgRIAAgSQACgKAGgGQAGgFASgCIAYgBQAdAAAHADQAMACAEAJQACAEAAAMIgaAAQAAgEgBgDQgDgDgHAAIgnABQgFABgBADQgCAEAAANQAAAMABADQABAFAIAAIAOACIAYAAQAJgCABgFIAAgGIghAAIAAgOIA7AAIAAAKQAAARgCAFQgDAHgEADQgGADgLABgACoApIAAggIg8AAIAAAgIgaAAIAAhRIAaAAIAAAfIA8AAIAAgfIAaAAIAABRgAhHApIAAhRIAbAAIAABRgAhrApIAAggIg7AAIAAAgIgbAAIAAhRIAbAAIAAAfIA7AAIAAgfIAbAAIAABRg");
	this.shape_1.setTransform(-5.4,-0.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E1E0DF").s().p("AAABGIjhAnIAAiyIDhgnIDiAnIAACyg");
	this.shape_2.setTransform(-5.3,-0.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6B6B6A").s().p("AjhBGIAAizIDhAoIDigoIAACzIjiAog");
	this.shape_3.setTransform(41.3,3.3);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-28,-11.8,92,26.2);


(lib.gbcurve = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EghpAD6Qgrj2Arj9MBDoAAAIAAHzg");
	this.shape.setTransform(114.4,25);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-103.2,0,435.2,50);


(lib.bgimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg111();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,320,50);


(lib._bg = function() {
	this.initialize();

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape.setTransform(160,25);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,320,50);


(lib._clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_46 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(46).call(this.frame_46).wait(1));

	// t3c
	this.instance = new lib.t3c();
	this.instance.setTransform(156,25,1,0.025);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).to({scaleY:1},4,cjs.Ease.get(0.9)).wait(40));

	// t3b
	this.instance_1 = new lib.t3b();
	this.instance_1.setTransform(238.2,28.8,1,1,0,0,0,96.2,13.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({x:225.2,alpha:1},7,cjs.Ease.get(0.9)).wait(35));

	// t3a
	this.instance_2 = new lib.t3a();
	this.instance_2.setTransform(99.8,28.8,1,1,0,0,0,62.8,13.8);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:79.8,alpha:1},7,cjs.Ease.get(0.9)).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(65.4,18.4,95.7,15.6);


(lib.t2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_49 = function() {
		this.stop();
		exportRoot.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(1));

	// t2.2
	this.instance = new lib.t22();
	this.instance.setTransform(236.5,22.1,1,1,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(33).to({_off:false},0).wait(1).to({regX:99.6,regY:34.3,x:298.2,y:45.3,alpha:0.344},0).wait(1).to({x:268.3,alpha:0.616},0).wait(1).to({x:246.3,alpha:0.816},0).wait(1).to({x:232.2,alpha:0.944},0).wait(1).to({regX:0,regY:11.1,x:126.5,y:22.1,alpha:1},0).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
		exportRoot.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQEbQgRgSAAgcIAAg2QAAggARgSQASgRAigBQAgABATARQATASAAAgIAAA2QAAAcgTASQgTAQggABQgigBgSgQgAA1CrQgGAGAAAKIAAAqQAAAIAGAGQAGAHAJAAQAIAAAGgHQAGgGAAgIIAAgqQAAgKgGgGQgGgFgIgBQgJABgGAFgAh/EnIDIpNIA3AAIjJJNgAh2iEQgTgRAAgcIAAg2QAAgfATgSQASgTAhAAQAhAAATATQARASAAAfIAAA2QAAAcgRARQgTASghAAQghAAgSgSgAhRjzQgGAHgBAJIAAApQABAKAGAFQAGAHAIAAQAJAAAGgHQAGgFAAgKIAAgpQAAgJgGgHQgGgFgJgBQgIABgGAFg");
	this.shape.setTransform(189.1,45.2);

	this.instance = new lib.Symbol1();
	this.instance.setTransform(220.1,45.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape,p:{x:189.1}}]},1).to({state:[{t:this.shape,p:{x:206.1}}]},16).to({state:[{t:this.instance}]},8).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance}]},5).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25).to({_off:false},0).wait(3).to({x:95.1},5,cjs.Ease.get(0.9)).wait(12));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9EdQgcgQgSgcQgRgcgBgoIAAlZQABgnARgdQASgcAcgQQAdgPAgAAQAiAAAcAPQAcAQARAcQASAdAAAnIAAFZQAAAogSAcQgRAcgcAQQgcAPgiAAQggAAgdgPgAgcjKQgMAMAAASIAAFZQAAASAMAMQALAMARAAQASAAALgMQAMgMAAgSIAAlZQAAgSgMgMQgLgLgSgBQgRABgLALg");
	this.shape_1.setTransform(66,44.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9EcQgcgPgSgdQgRgcAAgnIAAlZQAAgnARgcQASgdAcgPQAcgQAhAAQAhAAAdAQQAcAPASAdQARAcABAnIAAFZQgBAngRAcQgSAdgcAPQgdAQghAAQghAAgcgQgAgcjKQgLAMgBASIAAFZQABATALALQALAMARAAQARAAAMgMQALgLAAgTIAAlZQAAgSgLgMQgMgLgRgBQgRABgLALg");
	this.shape_2.setTransform(34.5,45.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah9EqIAAhQICXkeQAKgVACgRQADgRAAgXQAAgPgCgPQgBgPgKgLQgIgJgUAAQgRgBgLALQgMALAAAVIAAAwIhVAAIAAgvQABgjARgdQAQgdAdgSQAdgRAhgBQAsABAbAVQAdAUANAiQANAhgBAoQABAcgCASQgCASgGARQgGARgNAZIh6DuICWAAIAABVg");
	this.shape_3.setTransform(2.8,44.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},34).wait(11));

	// 1
	this.instance_1 = new lib.t2roll();
	this.instance_1.setTransform(163,708.1,1,1,0,0,0,71,640);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({y:634.4},2).wait(1).to({y:-100.4},0).wait(1).to({regX:98.5,regY:748.2,x:147.5,y:7.8},0).wait(1).to({x:113.5},0).wait(1).to({x:88.5},0).wait(1).to({x:72.5},0).wait(1).to({regX:71,regY:640,x:38,y:-100.4},0).to({_off:true},1).wait(11));

	// 10
	this.instance_2 = new lib.t2roll();
	this.instance_2.setTransform(148,655.6,1,1,0,0,0,71,640);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(17).to({_off:false},0).to({y:-388.4},6).to({y:-562.4},1).wait(1).to({x:131.6,y:-100.4},0).wait(4).to({regX:98.5,regY:748.2,x:116.1,y:7.8},0).wait(1).to({x:82.1},0).wait(1).to({x:57.1},0).wait(1).to({x:41.1},0).wait(1).to({regX:71,regY:640,x:6.6,y:-100.4},0).to({_off:true},1).wait(11));

	// 100
	this.instance_3 = new lib.t2roll();
	this.instance_3.setTransform(131,635,1,1,0,0,0,71,640);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).wait(7).to({x:128.6,y:665.6},0).to({x:131,y:-759.4},8).wait(1).to({x:116.6,y:-246.4},0).wait(8).to({x:100.6,y:-247.4},0).wait(4).to({regX:98.5,regY:748.2,x:85.1,y:-139.2},0).wait(1).to({x:51.1},0).wait(1).to({x:26.1},0).wait(1).to({x:10.1},0).wait(1).to({regX:71,regY:640,x:-24.4,y:-247.4},0).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// t1d
	this.instance = new lib.t1d();
	this.instance.setTransform(-44,-2.9,1,1,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1c
	this.instance_1 = new lib.t1c();
	this.instance_1.setTransform(-123,-2.9,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1b
	this.instance_2 = new lib.t1b();
	this.instance_2.setTransform(-214,-2.9,1,1,0,0,0,0,11.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1a
	this.instance_3 = new lib.t1a();
	this.instance_3.setTransform(-293,-2.9,1,1,0,0,0,0,11.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{on:1,off:7});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6).call(this.frame_6).wait(6).call(this.frame_12).wait(1));

	// GET STARTED
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C2F35").s().p("AC9AcQgLgMAAgQQAAgQALgLQAMgLARAAQASAAALALQAMALAAAQQAAAQgMAMQgLALgSAAQgRAAgMgLgADLgQQgIAHABAJQgBAKAIAHQAGAHAJAAQAKAAAGgHQAIgHgBgKQABgJgIgHQgGgHgKAAQgJAAgGAHgABhAcQgLgLAAgRQAAgQALgLQAMgLAQAAQARAAAMAKIgJANQgFgEgEgCQgFgCgFAAQgKAAgGAHQgHAHABAJQAAALAFAGQAHAHAJAAQAJAAAGgEIAAgUIARAAIAAAaQgLANgVAAQgQAAgMgLgAggAaIAKgNQANALAJAAQAEAAADgCQACgCAAgEQAAgDgCgCQgDgCgHgCQgNgDgHgEQgFgFAAgLQAAgLAHgFQAIgGAMAAQAFAAAIACQAIADAFAFIgIAMQgKgHgJAAQgEAAgDACQgCACAAADQAAADADACQADACAJADQALADAGADQAGAGAAAKQAAAKgIAHQgIAGgLAAQgSAAgOgNgAhYAmIAAg8IgWAAIAAgPIA9AAIAAAPIgWAAIAAA8gAi6AmIAAhLIA4AAIAAAQIgnAAIAAAPIAjAAIAAANIgjAAIAAAQIAoAAIAAAPgAkCAmIAAhLIARAAIAAA8IAhAAIAAAPg");
	this.shape.setTransform(-57,26.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13));

	// gb-curve
	this.instance = new lib.gbcurve();
	this.instance.setTransform(150,134.8,1,1,0,0,0,150,134.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},6).to({alpha:1},6).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F0F0F0").s().p("EghpAD6Qgrj2Arj9MBDoAAAIAAHzg");
	this.shape_1.setTransform(114.4,25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103.2,0,435.2,50);


// stage content:
(lib.highlow_320x501b_GBP = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.enableMouseOver(20);
		
		this.loopNumber = 0 ;
		
		// CLICKTHROUGH
		this.clickTagBtn.addEventListener("click", function () {
			console.log("clickthrough");
			window.open(window.clickTAG);
		});
		
		// CTA
		this.clickTagBtn.addEventListener("mouseover", function () {
			exportRoot.bt.gotoAndPlay("on");
		});
		
		this.clickTagBtn.addEventListener("mouseout", function () {
			exportRoot.bt.gotoAndPlay("off");
		});
	}
	this.frame_56 = function() {
		this.stop();
	}
	this.frame_200 = function() {
		if(this.loopNumber >= 1){
			console.log("STOP BANNER");
			this.stop();
		} else {
			this.loopNumber++;
			console.log("RESTART: " + this.loopNumber);
		}
	}
	this.frame_207 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(56).call(this.frame_56).wait(144).call(this.frame_200).wait(7).call(this.frame_207).wait(1));

	// clickTagBtn
	this.clickTagBtn = new lib._clicktag();
	this.clickTagBtn.setTransform(0,0,2,0.083);
	new cjs.ButtonHelper(this.clickTagBtn, 0, 1, 2, false, new lib._clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickTagBtn).wait(208));

	// Border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("A4/j5MAx/AAAIAAHzMgx/AAAg");
	this.shape.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(208));

	// bt
	this.bt = new lib.btn();
	this.bt.setTransform(685,149.5,1,1,0,0,0,150,149.5);

	this.timeline.addTween(cjs.Tween.get(this.bt).wait(162).to({x:485,y:149.6,alpha:0},0).to({alpha:1},7).wait(32).to({x:685,y:149.5},6,cjs.Ease.get(-0.9)).wait(1));

	// t6
	this.instance = new lib.t6();
	this.instance.setTransform(239.1,58.1,1,1,0,0,0,0,12.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(158).to({_off:false},0).to({alpha:1},6).wait(37).to({x:-250.9},6,cjs.Ease.get(-0.9)).wait(1));

	// t5
	this.instance_1 = new lib.t5();
	this.instance_1.setTransform(240.3,35.1,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(155).to({_off:false},0).to({alpha:1},6).wait(40).to({x:-249.7},6,cjs.Ease.get(-0.9)).wait(1));

	// logo
	this.instance_2 = new lib.logo_mc();
	this.instance_2.setTransform(110.5,42.8,1,1,0,0,0,64.5,18.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(151).to({_off:false},0).to({alpha:1},7).wait(43).to({x:-379.5},6,cjs.Ease.get(-0.9)).wait(1));

	// t4
	this.instance_3 = new lib.t3();
	this.instance_3.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(64).to({_off:false},0).wait(45).to({y:349},8,cjs.Ease.get(0.9)).to({_off:true},1).wait(90));

	// bg
	this.instance_4 = new lib.gbcurve();
	this.instance_4.setTransform(90.8,-15.5,0.68,1.409,0,0.8,0);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(62).to({_off:false},0).wait(1).to({scaleX:0.74,scaleY:1.35,skewX:0,x:74.8,y:-10.5},0).wait(1).to({regX:150,regY:134.8,scaleX:1,scaleY:1,x:228.5,y:134.8},0).wait(45).to({x:246.5},0).to({x:581},8,cjs.Ease.get(0.9)).wait(26).to({x:591},0).to({x:485},10,cjs.Ease.get(-1)).to({_off:true},16).wait(39));

	// bg
	this.instance_5 = new lib.gbcurve();
	this.instance_5.setTransform(591,134.8,1,1,0,0,0,150,134.8);
	this.instance_5._off = true;
	this.instance_5.filters = [new cjs.ColorFilter(0, 0, 0, 1, 63, 63, 63, 0)];
	this.instance_5.cache(-105,-2,439,54);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(143).to({_off:false},0).to({x:240.5},10,cjs.Ease.get(-1)).wait(48).to({x:150.5},0).to({alpha:0},6).wait(1));

	// web-img
	this.instance_6 = new lib.webimg();
	this.instance_6.setTransform(132,70,1,1,0,0,0,132,70);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(109).to({_off:false},0).to({y:19},44).to({_off:true},1).wait(54));

	// t2
	this.instance_7 = new lib.t2copy();
	this.instance_7.setTransform(148.9,64.1,0.488,0.488,0,0,0,150,125);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(38).to({_off:false},0).wait(19).to({scaleX:8.77,scaleY:8.77,x:-86,y:727.1},4,cjs.Ease.get(-1)).to({_off:true},1).wait(146));

	// 320x50_mask
	this.instance_8 = new lib._320x50_mask();
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(42).to({_off:false},0).to({_off:true},15).wait(151));

	// t2
	this.instance_9 = new lib.t2();
	this.instance_9.setTransform(148.9,124.1,0.488,0.488,0,0,0,150,125);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(38).to({_off:false},0).to({y:104.1},4,cjs.Ease.get(-0.9)).to({y:64.1},4,cjs.Ease.get(0.9)).wait(11).to({scaleX:8.77,scaleY:8.77,x:-86,y:727.1},4,cjs.Ease.get(-1)).to({_off:true},1).wait(146));

	// t1
	this.instance_10 = new lib.t1();
	this.instance_10.setTransform(364.5,69.5,1,1,0,0,0,0,38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(38).to({y:39.5},4,cjs.Ease.get(-0.9)).to({y:-0.5},4,cjs.Ease.get(0.9)).to({_off:true},1).wait(161));

	// bg
	this.instance_11 = new lib.bgimg();
	this.instance_11.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(208));

	// bg
	this.instance_12 = new lib._bg();
	this.instance_12.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(208));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(159,24,868,52);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;