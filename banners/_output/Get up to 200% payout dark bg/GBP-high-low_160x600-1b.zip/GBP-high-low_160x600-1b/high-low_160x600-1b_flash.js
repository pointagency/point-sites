(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 160,
	height: 600,
	fps: 18,
	color: "#FFFFFF",
	manifest: [
		{src:"images/_160x600_mask.png", id:"_160x600_mask"},
		{src:"images/bg11.jpg", id:"bg11"},
		{src:"images/web11.png", id:"web11"}
	]
};



// symbols:



(lib._160x600_mask = function() {
	this.initialize(img._160x600_mask);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.bg11 = function() {
	this.initialize(img.bg11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.web11 = function() {
	this.initialize(img.web11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,499,286);


(lib.webimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.web11();
	this.instance.setTransform(0,120);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,120,499,286);


(lib.t6 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AF2CWQgKgMAAgTIAAgCQAAgTAKgMQAKgMATAAQAQAAAKAJQAJAJAAAPIgVAAQAAgHgEgEQgEgEgGAAQgJAAgDAHQgFAHAAALIAAACQAAALAFAHQADAHAJAAQAGAAAEgDQAEgEAAgGIAVAAIAAABQAAANgKAIQgKAJgPAAQgTAAgKgMgAEdCbQgHgHAAgMQAAgMAJgHQAKgHASAAIANAAIAAgGQAAgGgDgEQgDgDgHAAQgFAAgDADQgDACAAAFIgWAAIAAgBQgBgKAKgIQAKgIAQAAQAPAAAJAIQAKAIAAAOIAAAjIABALQABAFACAFIgXAAIgDgMQgEAGgGAEQgFAEgJAAQgNAAgHgHgAEwB/QgDADAAAGQAAAEACACQADADAFAAQAGAAAEgDQAFgDACgEIAAgMIgNAAQgHAAgEAEgADfCfQgGgDgDgGIgCAKIgTAAIAAh6IAWAAIAAAvQADgFAGgDQAFgDAGAAQARAAAIAMQAIAMAAAVIAAABQAAATgIAMQgIALgRAAQgGAAgGgDgADdBeQgEACgCAEIAAAkQACAEAEACQAEACAFAAQAJAAADgGQAEgGAAgMIAAgBQAAgNgEgHQgEgHgIAAQgFAAgEACgAgjCZQgKgIAAgLIAAgBIAVAAQABAHAEADQAEADAHAAQAGAAACgCQADgDAAgEQAAgEgDgDQgCgCgKgCQgPgDgIgGQgHgGgBgLQAAgLAKgHQAJgIAPAAQAPAAAJAIQAJAHAAAMIAAAAIgWAAQAAgFgCgDQgDgDgGAAQgFAAgEADQgCACAAAEQgBAEAEADQADACALACQANADAHAGQAIAGAAALQAAALgKAIQgKAHgOAAQgRAAgJgJgAh8CbQgGgHAAgMQgBgMAKgHQAKgHASAAIAMAAIAAgGQAAgGgCgEQgEgDgGAAQgFAAgDADQgDACgBAFIgWAAIAAgBQgBgKAKgIQALgIAQAAQAOAAAKAIQAKAIAAAOIAAAjIABALQAAAFACAFIgWAAIgEgMQgEAGgGAEQgFAEgIAAQgNAAgIgHgAhoB/QgEADAAAGQAAAEADACQADADAEAAQAHAAAEgDQAFgDABgEIAAgMIgMAAQgHAAgEAEgAjKCWQgLgMAAgTIAAgCQAAgTALgMQAJgMAUAAQAPAAAKAJQAKAJgBAPIgVAAQAAgHgDgEQgEgEgGAAQgKAAgDAHQgEAHAAALIAAACQAAALAEAHQADAHAKAAQAGAAAEgDQADgEAAgGIAVAAIAAABQAAANgJAIQgKAJgPAAQgTAAgKgMgAlLCWQgKgLAAgXIAAgZQAAgXAKgLQALgMARAAQASAAALAMQAKALAAAXIAAAZQAAAXgKALQgLAMgSAAQgRAAgLgMgAk7BFQgDAGAAAOIAAAdQAAAOADAGQAEAGAIAAQAIAAAEgGQAEgGAAgOIAAgdQAAgOgEgGQgEgHgIAAQgIAAgEAHgAmlCZQgLgIAAgPIABgBIAWgBQgBAIAFAEQAFAEAGAAQAIAAAEgFQAEgGAAgJQAAgKgEgGQgFgGgIAAQgGAAgEADQgDACgBAEIgVgBIAHg/IA/AAIAAASIgsAAIgDAaIAIgEQAEgBAFAAQAQgBAKAKQAIALABASQAAAQgKALQgKALgTAAQgQAAgLgJgAH2CgIgWgjIgHAAIAAAjIgXAAIAAh6IAXAAIAABGIAFAAIAVggIAaAAIgbAmIAfAugABaCgIAAgyQAAgKgDgEQgEgEgHAAQgEAAgEABIgGAFIAAA+IgXAAIAAh6IAXAAIAAAwQAEgFAGgEQAFgDAIAAQANAAAIAJQAHAJAAASIAAAygAoLCgIAAgRIABAAQAEgBACgHQACgGAAgHIgBgIIgNAAIAAgRIANAAIgBgRQAAgQAJgKQAJgJARAAQAQAAAJAJQAJAIAAAPIAAAAIgWAAQAAgHgDgEQgEgEgGAAQgFAAgDAFQgEAFAAAIIABARIAcAAIAAARIgbAAIAAAHQAAAGgCAGQgDAFgEAFIA4AAIAAARgACCB4IAAgRIAsAAIAAARgAGKgsQgHgHAAgMQAAgMAJgHQAKgHASAAIANAAIAAgGQAAgGgDgEQgDgDgHAAQgFAAgDADQgDACAAAFIgWAAIAAgBQgBgKAKgIQAKgIAQAAQAPAAAJAIQAKAIAAAOIAAAjIABALQABAFACAFIgXAAIgDgMQgEAGgGAEQgFAEgJAAQgNAAgHgHgAGdhIQgDADAAAGQAAAEACACQADADAFAAQAGAAAEgDQAFgDACgEIAAgMIgNAAQgHAAgEAEgAEUgxQgLgMAAgSIAAgDQAAgTAKgMQAKgMASAAQARAAAJAKQAKALAAARIAAANIgzAAIAAAAQABAJAFAFQAEAFAJAAQAHAAAGgBIAKgFIAHAOQgFAEgJADQgIADgLAAQgRAAgLgMgAElhmQgEAEgBAIIAAABIAcAAIAAgCQAAgIgDgEQgEgEgGAAQgHAAgDAFgABDgxQgLgMAAgSIAAgDQAAgTALgMQAJgMASAAQASAAAJAKQAJALAAARIAAANIgzAAIAAAAQABAJAFAFQAFAFAIAAQAIAAAFgBIALgFIAHAOQgGAEgIADQgJADgKAAQgSAAgLgMgABUhmQgDAEgCAIIABABIAcAAIAAgCQAAgIgDgEQgEgEgHAAQgGAAgEAFgAgQgxQgJgMgBgTIAAgCQABgTAJgMQAKgMASAAQAPAAAKAJQAKAJgBAPIgVAAQAAgHgDgEQgEgEgGAAQgKAAgCAHQgDAHAAALIAAACQAAALADAHQACAHAKAAQAGAAAEgDQADgEAAgGIAVAAIAAABQABANgLAIQgJAJgPAAQgRAAgLgMgAhigxQgLgMAAgSIAAgDQAAgTAKgMQAKgMASAAQARAAAJAKQAKALAAARIAAANIgyAAIAAAAQAAAJAFAFQAFAFAJAAQAHAAAFgBIALgFIAGAOQgFAEgIADQgJADgKAAQgSAAgLgMgAhRhmQgEAEAAAIIAAABIAcAAIAAgCQAAgIgEgEQgDgEgHAAQgGAAgEAFgAkfgxQgIgLgBgTIAAgBQABgUAIgNQAJgMAQAAQAGAAAFADQAFADAEAFIAAgvIAXAAIAAB6IgTAAIgDgKQgEAGgFADQgGADgGAAQgQAAgJgMgAkNhkQgDAIAAAMIAAABQgBAMAEAGQAEAGAJAAQAFAAADgCQADgCADgEIAAgkQgDgEgDgCQgDgCgFAAQgJAAgEAHgAnRgsQgGgHAAgMQAAgMAJgHQAKgHASAAIAMAAIAAgGQAAgGgCgEQgEgDgGAAQgFAAgDADQgDACAAAFIgXAAIAAgBQgBgKAKgIQALgIAPAAQAQAAAJAIQAKAIAAAOIAAAjIABALQAAAFACAFIgWAAIgEgMQgDAGgHAEQgFAEgIAAQgNAAgIgHgAm9hIQgEADAAAGQAAAEADACQACADAFAAQAHAAAEgDQAFgDABgEIAAgMIgMAAQgIAAgDAEgADPgnIgdhUIAYAAIAOA1IACAIIABAAIAOg9IAZAAIgdBUgACQgnIAAhUIAXAAIAABUgAiignIAAhUIAVAAIABAMQADgGAEgEQAGgEAGAAIADAAIACABIgCAUIgIAAQgFAAgEACQgDACgBAEIAAA5gAlMgnIAAg1QABgIgEgEQgDgDgHAAQgEAAgEACQgEABgDAEIAAA9IgWAAIAAhUIAVAAIABAMQAFgHAFgDQAHgEAIAAQAMAAAHAIQAIAIAAARIAAA1gACQiQIAAgRIAXAAIAAARg");
	this.shape.setTransform(2.5,24.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-53.3,2,110.6,45.2);


(lib.t5 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("AC6ApQgNgMAAgXIAAg4IAYAAIAAA3QAAANAFAHQAGAIAKgBQAKABAGgIQAGgHAAgNIAAg3IAXAAIAAA4QAAAXgNAMQgMAMgUAAQgTAAgNgMgAiyAnQgQgQAAgXQAAgWAQgPQAQgPAXgBQAWAAARAPIgMARQgHgFgGgDQgGgCgHAAQgNAAgKAJQgJAJAAANQAAAOAJAJQAJAKAMgBQAMAAAIgEIAAgcIAYAAIAAAlQgQAQgbAAQgYAAgPgOgAmPAjIAOgRQARAPAOAAQAGAAAEgDQAEgDAAgFQAAgEgEgDQgEgDgMgCQgSgFgIgFQgJgGAAgPQAAgPALgJQALgHAQgBQAKAAALAEQAKAEAIAGIgMARQgOgKgOAAQgGAAgDACQgEADAAAFQAAAFAEACQAFADAOADQAPAEAJAGQAIAHAAAOQAAAOgLAJQgKAJgSgBQgYAAgUgSgAE9A0IAAhmIAlAAQAYAAALAJQALAKAAATQAAARgLAJQgLAKgYgBIgNAAIAAAdgAFVADIAPAAQAMAAAEgDQAEgFAAgIQAAgJgFgFQgGgDgLAAIgNAAgAAaA0Igwg/IAAA/IgXAAIAAhmIAWAAIAxBBIAAhBIAXAAIAABmgAkKA0IAAhmIAXAAIAABmg");
	this.shape.setTransform(0.5,11.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-39.6,0,80.2,22.3);


(lib.t3c = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#EE683A").ss(1,0,1).p("Ai4AAIFxAA");
	this.shape.setTransform(0.5,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AFpC3QgKgJAAgMIABgBIAQAAQAAAJAHAFQAGAEAJAAQAJAAAFgEQAGgDAAgHQAAgFgFgEQgEgEgMgCQgSgEgIgHQgJgGAAgLQAAgMAKgIQAKgIAPAAQARAAAKAIQAKAJgBAMIAAABIgQAAQAAgHgGgEQgFgFgJAAQgJAAgEAEQgFAEAAAFQAAAGAEADQAEADAMADQASAEAJAHQAJAGAAALQAAANgKAIQgLAIgQAAQgSAAgLgKgAEwC6QgGgGAAgOIAAg6IgPAAIAAgMIAPAAIAAgXIARAAIAAAXIASAAIAAAMIgSAAIAAA6QAAAHADADQADACAEAAIAEAAIADgBIACAMQgCACgEABIgHABQgLAAgGgHgADNCzQgMgNAAgVIAAgEQAAgUANgOQAMgNAQAAQATAAAKALQAKAMAAATIAAALIg+AAIAAABQAAANAHAJQAHAJAMAAQAJAAAGgCQAHgDAFgEIAGALQgFAFgIADQgIAEgMAAQgUAAgMgOgADbBzQgGAHgBALIAAABIAsAAIAAgDQAAgKgGgHQgFgGgLAAQgJAAgGAHgAgxC5QgIgIAAgNQAAgOALgHQALgIATAAIARAAIAAgJQAAgJgDgFQgFgEgKAAQgIAAgFAEQgFAEAAAGIgRAAIAAgBQgBgKALgIQAKgJAQAAQAQAAAIAIQAKAIAAAQIAAAuIABAJIACAKIgSAAIgCgIIAAgGQgDAGgIAFQgIAFgJAAQgOAAgIgIgAghCYQgHAFAAAHQAAAHAEADQAEAEAIAAQAJAAAIgFQAHgFABgGIAAgPIgSAAQgKAAgGAFgAmdCzQgLgOAAgVIAAgCQAAgVALgNQAMgOATAAQAUAAAMAOQALANAAAVIAAACQAAAWgLANQgMAOgUAAQgTAAgMgOgAmQB1QgHAKAAAPIAAACQAAAPAHAKQAGAKAMAAQANAAAGgKQAHgKAAgPIAAgCQAAgPgHgKQgGgJgNAAQgMAAgGAJgACkC/IgfgsIgLAAIAAAsIgRAAIAAiJIARAAIAABPIALAAIAaglIAVAAIggArIAlA0gAArC/IAAhfIAQAAIABAOQAFgIAFgEQAGgEAIAAIAEAAIADABIgDAQIgJgBQgGAAgFAEQgFADgCAGIAABEgAhjC/IABhnIAAAAIgqBnIgLAAIgphnIgBAAIACBnIgRAAIAAiAIAWAAIApBoIAAAAIAphoIAWAAIAACAgAk3C/IAAhTIgPAAIAAgMIAPAAIAAgMQAAgQAIgIQAIgIAOAAIAGAAIAHACIgCANIgEgBIgFAAQgHAAgEAFQgEAEAAAJIAAAMIAUAAIAAAMIgUAAIAABTgAEigSQgIgCgGgDIAEgOQAFADAGABQAHACAHAAQAMAAAGgGQAGgFAAgMIAAgLQgFAGgGADQgHADgIAAQgSAAgKgNQgKgMAAgVIAAgCQAAgWAKgPQAKgOASAAQAJAAAHAEQAHAEAEAHIACgNIAOAAIAABgQAAASgLAKQgKAKgUAAQgHAAgIgCgAEhh/QgHAKAAAQIAAACQAAAPAGAIQAGAJANAAQAIAAAFgDQAFgEAEgHIAAgrQgEgGgFgEQgFgEgIAAQgMAAgGALgAF7hCQgMgNAAgVIAAgEQAAgVAMgNQAMgOARAAQATAAAKAMQAKAMAAATIAAALIg+AAIAAAAQAAAOAHAJQAGAIAMAAQAJAAAHgCQAGgDAFgEIAHALQgFAFgJAEQgIADgMAAQgUAAgLgNgAGJiDQgGAIgCALIAAAAIAsAAIAAgCQAAgKgFgHQgGgHgKAAQgJAAgGAHgABIg8QgHgIAAgNQAAgOALgIQALgHATAAIASAAIAAgKQAAgIgFgFQgFgFgJAAQgJAAgFAEQgFAFAAAGIgRAAIAAgBQAAgKAKgJQAKgJARAAQAQAAAKAJQAKAIAAAPIAAAuIAAAKIACAJIgSAAIgBgHIgBgHQgFAHgHAFQgIAEgJAAQgPAAgIgHgABYheQgGAGAAAHQAAAGAEAEQAEAEAIAAQAJAAAHgFQAIgFACgGIAAgQIgTAAQgLAAgGAFgAh7hCQgMgNAAgVIAAgEQAAgVAMgNQAMgOARAAQATAAAKAMQAKAMAAATIAAALIg+AAIAAAAQAAAOAHAJQAGAIAMAAQAJAAAHgCQAGgDAFgEIAHALQgFAFgJAEQgIADgMAAQgUAAgLgNgAhtiDQgGAIgCALIAAAAIAsAAIAAgCQAAgKgFgHQgGgHgKAAQgJAAgGAHgAjjhBQgKgNAAgVIAAgCQAAgWAKgPQAJgOASAAQAIAAAHADQAGAEAFAFIAAg0IARAAIAACJIgOAAIgCgLQgFAGgGAEQgHADgJAAQgRAAgKgMgAjWh/QgGAKAAAQIAAACQAAAPAGAIQAGAJAMAAQAIAAAFgDQAGgEADgGIAAgtQgDgGgGgDQgFgEgHAAQgNAAgGALgADjg3IAAg7QAAgNgFgFQgFgGgKAAQgIAAgGAEQgFAEgEAGIAABFIgRAAIAAhfIAPAAIACAOQAEgHAHgEQAIgFAJAAQAPAAAJAJQAIAJAAATIAAA8gAAGg3IAAhfIAQAAIABAOQAFgHAFgEQAGgFAIAAIAEABIADAAIgDAQIgJAAQgGAAgFADQgFADgCAGIAABEgAkVg3IAAhfIARAAIAABfgAlXg3IgahZIgCgLIAAAAIgcBkIgQAAIgfiAIASAAIATBUIADAQIAAAAIAbhkIAPAAIAbBkIABAAIAWhkIARAAIgfCAgAkViuIAAgSIARAAIAAASg");
	this.shape_1.setTransform(-0.1,36.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-49.5,0,99,62.5);


(lib.t3b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#EE683A").ss(1,0,1).p("Ai4AAIFxAA");
	this.shape.setTransform(0.5,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AB/EvQgMgNAAgVIAAgEQAAgVANgNQAMgOAQAAQATAAAKAMQAKAMAAATIAAALIg+AAIAAAAQAAAOAHAJQAHAJAMAAQAJAAAGgDQAHgDAFgDIAGALQgFAEgIAEQgIAEgMgBQgUAAgMgNgACNDvQgGAHgBALIAAABIAsAAIAAgDQAAgKgGgHQgFgGgLAAQgJgBgGAIgAhCEvQgLgOAAgVIAAgCQAAgVALgNQAMgOATgBQAUABAMAOQAJANAAAVIAAACQAAAWgJANQgMANgUAAQgTAAgMgNgAg1DxQgHAKAAAPIAAACQAAAPAHAKQAGAKAMAAQANAAAGgKQAHgKAAgPIAAgCQAAgPgHgKQgGgJgNAAQgMAAgGAJgADWE6IAAhfIAQAAIABAPQAFgIAFgEQAGgEAIgBIAEABIADAAIgDAQIgJAAQgGAAgFADQgFAEgCAFIAABEgABWE6IgfgsIgLAAIAAAsIgRAAIAAiIIARAAIAABPIALAAIAagmIAVAAIggArIAlA0gAiHE6IAAhfIAQAAIABAPQAFgIAFgEQAGgEAIgBIAEABIADAAIgDAQIgJAAQgGAAgFADQgFAEgCAFIAABEgAj2E6IAAh/IApAAQAUAAAMAIQALAJAAARQAAAJgFAGQgGAHgJADQAMADAHAJQAGAIAAANQAAARgLAJQgMAKgTgBgAjlEtIAeAAQAMAAAGgGQAHgFAAgLQAAgMgGgGQgFgHgMAAIggAAgAjlDxIAcAAQAKAAAGgGQAGgEAAgKQAAgLgHgEQgGgGgNAAIgYAAgAi+BoQgIgDgGgCIAEgOQAFACAGACQAHACAHAAQAMAAAGgGQAGgGAAgLIAAgLQgFAGgGADQgHADgIAAQgSAAgKgNQgKgMAAgVIAAgCQAAgVAKgOQAKgOASAAQAJAAAHAEQAHAEAEAGIACgMIAOAAIAABeQAAASgLAKQgKAJgUABQgHAAgIgCgAi/gEQgHAJAAAQIAAACQAAAOAGAJQAGAJANAAQAIAAAFgDQAFgFAEgGIAAgpQgEgHgFgDQgFgEgIAAQgMAAgGAKgAEqA4QgKgMAAgVIAAgCQAAgVAKgOQAKgOASAAQAIAAAGADQAHADAEAGIAAg0IASAAIAACHIgOAAIgCgMQgFAHgHADQgHAEgJAAQgRAAgKgNgAE4gEQgGAJAAAQIAAACQAAAOAGAJQAFAJANAAQAIAAAFgDQAFgEADgGIAAgrQgDgGgFgDQgGgEgHAAQgMAAgGAKgADNA3QgMgNAAgVIAAgEQAAgSANgOQAMgNAQAAQATAAAKALQAKANAAAQIAAAMIg+AAIAAAAQAAAOAHAIQAHAJAMAAQAJAAAGgCQAHgDAFgEIAGALQgFAFgIADQgIAEgMAAQgUAAgMgOgADbgHQgGAHgBAJIAAABIAsAAIAAgCQAAgIgGgHQgFgHgLAAQgJAAgGAHgACTA+QgGgGAAgNIAAg5IgPAAIAAgMIAPAAIAAgXIARAAIAAAXIASAAIAAAMIgSAAIAAA5QAAAGADADQADADAEgBIAEAAIADAAIACALQgCACgEABIgHABQgLAAgGgHgAApA+QgIgIAAgNQAAgOALgIQALgIATAAIATAAIAAgJQAAgHgFgEQgFgFgKAAQgIAAgFAEQgFAFAAAFIgRAAIAAAAQgBgKALgJQAKgJAQAAQAQAAAKAJQAKAHAAAOIAAAuIABAJIACAKIgSAAIgCgHIAAgHQgFAHgIAEQgIAFgJAAQgOAAgIgHgAA5AcQgHAFAAAIQAAAGAEAEQAEADAIAAQAJAAAIgEQAIgGACgGIAAgPIgUAAQgKAAgGAFgAhlA7QgJgKAAgVIAAg2IASAAIAAA2QAAAQAEAFQAFAGAJAAQAJAAAHgEQAGgEADgGIAAhDIARAAIAABdIgQAAIgBgOQgEAIgHADQgHAFgKAAQgPAAgJgKgAkqA3QgMgNAAgVIAAgEQAAgSAMgOQAMgNARAAQATAAAKALQAKANAAAQIAAAMIg+AAIAAAAQAAAOAHAIQAGAJAMAAQAJAAAHgCQAGgDAFgEIAHALQgFAFgJADQgIAEgMAAQgUAAgLgOgAkcgHQgGAHgCAJIAAABIAsAAIAAgCQAAgIgFgHQgGgHgKAAQgJAAgGAHgAgGBDIAAiHIAQAAIAACHgAlwBDIAAhdIAQAAIABAOQAFgHAFgFQAGgEAIAAIAEABIADAAIgDAQIgJAAQgGAAgFADQgFADgCAFIAABDgAB2iNIgFgBIACgNIADAAIAEABQAGgBADgFIAGgKIAEgKIgjheIATAAIAXBIIABAAIAXhIIAUAAIgoBuQgEAJgHAIQgGAHgMAAIgFgBgAhCi7QgJgKAAgUIAAg5IARAAIAAA5QAAAPAFAFQAEAGAKABQAJAAAGgFQAGgDADgHIAAhFIAPAAIAABfIgNAAIgBgOQgFAIgHAEQgHAFgJgBQgQABgIgLgABIizIAAiIIASAAIAACIgAAbizIAAiIIARAAIAACIgAiwizIAAh/IBUAAIAAANIhDAAIAAAsIA6AAIAAAOIg6AAIAAA4g");
	this.shape_1.setTransform(0,50.9);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-42.4,1,84.9,88.3);


(lib.t3a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAxCvQgLgOAAgVIAAgCQAAgVALgOQAMgOATAAQAUAAAMAOQALAOAAAVIAAACQAAAVgLAOQgMANgUAAQgTAAgMgNgAA+BxQgHAKAAAPIAAACQAAAPAHAKQAGAJAMAAQANAAAGgJQAHgKAAgPIAAgCQAAgPgHgKQgGgKgNAAQgMAAgGAKgAhEC2QgHgHAAgNIAAg6IgPAAIAAgNIAPAAIAAgXIASAAIAAAXIASAAIAAANIgSAAIAAA6QAAAGACADQADADAFAAIADAAIADgBIADALQgCACgEABIgIABQgKAAgGgGgAivC1QgHgIAAgNQAAgOALgIQALgHATAAIASAAIAAgKQAAgIgFgFQgFgFgJAAQgJAAgFAEQgFAFAAAGIgRAAIAAgBQAAgKAKgJQAKgJARAAQAQAAAKAJQAKAIAAAPIAAAuIAAAKIACAJIgSAAIgBgHIgBgHQgFAHgHAFQgIAEgJAAQgPAAgIgHgAifCTQgGAGAAAHQAAAGAEAEQAEAEAIAAQAJAAAHgFQAIgFACgGIAAgQIgTAAQgLAAgGAFgAFAC6IAAg5QAAgOgFgGQgEgGgKAAQgJAAgFAHQgGAGgBAJIAAA9IgRAAIAAg5QAAgNgFgGQgFgHgKAAQgHAAgGAEQgFADgCAGIAABGIgSAAIAAhfIAQAAIABANQAFgHAHgEQAHgEAJAAQAKAAAHAFQAHAEADAJQAFgIAHgFQAHgFAKAAQAPAAAIAKQAJAKAAAUIAAA5gACQC6IAAhfIAPAAIACAOQAEgHAGgEQAGgFAIAAIADABIADAAIgCAQIgJAAQgHAAgFADQgEADgDAGIAABEgAgLC6IAAhSIgPAAIAAgNIAPAAIAAgMQAAgPAIgIQAGgJAOAAIAGABIAHABIgCANIgEAAIgFgBQgHAAgEAFQgEAEAAAJIAAAMIAUAAIAAANIgUAAIAABSgAjfC6IAAiJIARAAIAACJgAlRC6IAAiAIAxAAQAVAAALALQALAKAAASQAAARgLALQgLAKgVAAIggAAIAAAzgAlAB5IAgAAQANAAAGgHQAHgHAAgKQAAgLgHgHQgGgHgNAAIggAAgACPhAQgGgGAAgOIAAg6IgPAAIAAgMIAPAAIAAgXIARAAIAAAXIASAAIAAAMIgSAAIAAA6QAAAHADADQADACAEAAIAEAAIADgBIACAMQgCACgEABIgHABQgLAAgGgHgAAshDQgKgJAAgMIABgBIAQAAQAAAJAHAFQAGAEAJAAQAJAAAFgEQAGgDAAgHQAAgFgFgEQgEgEgMgCQgSgEgIgHQgJgGAAgLQAAgMAKgIQAKgIAPAAQARAAAKAIQAKAJgBAMIAAABIgQAAQAAgHgGgEQgFgFgJAAQgJAAgEAEQgFAEAAAFQAAAGAEADQAEADAMADQASAEAJAHQAJAGAAALQAAANgKAIQgLAIgQAAQgSAAgLgKgAgwhHQgMgNAAgVIAAgEQAAgUANgOQAMgNAQAAQATAAAIALQAKAMAAATIAAALIg8AAIAAABQAAANAHAJQAHAJAMAAQAJAAAGgCQAFgDAFgEIAGALQgFAFgIADQgGAEgMAAQgUAAgMgOgAgiiHQgGAHgBALIAAABIAqAAIAAgDQAAgKgEgHQgFgGgLAAQgJAAgGAHgAing7IAAiAIApAAQAUAAAMAIQALAJAAARQAAAJgFAHQgGAGgJAEQAMACAHAJQAGAJAAAMQAAARgLAKQgMAJgTAAgAiWhJIAeAAQAMAAAGgGQAHgFAAgLQAAgLgGgHQgFgGgMAAIggAAgAiWiFIAcAAQAKAAAGgFQAGgFAAgKQAAgKgHgFQgGgGgNAAIgYAAg");
	this.shape.setTransform(0.2,25.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-37.2,-1,74.5,52.5);


(lib.t22 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ADvBLQgMgMgGgPQgFgQgBgUIAAhoIArAAIAABnQAAAWAKANQAGAHAGADQAHAEAJgBQAJABAIgEQAGgDAFgHQAGgGACgJQADgJAAgLIAAhnIAqAAIAABoQAAApgWAWQgMALgOAGQgPAFgSAAQgjAAgWgWgAANBFQgbgcAAgpQABgUAGgRQAHgRANgOQAcgcAqAAQArAAAcAcQAOAOAIARQAGARAAAUQAAAUgGASQgIARgOAOQgcAcgrAAQgqAAgcgcgAA+g3QgKAEgIAKQgRARAAAYQAAAZARARQAIAKAKAEQAKAEALAAQAZAAAQgSQAQgRAAgZQAAgYgQgRQgQgSgZAAQgLAAgKAEgAHKBfIAAiXIg1AAIAAgkICVAAIAAAkIg1AAIAACXgAiCBfIAAhLIhChwIAuAAIApBGIAohGIAuAAIhBBwIAABLgAjsBfIgRgoIhQAAIgRAoIgtAAIBRi7IAqAAIBRC7gAkOARIgXg0IgXA0IAuAAgAopBfIAAi7IBDAAQAWAAAPAFQARADAJAJQAUARAAAjQAAASgFAKQgFANgKAIQgVAQgqAAIgZAAIAAA1gAn/AGIAcAAQAWAAAIgHQADgEACgGQACgHAAgHQAAgRgKgHQgKgGgUgBIgZAAg");
	this.shape.setTransform(-1.2,18.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-61,0,118.1,37);


(lib.t2roll = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgCcC/gICdmdIgBgCQgHAEgOAEQgPAEgXAAQglgBgfgRQgggSgSgcQgMgSgHgXQgHgYgCgsQgDgrAAhNQAAg+ADglQACgjAIgXQAGgVANgWQAcguAugYQAtgZA5AAQA5ABAtAZQAuAZAdAsQANAWAHAVQAHAXADAjQADAlAAA+QAAA8gDAjQgDAjgFAXQgGAYgKAZIi3HugEgAuCyhQgUATgBAgIAAC3QABAgAUATQAUASAaABQAcgBAUgSQAUgTABggIAAi3QgBgggUgTQgUgSgcgBQgaABgUASgEgBmCr4QgrgYgYglQgOgUgJgXQgIgXgEgjQgEgkAAg7QAAhKAEgrQADgsAQgdQAOgbAhgYQghgbgOgaQgQgagDglQgEglAAg5QAAg1AFghQAGgiALgXQALgXATgXQAcgkApgUQApgUAuAAQAwAAApAUQApAUAcAkQATAXALAXQALAXAGAiQAFAhAAA1QAAA5gEAlQgDAlgQAaQgPAaghAbQAhAYAPAbQAQAdADAsQAEArAABKQAAA7gEAkQgEAjgIAXQgJAXgOAUQgYAlgrAYQgrAZg9ABQg7gBgrgZgEgAuClOQgUATgBAeIAADBQABAeAUATQAUATAaABQAcgBAUgTQAUgTABgeIAAjBQgBgegUgTQgUgTgcgBQgaABgUATgEgAuCfMQgUATgBAeIAACPQABAeAUATQAUATAaABQAcgBAUgTQAUgTABgeIAAiPQgBgegUgTQgUgTgcgBQgaABgUATgEgCwCY0ID1tSIiZAAIAABxIh8AAIAAj2IGiAAIAACNIjtNKgEgBkCFMQgugZgdgsQgNgWgHgVQgHgXgDgjQgDglAAg+QAAg8ADgjQADgjAFgXQAGgYAKgZIC2nuICdAAIieGdIABACQAIgEAOgEQAPgEAXAAQAlABAfARQAgASASAcQAMASAHAXQAHAYACAsQADArAABNQAAA+gDAlQgCAjgIAXQgGAVgNAWQgcAuguAYQgtAZg7AAQg3gBgtgZgEgAuB+pQgUATgBAgIAAC3QABAgAUATQAUASAaABQAcgBAUgSQAUgTABggIAAi3QgBgggUgTQgUgSgcgBQgaABgUASgEgBmBx2QgwgZgdgwQgcgvgBhBIAAgqICNAAIAAAkQAAAkAUAUQAUAUAeAAQAfAAARgUQASgSAAgjIAAjnQgBgegSgTQgSgUgdgBQgXABgOAJQgPAKgHAMIgLAWIh8AAIAAoSIGRAAIAACFIkVAAIAAEIQATgTAegMQAdgNAlgBQBJAAArAtQAsAsACBVIAAD+QgBBBgdAvQgdAwgvAZQgvAag5AAQg3AAgvgagEAAkBeyIAAiSIkXAAIAAiFIDLrAICUAAIjSLAICKAAIAAkYICNAAIAAEYIBDAAIAACFIhDAAIAACSgEgBdBLQQgwgVggguQghgugChNIAAhQICNAAIAABJQAAAiASAUQATAVAeABQAggBATgUQASgVAAglIAAiNQABg3gXgTQgXgThAABIAAh8QA8ABAYgQQAZgRAAg2IAAh+QAAgfgSgSQgTgTgggBQgjABgQAXQgQAWAAAXIAABQIiNAAIAAhSQABg6AdgvQAcgvAwgbQAwgcA5gBQA5ACAmAVQAnAWATAYQATAWALAYQAMAZAGAlQAGAnAAA9QAABDgFAkQgGAkgSAWQgTAWgnAXQAqAZATAaQASAaAEAnQAEAoAABFQAAA/gEAlQgDAlgIAWQgIAWgPAUQgZAngrAZQgqAZg+ABIgDAAQgsAAgugUgEgDQA4GIAAiFID8neQASgjADgcQAEgcAAgnQAAgZgDgZQgDgZgPgRQgOgQgigBQgeAAgSASQgSASgBAiIAABQIiNAAIAAhNQABg7AcgwQAcgxAwgcQAvgdA5gBQBJABAuAiQAuAiAWA4QAWA4AABDQAAAtgDAfQgDAegKAcQgJAdgXAoIjMGPID8AAIAACNgEgApAkwIAAtCIiNBoIAAiVICNhoICLAAIAAPXgAhmRIQgvgZgdgwQgdgvgBhBIAApBQABhBAdgvQAdgwAvgZQAvgaA3AAQA5AAAvAaQAvAZAdAwQAdAvABBBIAAJBQgBBBgdAvQgdAwgvAZQgvAag5AAQg3AAgvgagAgvEcQgTAUgBAeIAAJBQABAeATAUQATATAcABQAegBATgTQATgUABgeIAApBQgBgegTgUQgTgTgegBQgcABgTATgAich6ICdmdIgBgCQgHAEgOAEQgPAEgXAAQglgBgfgRQgggSgSgcQgMgSgHgXQgHgYgCgsQgDgrAAhNQAAg+ADglQACgjAIgXQAGgVANgWQAcguAugYQAtgZA5AAQA5ABAtAZQAuAZAdAsQANAWAHAVQAHAXADAjQADAlAAA+QAAA8gDAjQgDAjgFAXQgGAYgKAZIi3HugAguu5QgUATgBAgIAAC3QABAgAUATQAUASAaABQAcgBAUgSQAUgTABggIAAi3QgBgggUgTQgUgSgcgBQgaABgUASgAhm1iQgrgYgYglQgOgUgJgXQgIgXgEgjQgEgkAAg7QAAhKAEgrQADgsAQgdQAOgbAhgYQghgbgOgaQgQgagDglQgEglAAg5QAAg1AFghQAGgiALgXQALgXATgXQAcgkApgUQApgUAuAAQAwAAApAUQApAUAcAkQATAXALAXQALAXAGAiQAFAhAAA1QAAA5gEAlQgDAlgQAaQgPAaghAbQAhAYAPAbQAQAdADAsQAEArAABKQAAA7gEAkQgEAjgIAXQgJAXgOAUQgYAlgrAYQgrAZg9ABQg7gBgrgZgAgu8MQgUATgBAeIAADBQABAeAUATQAUATAaABQAcgBAUgTQAUgTABgeIAAjBQgBgegUgTQgUgTgcgBQgaABgUATgEgAugiOQgUATgBAeIAACPQABAeAUATQAUATAaABQAcgBAUgTQAUgTABgeIAAiPQgBgegUgTQgUgTgcgBQgaABgUATgEgCwgomID1tSIiZAAIAABxIh8AAIAAj2IGiAAIAACNIjtNKgEgBkg8OQgugZgdgsQgNgWgHgVQgHgXgDgjQgDglAAg+QAAg8ADgjQADgjAFgXQAGgYAKgZIC2nuICdAAIieGdIABACQAIgEAOgEQAPgEAXAAQAlABAfARQAgASASAcQAMASAHAXQAHAYACAsQADArAABNQAAA+gDAlQgCAjgIAXQgGAVgNAWQgcAuguAYQgtAZg7AAQg3gBgtgZgEgAuhCxQgUATgBAgIAAC3QABAgAUATQAUASAaABQAcgBAUgSQAUgTABggIAAi3QgBgggUgTQgUgSgcgBQgaABgUASgEgBmhPkQgwgZgdgwQgcgvgBhBIAAgqICNAAIAAAkQAAAkAUAUQAUAUAeAAQAfAAARgUQASgSAAgjIAAjnQgBgegSgTQgSgUgdgBQgXABgOAJQgPAKgHAMIgLAWIh8AAIAAoSIGRAAIAACFIkVAAIAAEIQATgTAegMQAdgNAlgBQBJAAArAtQAsAsACBVIAAD+QgBBBgdAvQgdAwgvAZQgvAag5AAQg3AAgvgagEAAkhioIAAiSIkXAAIAAiFIDLrAICUAAIjSLAICKAAIAAkYICNAAIAAEYIBDAAIAACFIhDAAIAACSgEgBdh2KQgwgVggguQghgugChNIAAhQICNAAIAABJQAAAiASAUQATAVAeABQAggBATgUQASgVAAglIAAiNQABg3gXgTQgXgThAABIAAh8QA8ABAYgQQAZgRAAg2IAAh+QAAgfgSgSQgTgTgggBQgjABgQAXQgQAWAAAXIAABQIiNAAIAAhSQABg6AdgvQAcgvAwgbQAwgcA5gBQA5ACAmAVQAnAWATAYQATAWALAYQAMAZAGAlQAGAnAAA9QAABDgFAkQgGAkgSAWQgTAWgnAXQAqAZATAaQASAaAEAnQAEAoAABFQAAA/gEAlQgDAlgIAWQgIAWgPAUQgZAngrAZQgqAZg+ABIgDAAQgsAAgugUgEgDQiJUIAAiFID8neQASgjADgcQAEgcAAgnQAAgZgDgZQgDgZgPgRQgOgQgigBQgeAAgSASQgSASgBAiIAABQIiNAAIAAhNQABg7AcgwQAcgxAwgcQAvgdA5gBQBJABAuAiQAuAiAWA4QAWA4AABDQAAAtgDAfQgDAegKAcQgJAdgXAoIjMGPID8AAIAACNgEgApicqIAAtCIiNBoIAAiVICNhoICLAAIAAPXgEgBmiwSQgvgZgdgwQgdgvgBhBIAApBQABhBAdgvQAdgwAvgZQAvgaA3AAQA5AAAvAaQAvAZAdAwQAdAvABBBIAAJBQgBBBgdAvQgdAwgvAZQgvAag5AAQg3AAgvgagEgAvi8+QgTAUgBAeIAAJBQABAeATAUQATATAcABQAegBATgTQATgUABgeIAApBQgBgegTgUQgTgTgegBQgcABgTATg");
	this.shape.setTransform(71,1257.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,1030.2,2483.5);


(lib.t1d = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ADaA0IAAgpIgpAAIAAApIgYAAIAAhnIAYAAIAAAsIApAAIAAgsIAYAAIAABngAA1A0IAAhTIgeAAIAAgUIBTAAIAAAUIgdAAIAABTgAgsA0IAAhnIAXAAIAABngAiNA0IgXhHIgXBHIgRAAIglhnIAaAAIAUA7IATg7IAYAAIATA7IAVg7IAZAAIglBng");
	this.shape.setTransform(-2.2,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-26.4,0,48.8,22.3);


(lib.t1c = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFhAjIAOgRQARAPAOAAQAGAAAFgDQADgDAAgFQAAgEgEgDQgEgDgMgCQgRgFgJgFQgJgGAAgPQAAgPALgJQALgHAQgBQALAAAKAEQALAEAHAGIgMARQgOgKgOAAQgGAAgDACQgEADABAFQAAAFADACQAFADAOADQAQAEAIAGQAIAHAAAOQAAAOgKAJQgLAJgRgBQgZAAgUgSgABAAmQgQgQAAgWQAAgVAQgQQAQgPAXgBQAXABAQAPQAQAQAAAVQAAAWgQAQQgQAPgXAAQgXAAgQgPgABRgWQgJAKAAAMQAAANAJAKQAJAKANAAQANAAAJgKQAJgKAAgNQAAgMgJgKQgJgKgNAAQgNAAgJAKgAmjAmQgQgQAAgWQAAgVAQgQQAQgPAXgBQAXABAQAPQAQAQAAAVQAAAWgQAQQgQAPgXAAQgXAAgQgPgAmSgWQgJAKAAAMQAAANAJAKQAJAKANAAQANAAAJgKQAJgKAAgNQAAgMgJgKQgJgKgNAAQgNAAgJAKgAEaA0Igzg/IAAA/IgXAAIAAhmIAWAAIA0BBIAAhBIAWAAIAABmgAgWA0IAAhmIAWAAIAABmgAh6A0IAAhSIgfAAIAAgUIBTAAIAAAUIgdAAIAABSgAkTA0IAAhmIAlAAQAYAAALAJQALAKAAATQAAARgLAJQgMAKgXgBIgOAAIAAAdgAj8ADIAQAAQAMAAAEgDQAEgFAAgIQAAgJgFgFQgGgDgLAAIgOAAg");
	this.shape.setTransform(-1.5,11.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-45.1,0,87.3,22.3);


(lib.t1b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEvA0IAAgqIgkg9IAZAAIAXAnIAWgnIAaAAIgkA9IAAAqgADNA0IgXgiIgQAAIAAAiIgXAAIAAhnIAnAAQAZAAAKAIQAKAIAAATQAAAXgTAIIAaAlgACmAAIARAAQAMAAAEgEQAFgEgBgIQABgJgFgCQgEgDgMgBIgRAAgABLA0IgKgXIgsAAIgKAXIgWAAIArhnIAXAAIAtBngAAeAJIAaAAIgMgcgAhNA0Igyg/IAAA/IgXAAIAAhnIAWAAIAzBCIAAhCIAYAAIAABngAjlA0IAAhnIAYAAIAABngAlqA0IAAhnIApAAQALAAAHACQAIADADAEQAIAJAAAKQgBAMgHAGIgEADIgEACQAKAAAGAHQAGAGAAAKQAAALgIAJQgJAJgVAAgAlSAgIAQAAQAJAAAFgDQAGgCAAgHQgBgIgFgCQgFgCgMAAIgNAAgAlSgIIAKAAQAKAAAFgCQAFgCgBgHQAAgIgDgCQgFgCgLAAIgKAAg");
	this.shape.setTransform(-0.7,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-37.1,0,72.7,22.3);


(lib.t1a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ADvA0IAAhnIBMAAIAAAVIg0AAIAAAWIAvAAIAAARIgvAAIAAAXIA1AAIAAAUgABeA0IAAhnIAlAAQAcAAAPAOQAPAOAAAXQAAAXgPAOQgPAPgdAAgAB1AgIAPAAQAQAAAJgJQAIgIAAgPQAAgOgIgIQgJgJgSAAIgNAAgAAaA0IgJgXIgqAAIgKAXIgZAAIAthnIAVAAIAtBngAgQAJIAYAAIgLgcgAh7A0IgXgiIgQAAIAAAiIgXAAIAAhnIAnAAQAZAAAKAIQALAIAAATQAAAXgUAIIAaAlgAiiAAIARAAQAMAAAEgEQAFgEAAgIQAAgJgFgCQgEgDgLgBIgSAAgAkdA0IAAhTIgeAAIAAgUIBTAAIAAAUIgeAAIAABTg");
	this.shape.setTransform(-1.7,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-33.3,0,63.7,22.3);


(lib.logo_mc = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2E").s().p("AAUA4QghAAgHgCQgPgDgFgHQgGgGgCgNQgBgEAAgUQAAgTABgFQADgOAHgHQAIgIAYgCIAggBQAmAAAKADQAQADAEALQADAHAAAPIgiAAQAAgFgCgEQgEgEgIAAIgxABIgDAAQgHACgCAEQgCAFAAATQAAAPACAEQACAHAJABIAUABIAfAAQAMgBABgIIAAgIIgrAAIAAgTIBNAAIAAAOQAAAXgDAIQgDAIgGAEQgIAEgNABgADdA3IAAgqIhPAAIAAAqIgiAAIAAhtIAiAAIAAApIBPAAIAAgpIAjAAIAABtgAheA3IAAhtIAjAAIAABtgAiNA3IAAgqIhOAAIAAAqIgkAAIAAhtIAkAAIAAApIBOAAIAAgpIAjAAIAABtg");
	this.shape.setTransform(29.8,16.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AhXA2QgOgCgGgHQgGgFgCgNQgCgHAAgUIABgTQAAgFACgGQACgLAJgHQAJgFAWgCIAfgBQAnABAJABQAPADAFAHQAHAJABALQABAJABAQQgBAZgEAJQgEAKgIAEQgIAEgFABIgTACIgcABQgngBgIgCgAhDgbQgKABgCAGQgDAFAAAPQAAAPADAGQACAFALACIAaABQAZAAAGgBQAHgCACgEQABgFABgHIAAgKQAAgPgCgFQAAgEgDgCQgFgCgGAAIgaAAQgXAAgEABgAkBA4IAAhvIAkAAIAABTIBcAAIAAAcgACnA3IgUhEIgVBEIgwAAIgphuIAlAAIAbBMIAYhMIAsAAIAXBMIAchMIAlAAIgqBug");
	this.shape_1.setTransform(91.5,22.5);

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E1E0DF").s().p("AAABeIkpA1IAAjxIEpg1IEpA1IAADxg");
	this.shape_2.setTransform(29.8,16.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6B6B6A").s().p("AkpBeIAAjxIEpA1IEpg1IAADxIkpA1g");
	this.shape_3.setTransform(91.2,22.4);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,2,121,35.2);


(lib.gbcurve = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgMfg6DQMvhoMTBoMgADB02I5CAFg");
	this.shape.setTransform(80,371.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.4,-5.2,160.8,753.7);


(lib.bgimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg11();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib._bg = function() {
	this.initialize();

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib._clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_46 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(46).call(this.frame_46).wait(1));

	// t3c
	this.instance = new lib.t3c();
	this.instance.setTransform(198.7,360.8,1,1,0,0,0,98.7,13.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({x:178.7,alpha:1},7,cjs.Ease.get(0.9)).wait(30));

	// t3b
	this.instance_1 = new lib.t3b();
	this.instance_1.setTransform(196.2,258.8,1,1,0,0,0,96.2,13.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({x:176.2,alpha:1},7,cjs.Ease.get(0.9)).wait(35));

	// t3a
	this.instance_2 = new lib.t3a();
	this.instance_2.setTransform(162.8,196.8,1,1,0,0,0,62.8,13.8);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:142.8,alpha:1},7,cjs.Ease.get(0.9)).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(66.4,190.1,67.7,37.8);


(lib.t2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(1));

	// t2.2
	this.instance = new lib.t22();
	this.instance.setTransform(151.5,191.1,0.537,0.537,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(33).to({_off:false},0).wait(1).to({regX:-1.2,regY:18.6,scaleX:0.7,scaleY:0.7,x:150.6,y:196.3,alpha:0.344},0).wait(1).to({scaleX:0.82,scaleY:0.82,x:150.5,y:197.3,alpha:0.616},0).wait(1).to({scaleX:0.92,scaleY:0.92,x:150.4,y:197.9,alpha:0.816},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:150.3,y:198.4,alpha:0.944},0).wait(1).to({regX:0,regY:11.1,scaleX:1,scaleY:1,x:151.5,y:191.1,alpha:1},0).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
		exportRoot.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// %
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbHWQgdgcgBgwIAAhZQABg1AdgdQAfgfA3AAQA3AAAfAfQAfAdAAA1IAABZQAAAwgfAcQgfAcg3ABQg3gBgfgcgABZEdQgKAKgBAPIAABGQABAPAKAKQAKAKAOABQAOgBAKgKQAKgKABgPIAAhGQgBgPgKgKQgKgKgOgBQgOABgKAKgAjUHrIFPvVIBbAAIlPPVgAjFjbQgfgdgBgwIAAhZQABg0AfgeQAfgeA3gBQA2ABAfAeQAdAeABA0IAABZQgBAwgdAdQgfAcg2AAQg3AAgfgcgAiHmUQgLAKAAAPIAABGQAAAPALAKQAKAKAOABQANgBAKgKQAKgKABgPIAAhGQgBgPgKgKQgKgKgNgBQgOABgKAKg");
	this.shape.setTransform(174.2,118.6);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(16).to({x:199.2},0).wait(8).to({x:224.2},0).wait(20));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AGPHZQgvgZgdgwQgdgvgBhBIAAo/QABhBAdgvQAdgwAvgZQAvgaA4AAQA5AAAwAaQAuAZAdAwQAdAvACBBIAAI/QgCBBgdAvQgdAwguAZQgwAag5AAQg4AAgvgagAHGlRQgUAUAAAeIAAI/QAAAeAUAUQASATAeABQAfgBATgTQATgUABgeIAAo/QgBgegTgUQgTgTgfgBQgeABgSATgAhdHZQgvgZgdgwQgdgvgBhBIAAo/QABhBAdgvQAdgwAvgZQAvgaA2AAQA6AAAvAaQAuAZAdAwQAdAvACBBIAAI/QgCBBgdAvQgdAwguAZQgvAag6AAQg2AAgvgagAgmlRQgUAUAAAeIAAI/QAAAeAUAUQASATAcABQAfgBATgTQATgUAAgeIAAo/QAAgegTgUQgTgTgfgBQgcABgSATgArIHsIAAiEID+ndQASgjAEgcQAEgcgBgmQABgagDgZQgDgZgPgRQgPgQgiAAQgfAAgSASQgTARAAAjIAABQIiOAAIAAhOQABg7AcgwQAdgwAvgdQAwgdA7AAQBJAAAtAjQAvAhAVA4QAWA4AABDQAAAugDAeQgCAegLAdQgJAcgXApIjNGMID9AAIAACNg");
	this.shape_1.setTransform(125.9,117.9);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(33).to({_off:false},0).wait(12));

	// 1
	this.instance = new lib.t2roll();
	this.instance.setTransform(176.6,799.1,1,1,0,0,0,71,640);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25).to({_off:false},0).to({y:675.3},2).to({_off:true},6).wait(12));

	// 10
	this.instance_1 = new lib.t2roll();
	this.instance_1.setTransform(150.6,676.6,1,1,0,0,0,71,640);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(17).to({_off:false},0).to({y:-562.4},7).wait(1).to({x:126.6},0).to({_off:true},8).wait(12));

	// 100
	this.instance_2 = new lib.t2roll();
	this.instance_2.setTransform(125.6,676.6,1,1,0,0,0,71,640);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(7).to({y:-809.4},8).wait(1).to({x:100.6},0).wait(8).to({x:75.6},0).to({_off:true},8).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// t1d
	this.instance = new lib.t1d();
	this.instance.setTransform(0,65.1,1,1,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({alpha:1},7).wait(32));

	// t1c
	this.instance_1 = new lib.t1c();
	this.instance_1.setTransform(0,47.1,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).to({alpha:1},7).wait(34));

	// t1b
	this.instance_2 = new lib.t1b();
	this.instance_2.setTransform(0,29.1,1,1,0,0,0,0,11.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).to({alpha:1},7).wait(36));

	// t1a
	this.instance_3 = new lib.t1a();
	this.instance_3.setTransform(0,11.1,1,1,0,0,0,0,11.1);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({alpha:1},7).wait(38));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33.3,6,63.4,10.5);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{on:1,off:7});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6).call(this.frame_6).wait(6).call(this.frame_12).wait(1));

	// GET STARTED
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C2F35").s().p("AilAeIANgOQAOANANgBQAFAAAEgCQADgCAAgEQAAgEgDgDQgEgCgKgCQgPgFgIgEQgHgGAAgMQAAgNAJgIQAJgGAOAAQAJAAAJADQAJADAHAGIgKAPQgMgJgNAAQgEAAgEACQgDACAAAEQABAEADACQADADANADQANADAIAFQAHAGAAAMQAAAMgKAIQgIAHgPAAQgWAAgSgQgAnlAhQgOgNAAgUQAAgSAOgOQAOgNATAAQAUAAAOAMIgKAQQgGgGgFgBQgGgCgFAAQgMgBgIAIQgIAIAAALQAAANAHAHQAIAIAKAAQALAAAHgEIAAgYIAVAAIAAAfQgOAPgYAAQgUAAgNgNgAGhAuIAAhZIAhAAQAYgBANAMQANAMAAAUQAAAVgMAMQgOANgZAAgAG2AcIANAAQAOAAAHgIQAHgGAAgOQAAgMgHgGQgHgIgPABIgMAAgAFDAuIAAhZIBBAAIAAASIgtAAIAAATIAoAAIAAAPIgoAAIAAATIAuAAIAAASgAD8AuIAAhIIgaAAIAAgRIBIAAIAAARIgaAAIAABIgAC3AuIgUgdIgOAAIAAAdIgUAAIAAhZIAiAAQAWAAAJAHQAJAHAAAQQAAATgSAHIAXAhgACVAAIAPAAQAKAAAFgDQADgDAAgHQAAgIgDgCQgFgDgKAAIgPAAgABXAuIgIgUIgnAAIgIAUIgWAAIAnhZIAVAAIAnBZgAAwAIIAXAAIgMgYgAgvAuIAAhIIgZAAIAAgRIBIAAIAAARIgaAAIAABIgAkRAuIAAhIIgaAAIAAgRIBIAAIAAARIgaAAIAABIgAmCAuIAAhZIBBAAIAAASIgtAAIAAATIAoAAIAAAPIgoAAIAAATIAuAAIAAASg");
	this.shape.setTransform(81.7,57);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13));

	// gb-curve
	this.instance = new lib.gbcurve();
	this.instance.setTransform(150,134.8,1,1,0,0,0,150,134.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},6).to({alpha:1},6).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F0F0F0").s().p("EgMfg6DQMvhoMTBoMgADB02I5CAFg");
	this.shape_1.setTransform(80,371.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-5.2,160.8,753.7);


// stage content:
(lib.highlow_160x6001b_GBP = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.enableMouseOver(20);
		
		this.loopNumber = 0 ;
		
		// CLICKTHROUGH
		this.clickTagBtn.addEventListener("click", function () {
			console.log("clickthrough");
			window.open(window.clickTAG);
		});
		
		// CTA
		this.clickTagBtn.addEventListener("mouseover", function () {
			exportRoot.bt.gotoAndPlay("on");
		});
		
		this.clickTagBtn.addEventListener("mouseout", function () {
			exportRoot.bt.gotoAndPlay("off");
		});
	}
	this.frame_64 = function() {
		this.stop();
	}
	this.frame_230 = function() {
		if(this.loopNumber >= 1){
			console.log("STOP BANNER");
			this.stop();
		} else {
			this.loopNumber++;
			console.log("RESTART: " + this.loopNumber);
		}
	}
	this.frame_237 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(64).call(this.frame_64).wait(166).call(this.frame_230).wait(7).call(this.frame_237).wait(1));

	// clickTagBtn
	this.clickTagBtn = new lib._clicktag();
	new cjs.ButtonHelper(this.clickTagBtn, 0, 1, 2, false, new lib._clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickTagBtn).wait(238));

	// Border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EgMfgu3IY/AAMAAABdvI4/AAg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(238));

	// bt
	this.bt = new lib.btn();
	this.bt.setTransform(150,637.6,1,1,0,0,0,150,149.5);
	this.bt.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.bt).wait(189).to({alpha:1},6).wait(36).to({y:767.6},6,cjs.Ease.get(-1)).wait(1));

	// t6
	this.instance = new lib.t6();
	this.instance.setTransform(79.1,271.1,1,1,0,0,0,0,12.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(185).to({_off:false},0).to({alpha:1},6).wait(40).to({y:-38.9},6,cjs.Ease.get(-1)).wait(1));

	// t5
	this.instance_1 = new lib.t5();
	this.instance_1.setTransform(80.3,248.1,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(182).to({_off:false},0).to({alpha:1},6).wait(43).to({y:-61.9},6,cjs.Ease.get(-1)).wait(1));

	// web-img
	this.instance_2 = new lib.webimg();
	this.instance_2.setTransform(-597,218,1,1,0,0,0,132,70);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(123).to({_off:false},0).to({x:-386.9},5,cjs.Ease.get(0.9)).to({x:85.2},50).to({x:292},5,cjs.Ease.get(-0.9)).to({_off:true},1).wait(54));

	// t4
	this.instance_3 = new lib.t3();
	this.instance_3.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(72).to({_off:false},0).wait(45).to({y:349},8,cjs.Ease.get(0.9)).to({_off:true},1).wait(112));

	// bg
	this.instance_4 = new lib.gbcurve();
	this.instance_4.setTransform(150,115.3,0.967,1.349,0,0,0,150,134.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(70).to({_off:false},0).wait(1).to({scaleX:1,scaleY:1},0).wait(46).to({y:622.8},8,cjs.Ease.get(0.9)).to({_off:true},71).wait(42));

	// logo
	this.instance_5 = new lib.logo_mc();
	this.instance_5.setTransform(84.5,76.8,1,1,0,0,0,64.5,18.8);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(117).to({_off:false},0).wait(114).to({y:-233.2},6,cjs.Ease.get(-1)).wait(1));

	// t2
	this.instance_6 = new lib.t2copy();
	this.instance_6.setTransform(-12,229,0.62,0.62);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(46).to({_off:false},0).wait(19).to({scaleX:8.77,scaleY:8.77,x:-1146.6,y:-751.4},4,cjs.Ease.get(-1)).to({_off:true},1).wait(168));

	// 160x600_mask
	this.instance_7 = new lib._160x600_mask();
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(50).to({_off:false},0).to({_off:true},15).wait(173));

	// t2
	this.instance_8 = new lib.t2();
	this.instance_8.setTransform(158,229,0.62,0.62);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(46).to({_off:false},0).to({x:73},4,cjs.Ease.get(-0.9)).to({x:-12},4,cjs.Ease.get(0.9)).wait(11).to({scaleX:8.77,scaleY:8.77,x:-1146.6,y:-751.4},4,cjs.Ease.get(-1)).to({_off:true},1).wait(168));

	// t1
	this.instance_9 = new lib.t1();
	this.instance_9.setTransform(81.5,302.5,1,1,0,0,0,0,38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(46).to({x:-8.5},4,cjs.Ease.get(-0.9)).to({x:-98.5},4,cjs.Ease.get(0.9)).to({_off:true},1).wait(183));

	// bg
	this.instance_10 = new lib.bgimg();
	this.instance_10.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(238));

	// bg
	this.instance_11 = new lib._bg();
	this.instance_11.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(238));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(79,299,162,1237.5);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;