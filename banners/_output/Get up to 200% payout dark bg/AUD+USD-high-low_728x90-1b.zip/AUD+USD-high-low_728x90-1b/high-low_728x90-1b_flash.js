(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 728,
	height: 90,
	fps: 18,
	color: "#FFFFFF",
	manifest: [
		{src:"images/_728x90_mask.png", id:"_728x90_mask"},
		{src:"images/bg11111.jpg", id:"bg11111"},
		{src:"images/web.jpg", id:"web"}
	]
};



// symbols:



(lib._728x90_mask = function() {
	this.initialize(img._728x90_mask);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.bg11111 = function() {
	this.initialize(img.bg11111);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.web = function() {
	this.initialize(img.web);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,728,180);


(lib.webimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.web();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,728,180);


(lib.t6 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAABKIAAgPQgNgCgKgJQgKgJABgRIAAAAIAWAAQAAAKAFAFQAFAEAFAAQAHAAAEgDQAEgEAAgHQAAgGgEgEQgDgEgJgDQgQgHgIgFQgIgIAAgOQAAgOAIgIQAIgIANgCIAAgRIAMAAIAAARQAOACAIAKQAIAJgBAPIAAABIgWAAQAAgJgEgFQgEgFgGAAQgGAAgCADQgEAEAAAHQAAAGAEAEQACADAJAEQARAHAIAGQAJAHAAAOQAAAOgJAIQgIAIgOACIAAAPgANmAvQgKgMAAgTIAAgCQAAgRAKgMQAKgMATAAQAQAAAKAJQAJAJAAANIgVAAQAAgFgEgEQgDgEgHAAQgJAAgDAHQgEAFAAALIAAACQAAALAEAHQADAHAJAAQAHAAADgDQAEgEAAgGIAVAAIAAABQAAANgKAIQgKAJgPAAQgSAAgLgMgAMNA0QgHgHAAgMQAAgMAJgHQAKgHASAAIANAAIAAgGQAAgEgDgEQgEgDgGAAQgFAAgDADQgDACAAAFIgWAAIgBgBQAAgKAKgIQAKgIAQAAQAPAAAJAIQAKAIAAAMIAAAjIABALQAAAFACAFIgWAAIgCgGIgCgGQgDAGgGAEQgGAEgIAAQgNAAgHgHgAMgAYQgEADAAAGQAAAEADACQADADAFAAQAGAAAEgDQAFgDACgEIAAgMIgNAAQgHAAgEAEgALOA4QgFgDgEgGIgCAKIgTAAIAAh4IAWAAIAAAvQAEgFAFgDQAFgDAHAAQAQAAAIAMQAJAMAAATIAAABQAAATgJAMQgIALgQAAQgHAAgGgDgALMgHQgEACgCAEIAAAiQACAEAEACQAEACAFAAQAJAAAEgGQADgGAAgMIAAgBQAAgNgEgFQgDgHgJAAQgFAAgEACgAHKAyQgKgIAAgLIAAgBIAVAAQABAHAEADQAEADAHAAQAGAAADgCQAEgDAAgEQAAgEgEgDQgEgCgJgCQgPgDgIgGQgIgGAAgJQAAgLAKgHQAJgIAPAAQAQAAAKAIQAJAHAAAMIAAAAIgWAAQAAgFgDgDQgEgDgGAAQgFAAgEADQgDACAAAEQAAACAEADQADACAKACQAQADAHAGQAIAGAAALQAAALgKAIQgKAHgQAAQgRAAgJgJgAFxA0QgHgHAAgMQAAgMAJgHQAKgHASAAIANAAIAAgGQAAgEgDgEQgEgDgGAAQgFAAgDADQgDACAAAFIgWAAIgBgBQAAgKAKgIQAKgIAQAAQAPAAAJAIQAKAIAAAMIAAAjIABALQAAAFACAFIgWAAIgCgGIgCgGQgDAGgGAEQgGAEgIAAQgNAAgHgHgAGEAYQgEADAAAGQAAAEADACQADADAFAAQAGAAAEgDQAFgDACgEIAAgMIgNAAQgHAAgEAEgAEhAvQgKgMAAgTIAAgCQAAgRAKgMQAKgMATAAQAQAAAKAJQAJAJAAANIgVAAQAAgFgEgEQgDgEgHAAQgJAAgDAHQgEAFAAALIAAACQAAALAEAHQADAHAJAAQAHAAADgDQAEgEAAgGIAVAAIAAABQAAANgKAIQgKAJgPAAQgSAAgLgMgACgAvQgKgLAAgXIAAgXQAAgXAKgLQAKgMASAAQASAAAKAMQALALAAAXIAAAXQAAAXgLALQgKAMgSAAQgSAAgKgMgACwggQgEAGAAAOIAAAbQAAAOAEAGQAEAGAIAAQAIAAAEgGQAEgGAAgOIAAgbQAAgOgEgGQgEgHgIAAQgIAAgEAHgABGAyQgMgIABgPIAAgBIAWgBQAAAIAEAEQAFAEAHAAQAHAAAEgFQAEgGAAgJQAAgKgEgGQgEgFgIAAQgHAAgDACQgEACgBAEIgUgBIAGg9IBAAAIAAASIgtAAIgDAaIAIgEQAEgBAFAAQARgBAJAKQAJAJAAASQAAAQgKALQgKALgSAAQgQAAgLgJgAiaA0QgHgHAAgMQAAgMAJgHQAKgHASAAIANAAIAAgGQAAgEgDgEQgEgDgGAAQgFAAgDADQgDACAAAFIgWAAIgBgBQAAgKAKgIQAKgIAQAAQAPAAAJAIQAKAIAAAMIAAAjIABALQAAAFACAFIgWAAIgCgGIgCgGQgDAGgGAEQgGAEgIAAQgNAAgHgHgAiHAYQgEADAAAGQAAAEADACQADADAFAAQAGAAAEgDQAFgDACgEIAAgMIgNAAQgHAAgEAEgAkRAvQgLgMAAgSIAAgDQAAgRAKgMQAKgMASAAQARAAAJAKQAKALAAAPIAAANIgzAAIAAAAQABAJAFAFQAFAFAIAAQAIAAAFgBIALgFIAGAOQgFAEgIADQgJADgKAAQgSAAgLgMgAkAgEQgEAEgBAGIABABIAcAAIAAgCQAAgGgEgEQgDgEgHAAQgGAAgEAFgAniAvQgLgMAAgSIAAgDQAAgRALgMQAKgMARAAQASAAAJAKQAJALAAAPIAAANIgyAAIAAAAQAAAJAFAFQAFAFAJAAQAHAAAFgBIALgFIAHAOQgGAEgIADQgIADgLAAQgSAAgLgMgAnRgEQgDAEgBAGIAAABIAcAAIAAgCQAAgGgDgEQgEgEgHAAQgGAAgEAFgAo3AvQgKgMAAgTIAAgCQAAgRAKgMQAKgMATAAQAQAAAKAJQAJAJAAANIgVAAQAAgFgEgEQgDgEgHAAQgJAAgDAHQgEAFAAALIAAACQAAALAEAHQADAHAJAAQAHAAADgDQAEgEAAgGIAVAAIAAABQAAANgKAIQgKAJgPAAQgSAAgLgMgAqJAvQgLgMAAgSIAAgDQAAgRAKgMQAKgMASAAQARAAAJAKQAKALAAAPIAAANIgzAAIAAAAQABAJAFAFQAFAFAIAAQAIAAAFgBIALgFIAGAOQgFAEgIADQgJADgKAAQgSAAgLgMgAp4gEQgEAEgBAGIABABIAcAAIAAgCQAAgGgEgEQgDgEgHAAQgGAAgEAFgAtHAvQgJgLAAgTIAAgBQAAgSAJgNQAJgMAPAAQAHAAAFADQAFADAEAFIAAgvIAXAAIAAB4IgUAAIgCgKQgEAGgFADQgGADgHAAQgPAAgJgMgAs1gCQgEAGAAAMIAAABQAAAMAEAGQAEAGAIAAQAFAAAEgCQADgCADgEIAAgiQgDgEgDgCQgEgCgFAAQgIAAgEAHgAv6A0QgHgHAAgMQAAgMAKgHQAJgHATAAIAMAAIAAgGQAAgEgDgEQgDgDgGAAQgGAAgDADQgDACAAAFIgWAAIAAgBQgBgKAKgIQAKgIAQAAQAPAAAKAIQAJAIAAAMIAAAjIABALQABAFACAFIgXAAIgCgGIgBgGQgEAGgGAEQgFAEgIAAQgOAAgHgHgAvmAYQgEADAAAGQAAAEADACQACADAFAAQAGAAAFgDQAFgDABgEIAAgMIgMAAQgIAAgDAEgAPnA5IgXgjIgGAAIAAAjIgXAAIAAh4IAXAAIAABEIAFAAIAUgeIAaAAIgbAkIAgAugAJJA5IAAgyQAAgIgEgEQgDgEgHAAQgFAAgDABIgGAFIAAA8IgXAAIAAh4IAXAAIAAAwQAEgFAGgEQAFgDAHAAQAOAAAHAJQAIAJAAAQIAAAygAlWA5IgchSIAXAAIAPAzIABAIIABAAIAPg7IAYAAIgdBSgAmUA5IAAhSIAWAAIAABSgArJA5IAAhSIAVAAIABAMQADgGAEgEQAFgEAGAAIADAAIADABIgCAUIgIAAQgFAAgEACQgDACgCACIAAA5gAt0A5IAAg1QAAgGgEgEQgDgDgHAAQgEAAgEACQgEABgCAEIAAA7IgXAAIAAhSIAVAAIABAMQAFgHAGgDQAGgEAIAAQAMAAAIAIQAHAIAAAPIAAA1gAJxARIAAgRIAsAAIAAARgAmUguIAAgRIAWAAIAAARg");
	this.shape.setTransform(100.2,11);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-4.5,-2,208.8,25.1);


(lib.t5 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("AC6ApQgNgMAAgXIAAg4IAYAAIAAA3QAAANAFAHQAGAIAKgBQAKABAGgIQAGgHAAgNIAAg3IAXAAIAAA4QAAAXgNAMQgMAMgUAAQgTAAgNgMgAiyAnQgQgQAAgXQAAgWAQgPQAQgPAXgBQAWAAARAPIgMARQgHgFgGgDQgGgCgHAAQgNAAgKAJQgJAJAAANQAAAOAJAJQAJAKAMgBQAMAAAIgEIAAgcIAYAAIAAAlQgQAQgbAAQgYAAgPgOgAmPAjIAOgRQARAPAOAAQAGAAAEgDQAEgDAAgFQAAgEgEgDQgEgDgMgCQgSgFgIgFQgJgGAAgPQAAgPALgJQALgHAQgBQAKAAALAEQAKAEAIAGIgMARQgOgKgOAAQgGAAgDACQgEADAAAFQAAAFAEACQAFADAOADQAPAEAJAGQAIAHAAAOQAAAOgLAJQgKAJgSgBQgYAAgUgSgAE9A0IAAhmIAlAAQAYAAALAJQALAKAAATQAAARgLAJQgLAKgYgBIgNAAIAAAdgAFVADIAPAAQAMAAAEgDQAEgFAAgIQAAgJgFgFQgGgDgLAAIgNAAgAAaA0Igwg/IAAA/IgXAAIAAhmIAWAAIAxBBIAAhBIAXAAIAABmgAkKA0IAAhmIAXAAIAABmg");
	this.shape.setTransform(38.5,11.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.6,0,80.1,22.3);


(lib.t3c = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("AgNANQgFgFgBgIQABgHAFgGQAGgGAHAAQAHAAAHAGQAFAGAAAHQAAAIgFAFQgHAHgHAAQgHAAgGgHg");
	this.shape.setTransform(2,14);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AikBWQgJgCgGgDIAFgNQAFACAGACQAHACAHAAQAMAAAGgGQAFgGAAgMIAAgKQgEAGgGADQgHADgJAAQgRAAgKgNQgKgNAAgUIAAgCQAAgVAKgOQAKgOARAAQAKAAAGAEQAIADAEAHIACgMIANAAIAABdQAAATgKAJQgKAKgUAAQgIAAgHgCgAilgVQgHALAAAOIAAACQAAAOAGAJQAGAJANAAQAHAAAFgEQAGgEADgGIAAgqQgDgGgGgDQgEgEgIAAQgNAAgFAKgANFAqQgKgJAAgMIABgBIAQAAQABAJAGAFQAGAEAJAAQAKAAAEgEQAGgDAAgHQAAgFgFgEQgEgEgMgCQgRgEgJgFQgJgGAAgLQAAgMAKgIQAKgIAQAAQAQAAAKAIQAKAJAAAMIAAABIgRAAQAAgHgGgEQgFgFgIAAQgKAAgEAEQgFAEABAFQAAAGAEADQADADANADQARADAKAGQAIAGAAALQAAANgKAIQgLAIgQAAQgSAAgLgKgAMMAtQgGgGAAgOIAAg4IgPAAIAAgMIAPAAIAAgXIARAAIAAAXIASAAIAAAMIgSAAIAAA4QAAAHADADQADACAEAAIAEAAIADgBIACAMQgCACgDABIgIABQgKAAgHgHgAKpAmQgMgNABgVIAAgEQAAgSAMgOQAMgNAQAAQAUAAAKALQAJAMABATIAAAJIg+AAIAAABQgBANAIAJQAGAJAMAAQAJAAAGgCQAHgDAFgEIAGALQgEAFgJADQgIAEgMAAQgUAAgMgOgAK4gYQgHAHgBALIAAABIAsAAIAAgDQAAgKgGgHQgFgGgLAAQgIAAgGAHgAGpAsQgHgIAAgNQgBgOALgHQAMgGASAAIATAAIAAgJQAAgJgFgFQgFgEgKAAQgIAAgFAEQgFAEAAAGIgRAAIAAgBQAAgKAKgIQAKgJAQAAQARAAAJAIQAKAIAAAQIAAAsIABAJIACAKIgSAAIgCgIIAAgGQgFAGgHAFQgJAFgJAAQgOAAgIgIgAG5ALQgHAFABAHQAAAHADADQAEAEAIAAQAJAAAIgFQAIgFACgGIAAgPIgUAAQgKAAgGAFgAA9AmQgLgOAAgVIAAgCQAAgTALgNQAMgOAUAAQATAAAMAOQALANAAATIAAACQAAAWgLANQgMAOgTAAQgUAAgMgOgABKgWQgGAKAAANIAAACQAAAPAGAKQAGAKANAAQAMAAAHgKQAGgKAAgPIAAgCQAAgNgGgKQgHgJgMAAQgNAAgGAJgAhLAmQgNgNAAgVIAAgEQAAgSANgOQAMgNARAAQASAAAKALQAKAMAAATIAAAJIg+AAIAAABQABANAGAJQAHAJAMAAQAJAAAGgCQAHgDAFgEIAGALQgEAFgJADQgIAEgMAAQgUAAgLgOgAg+gYQgFAHgCALIAAABIAsAAIAAgDQAAgKgFgHQgGgGgKAAQgKAAgGAHgAl+AsQgHgIAAgNQgBgOALgHQAMgGASAAIATAAIAAgJQAAgJgFgFQgFgEgKAAQgIAAgFAEQgFAEAAAGIgRAAIAAgBQgBgKALgIQAKgJAQAAQARAAAJAIQAKAIAAAQIAAAsIABAJIACAKIgSAAIgBgIIgBgGQgFAGgIAFQgHAFgKAAQgOAAgIgIgAluALQgGAFAAAHQAAAHADADQAFAEAIAAQAIAAAIgFQAIgFACgGIAAgPIgUAAQgKAAgGAFgApDAmQgNgNAAgVIAAgEQAAgSANgOQAMgNAQAAQATAAAKALQAKAMAAATIAAAJIg+AAIAAABQABANAGAJQAHAJAMAAQAJAAAGgCQAHgDAFgEIAHALQgFAFgJADQgIAEgMAAQgUAAgLgOgAo2gYQgFAHgCALIAAABIAsAAIAAgDQAAgKgFgHQgGgGgLAAQgJAAgGAHgAqsAnQgKgNAAgUIAAgCQAAgVAKgOQAKgOASAAQAIAAAHADQAGADAEAGIAAg0IASAAIAACHIgOAAIgCgMQgFAHgHADQgHAEgJAAQgQAAgLgNgAqegVQgGALAAAOIAAACQAAAOAGAJQAGAJAMAAQAIAAAFgEQAFgDADgHIAAgqQgDgGgFgEQgGgDgGAAQgNAAgGAKgAKBAyIgggsIgKAAIAAAsIgSAAIAAiHIASAAIAABPIAKAAIAaglIAVAAIggArIAlAygAIHAyIAAhdIAQAAIACAOQAEgIAFgEQAHgEAIAAIADAAIADABIgDAQIgJgBQgGAAgFAEQgEADgDAGIAABCgAF3AyIABhlIAAAAIgpBlIgMAAIgphlIAAAAIABBlIgRAAIAAh+IAWAAIApBmIABAAIAohmIAWAAIAAB+gACkAyIAAhRIgPAAIAAgMIAPAAIAAgMQAAgQAHgIQAIgIAPAAIAGAAIAGACIgCANIgDgBIgGAAQgHAAgDAFQgEAEgBAJIAAAMIAVAAIAAAMIgVAAIAABRgAjjAyIAAg6QAAgMgGgGQgFgFgJAAQgIAAgGAEQgGADgDAGIAABEIgSAAIAAhdIAQAAIABAOQAFgIAHgEQAIgEAIAAQAQAAAJAJQAHAJABATIAAA6gAnAAyIAAhdIAPAAIACAOQAEgIAGgEQAGgEAIAAIADAAIAEABIgDAQIgJgBQgHAAgFAEQgEADgDAGIAABCgArdAyIAAhdIARAAIAABdgAsgAyIgZhXIgCgMIgBAAIgcBjIgPAAIgfh+IASAAIATBRIACAQIABABIAbhiIAPAAIAbBiIABAAIAWhiIAQAAIgeB+gArdhEIAAgRIARAAIAAARg");
	this.shape_1.setTransform(103.8,15.8);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,197,27.8);


(lib.t3b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("AgNANQgFgFgBgIQABgHAFgGQAGgGAHAAQAHAAAHAGQAFAGAAAHQAAAIgFAFQgHAHgHAAQgHAAgGgHg");
	this.shape.setTransform(2,14);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AkMBVQgHgCgGgDIAEgNQAEACAHACQAHACAHAAQAMAAAGgGQAFgGAAgMIAAgKQgEAGgHADQgGADgIAAQgSAAgKgNQgKgNAAgUIAAgCQAAgVAKgOQAKgOASAAQAIAAAHAEQAIADAEAHIACgMIANAAIAABdQAAATgKAJQgLAKgTAAQgIAAgIgCgAkMgWQgHALAAAOIAAACQAAAOAGAJQAGAJAMAAQAJAAAEgEQAGgEADgGIAAgqQgDgGgGgDQgFgEgHAAQgNAAgFAKgApCBXIgFgBIACgOIADAAIAEABQAGAAADgFIAHgLIADgKIgjhbIATAAIAYBFIAAAAIAYhFIATAAIgoBrQgDAKgIAHQgGAHgMAAIgFAAgALkAlQgMgNABgVIAAgDQgBgTANgOQAMgNARAAQASAAALALQAKAMAAATIAAAJIg/AAIAAABQAAANAIAJQAGAJAMAAQAJAAAHgCQAGgDAFgEIAHALQgGAFgIADQgIAEgMAAQgUAAgMgOgALzgZQgHAHgBALIAAABIAsAAIAAgDQAAgKgGgHQgFgGgKAAQgKAAgFAHgAIiAlQgMgOAAgVIAAgCQAAgTAMgNQALgOATAAQAVAAALAOQALANAAATIAAACQAAAWgLANQgLAOgVAAQgTAAgLgOgAIugXQgHAKAAANIAAACQAAAPAHAKQAGAKAMAAQANAAAGgKQAHgKAAgPIAAgCQAAgNgHgKQgGgJgNAAQgMAAgGAJgADdAmQgKgNAAgUIAAgCQAAgVAKgOQAJgOATAAQAHAAAHADQAGADAFAGIAAg0IARAAIAACHIgNAAIgCgMQgGAHgGADQgHAEgJAAQgRAAgKgNgADqgWQgFALgBAOIAAACQABAOAFAJQAGAJAMAAQAIAAAGgEQAFgDADgHIAAgqQgDgGgFgEQgGgDgHAAQgMAAgHAKgACAAlQgMgNAAgVIAAgDQAAgTAMgOQANgNAQAAQATAAAKALQAKAMAAATIAAAJIg+AAIAAABQAAANAHAJQAHAJAMAAQAIAAAHgCQAGgDAGgEIAGALQgFAFgIADQgJAEgLAAQgVAAgLgOgACOgZQgGAHgBALIAAABIAsAAIAAgDQgBgKgFgHQgGgGgKAAQgJAAgGAHgABGAsQgGgGgBgOIAAg4IgPAAIAAgMIAPAAIAAgXIASAAIAAAXIASAAIAAAMIgSAAIAAA4QAAAHACADQAEACAEAAIAEAAIADgBIACAMQgCACgEABIgHABQgLAAgGgHgAgjArQgHgIAAgNQAAgOALgHQALgGATAAIARAAIAAgJQAAgJgGgFQgEgEgIAAQgJAAgFAEQgEAEAAAGIgRAAIAAgBQgBgKALgIQAKgJAQAAQAOAAAKAIQAKAIAAAQIAAAsIABAJIACAKIgTAAIgBgIIAAgGQgGAGgHAFQgGAFgJAAQgOAAgJgIgAgSAKQgHAFAAAHQAAAHAEADQAEAEAIAAQAJAAAGgFQAHgFADgGIAAgPIgSAAQgLAAgFAFgAiyApQgJgKAAgVIAAg2IARAAIAAA2QABAPAEAGQAEAGAKAAQAJAAAHgEQAGgEADgHIAAhCIARAAIAABdIgQAAIgBgOQgFAHgGAEQgIAFgJAAQgQAAgIgKgAl4AlQgMgNABgVIAAgDQAAgTAMgOQAMgNAQAAQAUAAAKALQAJAMABATIAAAJIg+AAIAAABQgBANAIAJQAGAJAMAAQAJAAAGgCQAHgDAFgEIAGALQgEAFgJADQgIAEgMAAQgUAAgMgOgAlpgZQgHAHgBALIAAABIAsAAIAAgDQAAgKgGgHQgFgGgLAAQgIAAgGAHgAr8ApQgJgKAAgVIAAg2IASAAIAAA2QAAAPAEAGQAFAGAJAAQAJAAAHgEQAFgEAEgHIAAhCIARAAIAABdIgQAAIgBgOQgEAHgIAEQgGAFgKAAQgPAAgJgKgAM7AxIAAhdIAQAAIACAOQAEgIAFgEQAGgEAJAAIADAAIADABIgDAQIgIgBQgHAAgFAEQgEADgDAGIAABCgAK8AxIgggsIgLAAIAAAsIgRAAIAAiHIARAAIAABPIALAAIAaglIAWAAIghArIAlAygAHcAxIAAhdIAQAAIACAOQAEgIAGgEQAFgEAJAAIADAAIADABIgDAQIgJgBQgGAAgFAEQgEADgDAGIAABCgAFtAxIAAh+IApAAQAVAAALAIQALAJAAARQAAAJgFAHQgGAGgIAEQALACAHAJQAHAHAAAMQAAARgMAKQgLAJgUAAgAF+AjIAeAAQAMAAAHgGQAGgFAAgLQAAgLgGgFQgFgGgMAAIggAAgAF+gXIAcAAQAKAAAGgFQAGgFAAgKQAAgKgHgFQgGgGgNAAIgYAAgAhTAxIAAiHIASAAIAACHgAm9AxIAAhdIAPAAIACAOQAEgIAGgEQAGgEAIAAIADAAIAEABIgDAQIgJgBQgHAAgFAEQgEADgDAGIAABCgApvAxIAAiHIARAAIAACHgAqdAxIAAiHIARAAIAACHgAtqAxIAAh+IBUAAIAAANIhDAAIAAAtIA6AAIAAANIg6AAIAAA3g");
	this.shape_1.setTransform(102.2,15.9);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,191.8,27.8);


(lib.t3a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("AgNANQgFgFgBgIQABgHAFgGQAGgGAHAAQAHAAAHAGQAFAGAAAHQAAAIgFAFQgHAHgHAAQgHAAgGgHg");
	this.shape.setTransform(2,14);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiABXIAAiBIANAAIADAMQAEgHAHgEQAHgDAKAAQARAAAKAOQAKAOAAAVIAAACQAAAUgKANQgKANgRAAQgJAAgHgDQgGgDgFgGIAAAugAhmgbQgGAEgDAGIAAArQADAGAGAEQAFADAIAAQAMAAAGgJQAHgJAAgOIAAgCQAAgOgHgLQgGgKgNAAQgHAAgFADgAD4AnQgMgOAAgVIAAgCQAAgTAMgNQALgOAUAAQAUAAALAOQALANAAATIAAACQAAAWgLANQgLAOgUAAQgUAAgLgOgAEEgVQgGAKAAANIAAACQAAAPAGAKQAGAKANAAQAMAAAHgKQAGgKAAgPIAAgCQAAgNgGgKQgHgJgMAAQgNAAgGAJgACAAuQgGgGAAgOIAAg4IgPAAIAAgMIAPAAIAAgXIARAAIAAAXIASAAIAAAMIgSAAIAAA4QAAAHADADQADACAEAAIAEAAIADgBIACAMQgCACgEABIgHABQgLAAgGgHgAAWAtQgIgIAAgNQAAgOALgHQALgGATAAIATAAIAAgJQAAgJgFgFQgFgEgKAAQgIAAgFAEQgFAEAAAGIgRAAIAAgBQgBgKALgIQAKgJAQAAQAQAAAKAIQAKAIAAAQIAAAsIABAJIACAKIgSAAIgCgIIAAgGQgFAGgIAFQgIAFgJAAQgOAAgIgIgAAmAMQgHAFAAAHQAAAHAEADQAEAEAIAAQAJAAAIgFQAIgFACgGIAAgPIgUAAQgKAAgGAFgAjfAuQgGgGAAgOIAAg4IgPAAIAAgMIAPAAIAAgXIARAAIAAAXIASAAIAAAMIgSAAIAAA4QAAAHADADQADACAEAAIAEAAIADgBIACAMQgCACgEABIgHABQgLAAgGgHgAlCArQgKgJAAgMIABgBIAQAAQAAAJAHAFQAGAEAJAAQAJAAAFgEQAGgDAAgHQAAgFgFgEQgEgEgMgCQgSgEgIgGQgJgFAAgLQAAgMAKgIQAKgIAPAAQARAAAKAIQAKAJgBAMIAAABIgQAAQAAgHgGgEQgFgFgJAAQgJAAgEAEQgFAEAAAFQAAAGAEADQAEADAMADQASACAJAHQAJAGAAALQAAANgKAIQgLAIgQAAQgSAAgLgKgAmgAnQgMgNAAgVIAAgEQAAgSANgOQAMgNAQAAQATAAAKALQAKAMAAATIAAAJIg+AAIAAABQAAANAHAJQAHAJAMAAQAJAAAGgCQAHgDAFgEIAGALQgFAFgIADQgIAEgMAAQgUAAgMgOgAmSgXQgGAHgBALIAAABIAsAAIAAgDQAAgKgGgHQgFgGgLAAQgJAAgGAHgAIHAzIAAg3QAAgOgFgGQgFgGgKAAQgIAAgGAGQgFAGgBAKIAAA7IgSAAIAAg3QAAgOgFgGQgFgGgJAAQgIAAgFADQgFADgDAGIAABFIgRAAIAAhdIAPAAIACAMQAEgHAHgDQAIgEAJAAQAJAAAHAEQAHAFAEAIQAEgIAHgEQAIgFAKAAQAOAAAJAKQAIAKAAAUIAAA3gAFWAzIAAhdIAQAAIABAOQAFgIAFgEQAGgEAIAAIAEAAIADABIgDAQIgJgBQgGAAgFAEQgFADgCAGIAABCgAC6AzIAAhRIgPAAIAAgMIAPAAIAAgMQAAgQAIgIQAHgIAPAAIAGAAIAGACIgCANIgDgBIgFAAQgIAAgDAFQgEAEAAAJIAAAMIAUAAIAAAMIgUAAIAABRgAgZAzIAAiHIASAAIAACHgAoXAzIAAh+IApAAQAUAAAMAIQALAJAAARQAAAJgFAHQgGAGgJAEQAMACAHAJQAGAHAAAMQAAARgLAKQgMAJgTAAgAoGAlIAeAAQAMAAAGgGQAHgFAAgLQAAgLgGgFQgFgGgMAAIggAAgAoGgVIAcAAQAKAAAGgFQAGgFAAgKQAAgKgHgFQgGgGgNAAIgYAAg");
	this.shape_1.setTransform(68.3,15.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,125.3,27.8);


(lib.t22 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AHPEiQgZgLgTgTQgTgTgKgYQgLgbAAgcIAAnIIBVAAIAAHAQAAAeAPAQQANAPAYAAQAXAAAOgPQAPgQAAgeIAAnAIBVAAIAAHIQAAAcgLAbQgKAYgTATQgTATgZALQgZAKgcAAQgcAAgZgKgABvEjQgagKgTgRQgVgUgMgZQgMgdAAgiIAAk3QAAgiAMgdQAMgaAVgTQATgSAagJQAZgJAaAAQAbAAAZAJQAZAJAUASQAVATAMAaQAMAdAAAiIAAE3QAAAigMAdQgMAZgVAUQgUARgZAKQgZAJgbAAQgaAAgZgJgAB6jIQgRARAAAcIAAE3QAAAdARAQQAQAOAYAAQAZAAAQgOQARgQAAgdIAAk3QAAgcgRgRQgQgOgZAAQgYAAgQAOgAMUEnIAAn9IhiAAIAAhQIEZAAIAABQIhiAAIAAH9gAjYEnIAAj5Ih0lUIBaAAIBEDrIABAAIBFjrIBZAAIh0FUIAAD5gAmkEnIgZh/Ih0AAIgYB/IhVAAICEpNIBHAAICDJNgAnNBZIgpjUIgCAAIgqDUIBVAAgAvKEnIAApNICAAAQAjAAAaAKQAbAJAVAWQAWAXAIAgQAIAeAAA2QAAAqgEAYQgFAdgPAWQgSAegdAPQgeARgtAAIgsAAIAADmgAt1gOIApAAQAZABAPgIQAOgGAGgOQAKgSAAg2QAAg1gJgTQgGgOgOgHQgOgIgYAAIgsAAg");
	this.shape.setTransform(99.6,34.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.5,2.8,202.2,102.5);


(lib.t2roll = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgBeBxwIBej4IAAgBIgMAEQgJACgOAAQgXAAgSgLQgTgKgLgRQgHgLgEgOQgFgOgBgaQgBgaAAguQAAgmABgWQABgWAFgNQAEgNAIgNQAQgbAcgPQAbgPAiAAQAiABAbAPQAcAOARAbQAIANAEANQAEANACAWQACAWAAAmQAAAkgCAVQgCAUgDAPQgDAOgGAPIhuEpgEgAbBp9QgMALgBATIAABuQABATAMAMQAMALAPAAQAQAAAMgLQANgMAAgTIAAhuQAAgTgNgLQgMgMgQAAQgPAAgMAMgEgA9BmGQgagOgOgXQgJgMgFgOQgFgNgCgVQgCgVAAglQgBgrADgbQACgaAJgRQAJgRAUgPQgUgPgJgQQgJgQgCgWQgDgWABgjQAAgfACgVQAEgTAHgOQAGgPALgNQARgWAZgMQAZgMAbAAQAcAAAZAMQAZAMARAWQALANAHAPQAHAOADATQADAVAAAfQAAAjgCAWQgCAWgKAQQgJAQgTAPQATAPAJARQAKARACAaQACAbAAArQAAAkgCAWQgDAVgFANQgFAOgIAMQgPAXgaAOQgZAPglABQgjgBgagPgEgAbBiGQgMAMgBARIAAB1QABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAh1QAAgRgNgMQgMgMgQAAQgPAAgMAMgEgAbBeeQgMAMgBARIAABXQABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAhXQAAgRgNgMQgMgMgQAAQgPAAgMAMgEgBpBayICSn/IhbAAIAABEIhKAAIAAiUID6AAIAABVIiOH6gEgA8BPIQgcgPgRgbQgIgMgEgNQgEgNgCgWQgBgWAAgmQAAgkABgVQACgUADgOQAEgPAFgPIBtkpIBfAAIhfD4IAAACQAFgDAIgCQAJgCAOAAQAXAAASALQAUAKAKARQAIAKAEAOQAEAPABAaQACAaAAAuQAAAmgCAWQgBAWgFANQgEANgHAMQgRAdgcAOQgbAPgjAAQghgBgbgPgEgAbBLMQgMAMgBATIAABuQABAUAMALQAMALAPAAQAQAAAMgLQANgLAAgUIAAhuQAAgTgNgMQgMgLgQAAQgPAAgMALgEgA9BDpQgdgPgRgcQgRgdgBgnIAAgZIBVAAIAAAWQAAAWAMALQAMAMARAAQATAAAKgMQALgLAAgVIAAiLQAAgSgLgLQgLgNgSAAQgMAAgJAGQgJAGgEAIIgHAMIhLAAIAAk+IDxAAIAABQIimAAIAACfQAMgMASgHQAQgIAWgBQAsAAAbAbQAaAbABAzIAACZQgBAngRAdQgSAcgcAPQgcAQgiAAQghAAgcgQgEAAVA4VIAAhYIimAAIAAhQIB6mnIBYAAIh+GnIBSAAIAAioIBVAAIAACoIAoAAIAABQIgoAAIAABYgEgA3AsuQgdgMgUgcQgUgbAAguIAAgxIBUAAIAAAsQAAAVALAMQALANASAAQATAAALgNQALgMAAgXIAAhUQABghgOgMQgOgMgmACIAAhLQAjABAPgLQAPgKAAgfIAAhNQAAgSgLgLQgLgMgTAAQgVABgJANQgKAOAAANIAAAwIhUAAIAAgwQAAgkARgcQARgcAdgRQAdgQAhgBQAjABAXANQAXANALAPQAMANAHAOQAHAPADAXQAEAXAAAlQAAAogDAWQgDAWgMAMQgLANgYAOQAaAQALAPQALAPADAYQACAZAAApQAAAmgCAWQgCAWgFANQgFAOgJAMQgPAXgaAPQgZAPglABIgBAAQgbAAgbgNgEgB8AhXIAAhQICWkfQALgWACgQQACgSAAgXQAAgPgCgPQgBgPgJgKQgJgJgUgBQgRAAgLALQgLAKgBAVIAAAxIhUAAIAAgvQAAgkARgcQARgeAcgRQAdgRAhgBQAsAAAcAWQAcAUANAhQANAiAAAoQAAAbgCATQgCASgGARQgFARgOAZIh6DvICXAAIAABVgAgYV4IAAn2IhVA/IAAhaIBVg+IBSAAIAAJPgAg9KOQgcgPgSgdQgRgcAAgnIAAlbQAAgnARgcQASgdAcgPQAdgQAgAAQAiAAAcAQQAcAPASAdQARAcABAnIAAFbQgBAngRAcQgSAdgcAPQgcAQgiAAQggAAgdgQgAgcCmQgLAMgBASIAAFbQABATALALQALAMARAAQASAAALgMQAMgLAAgTIAAlbQAAgSgMgMQgLgMgSAAQgRAAgLAMgAhehEIBej4IAAgBIgMAEQgJADgOAAQgXgBgSgLQgTgKgLgRQgHgKgEgOQgFgPgBgaQgBgaAAguQAAgmABgWQABgWAFgMQAEgNAIgNQAQgcAcgPQAbgPAiAAQAiABAbAOQAcAPARAcQAIANAEANQAEAMACAWQACAWAAAmQAAAkgCAVQgCAUgDAPQgDAOgGAPIhuEpgAgbo4QgMAMgBATIAABuQABAUAMAKQAMAMAPAAQAQAAAMgMQANgKAAgUIAAhuQAAgTgNgMQgMgLgQAAQgPAAgMALgAg9stQgagPgOgWQgJgMgFgOQgFgOgCgVQgCgWAAgjQgBgtADgaQACgaAJgRQAJgRAUgPQgUgPgJgQQgJgQgCgWQgDgWABgjQAAggACgTQAEgVAHgNQAGgPALgNQARgWAZgMQAZgMAbAAQAcAAAZAMQAZAMARAWQALANAHAPQAHANADAVQADATAAAgQAAAjgCAWQgCAWgKAQQgJAQgTAPQATAPAJARQAKARACAaQACAaAAAtQAAAjgCAWQgDAVgFAOQgFAOgIAMQgPAWgaAPQgZAPglAAQgjAAgagPgAgbwuQgMALgBATIAAB0QABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAh0QAAgTgNgLQgMgMgQAAQgPAAgMAMgAgb0WQgMALgBATIAABVQABATAMALQAMALAPABQAQgBAMgLQANgLAAgTIAAhVQAAgTgNgLQgMgLgQgBQgPABgMALgAhp4CICSn/IhbAAIAABEIhKAAIAAiUID6AAIAABVIiOH6gEgA8gjsQgcgPgRgaQgIgNgEgNQgEgOgCgVQgBgWAAgmQAAgjABgWQACgVADgOQAEgOAFgPIBtkpIBfAAIhfD4IAAACQAFgDAIgDQAJgBAOAAQAXAAASAKQAUALAKAQQAIAMAEAOQAEAOABAaQACAaAAAuQAAAmgCAWQgBAVgFAOQgEANgHANQgRAcgcAOQgbAPgjAAQghAAgbgQgEgAbgnoQgMAMgBATIAABuQABATAMAMQAMALAPAAQAQAAAMgLQANgMAAgTIAAhuQAAgTgNgMQgMgKgQgBQgPABgMAKgEgA9gvKQgdgQgRgcQgRgcgBgoIAAgZIBVAAIAAAVQAAAXAMAMQAMALARAAQATAAAKgLQALgMAAgVIAAiKQAAgTgLgLQgLgMgSgBQgMAAgJAHQgJAGgEAGIgHAOIhLAAIAAk/IDxAAIAABQIimAAIAACfQAMgMASgHQAQgIAWAAQAsAAAbAbQAaAaABAzIAACZQgBAogRAcQgSAcgcAQQgcAPgiAAQghAAgcgPgEAAVg6fIAAhYIimAAIAAhQIB6mnIBYAAIh+GnIBSAAIAAioIBVAAIAACoIAoAAIAABQIgoAAIAABYgEgA3hGFQgdgNgUgcQgUgbAAguIAAgwIBUAAIAAAsQAAATALANQALANASAAQATAAALgNQALgMAAgXIAAhUQABghgOgMQgOgLgmABIAAhLQAjABAPgKQAPgLAAgfIAAhNQAAgSgLgMQgLgLgTAAQgVABgJANQgKANAAAOIAAAxIhUAAIAAgyQAAgjARgcQARgcAdgRQAdgQAhgBQAjABAXANQAXANALAPQAMAMAHAPQAHAPADAXQAEAXAAAlQAAAogDAWQgDAWgMANQgLANgYAOQAaAPALAPQALAQADAXQACAYAAAqQAAAmgCAWQgCAWgFANQgFAOgJAMQgPAXgaAPQgZAQglAAIgBAAQgbAAgbgMgEgB8hRdIAAhQICWkgQALgUACgRQACgRAAgYQAAgPgCgPQgBgPgJgKQgJgJgUgBQgRAAgLALQgLALgBAUIAAAwIhUAAIAAgvQAAgjARgcQARgeAcgRQAdgSAhAAQAsABAcAUQAcAVANAhQANAiAAAoQAAAcgCASQgCASgGARQgFARgOAZIh6DwICXAAIAABUgEgAYhc8IAAn1IhVA+IAAhZIBVg/IBSAAIAAJPgEgA9homQgcgPgSgcQgRgdAAgnIAAlbQAAgnARgcQASgdAcgQQAdgPAgAAQAiAAAcAPQAcAQASAdQARAcABAnIAAFbQgBAngRAdQgSAcgcAPQgcAQgiAAQggAAgdgQgEgAchwOQgLAMgBASIAAFbQABASALAMQALAMARAAQASAAALgMQAMgMAAgSIAAlbQAAgSgMgMQgLgMgSAAQgRAAgLAMg");
	this.shape.setTransform(98.5,748.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(55,0,621.2,1476.3);


(lib.t1d = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ADaA0IAAgpIgpAAIAAApIgYAAIAAhnIAYAAIAAAsIApAAIAAgsIAYAAIAABngAA1A0IAAhTIgeAAIAAgUIBTAAIAAAUIgdAAIAABTgAgsA0IAAhnIAXAAIAABngAiNA0IgXhHIgXBHIgRAAIglhnIAaAAIAUA7IATg7IAYAAIATA7IAVg7IAZAAIglBng");
	this.shape.setTransform(-2.2,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-26.4,0,48.8,22.3);


(lib.t1c = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFhAjIAOgRQARAPAOAAQAGAAAFgDQADgDAAgFQAAgEgEgDQgEgDgMgCQgRgFgJgFQgJgGAAgPQAAgPALgJQALgHAQgBQALAAAKAEQALAEAHAGIgMARQgOgKgOAAQgGAAgDACQgEADABAFQAAAFADACQAFADAOADQAQAEAIAGQAIAHAAAOQAAAOgKAJQgLAJgRgBQgZAAgUgSgABAAmQgQgQAAgWQAAgVAQgQQAQgPAXgBQAXABAQAPQAQAQAAAVQAAAWgQAQQgQAPgXAAQgXAAgQgPgABRgWQgJAKAAAMQAAANAJAKQAJAKANAAQANAAAJgKQAJgKAAgNQAAgMgJgKQgJgKgNAAQgNAAgJAKgAmjAmQgQgQAAgWQAAgVAQgQQAQgPAXgBQAXABAQAPQAQAQAAAVQAAAWgQAQQgQAPgXAAQgXAAgQgPgAmSgWQgJAKAAAMQAAANAJAKQAJAKANAAQANAAAJgKQAJgKAAgNQAAgMgJgKQgJgKgNAAQgNAAgJAKgAEaA0Igzg/IAAA/IgXAAIAAhmIAWAAIA0BBIAAhBIAWAAIAABmgAgWA0IAAhmIAWAAIAABmgAh6A0IAAhSIgfAAIAAgUIBTAAIAAAUIgdAAIAABSgAkTA0IAAhmIAlAAQAYAAALAJQALAKAAATQAAARgLAJQgMAKgXgBIgOAAIAAAdgAj8ADIAQAAQAMAAAEgDQAEgFAAgIQAAgJgFgFQgGgDgLAAIgOAAg");
	this.shape.setTransform(-1.5,11.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-45.1,0,87.3,22.3);


(lib.t1b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEvA0IAAgqIgkg9IAZAAIAXAnIAWgnIAaAAIgkA9IAAAqgADNA0IgXgiIgQAAIAAAiIgXAAIAAhnIAnAAQAZAAAKAIQAKAIAAATQAAAXgTAIIAaAlgACmAAIARAAQAMAAAEgEQAFgEgBgIQABgJgFgCQgEgDgMgBIgRAAgABLA0IgKgXIgsAAIgKAXIgWAAIArhnIAXAAIAtBngAAeAJIAaAAIgMgcgAhNA0Igyg/IAAA/IgXAAIAAhnIAWAAIAzBCIAAhCIAYAAIAABngAjlA0IAAhnIAYAAIAABngAlqA0IAAhnIApAAQALAAAHACQAIADADAEQAIAJAAAKQgBAMgHAGIgEADIgEACQAKAAAGAHQAGAGAAAKQAAALgIAJQgJAJgVAAgAlSAgIAQAAQAJAAAFgDQAGgCAAgHQgBgIgFgCQgFgCgMAAIgNAAgAlSgIIAKAAQAKAAAFgCQAFgCgBgHQAAgIgDgCQgFgCgLAAIgKAAg");
	this.shape.setTransform(-0.7,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-37.1,0,72.7,22.3);


(lib.t1a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ADvA0IAAhnIBMAAIAAAVIg0AAIAAAWIAvAAIAAARIgvAAIAAAXIA1AAIAAAUgABeA0IAAhnIAlAAQAcAAAPAOQAPAOAAAXQAAAXgPAOQgPAPgdAAgAB1AgIAPAAQAQAAAJgJQAIgIAAgPQAAgOgIgIQgJgJgSAAIgNAAgAAaA0IgJgXIgqAAIgKAXIgZAAIAthnIAVAAIAtBngAgQAJIAYAAIgLgcgAh7A0IgXgiIgQAAIAAAiIgXAAIAAhnIAnAAQAZAAAKAIQALAIAAATQAAAXgUAIIAaAlgAiiAAIARAAQAMAAAEgEQAFgEAAgIQAAgJgFgCQgEgDgLgBIgSAAgAkdA0IAAhTIgeAAIAAgUIBTAAIAAAUIgeAAIAABTg");
	this.shape.setTransform(-1.7,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-33.3,0,63.7,22.3);


(lib.Symbol1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQEaQgRgRAAgdIAAg1QAAgfARgSQASgSAigBQAgABATASQATASAAAfIAAA1QAAAdgTARQgTASggAAQgiAAgSgSgAA1CrQgGAHAAAJIAAApQAAAKAGAFQAGAHAJAAQAIAAAGgHQAGgFAAgKIAAgpQAAgJgGgHQgGgFgIgBQgJABgGAFgAh/EnIDIpNIA3AAIjJJNgAh2iEQgTgQAAgdIAAg2QAAgfATgSQASgSAhgBQAhABATASQARASAAAfIAAA2QAAAdgRAQQgTARghABQghgBgSgRgAhRjyQgGAFgBAKIAAApQABAJAGAHQAGAGAIAAQAJAAAGgGQAGgHAAgJIAAgpQAAgKgGgFQgGgHgJAAQgIAAgGAHg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-13.8,-30,27.8,60.1);


(lib.logo_mc = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2E").s().p("AAZBEQgpAAgJgCQgRgDgHgJQgIgIgBgPQgBgGAAgXQAAgYABgHQADgRAJgIQAJgKAdgCIAogBQAuAAAMADQATAEAGAOQADAIAAASIgpAAQAAgGgCgEQgFgFgLAAIg/ABQgIACgCAFQgDAGAAAYQAAASACAEQACAJALACQAHABASAAIAmAAQAOgCACgJIAAgKIg1AAIAAgXIBeAAIAAARQAAAcgDAJQgEAKgIAFQgJAFgQABgAEMBDIAAgzIhfAAIAAAzIgqAAIAAiFIAqAAIAAAyIBfAAIAAgyIArAAIAACFgAhyBDIAAiFIAqAAIAACFgAisBDIAAgzIhfAAIAAAzIgrAAIAAiFIArAAIAAAyIBfAAIAAgyIArAAIAACFg");
	this.shape.setTransform(36.2,18);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AhrBCQgQgDgHgIQgIgGgDgQQgCgJAAgYIABgXQAAgGADgIQADgOALgHQALgHAagCIAlAAQAwAAALABQATADAGAKQAIAKACANQABAMABATQgBAfgFALQgEALgLAGQgJAEgHACIgXACIgiAAQgvAAgLgCgAhRghQgMABgEAIQgDAFAAATQAAATADAGQAEAHANACQAIACAXAAQAfAAAHgDQAJgBACgGQACgFAAgJIAAgNQAAgSgCgGQAAgFgEgBQgFgDgIAAIgfAAQgdAAgEABgAk4BDIAAiGIArAAIAABkIBxAAIAAAigADLBDIgYhTIgaBTIg5AAIgziGIAtAAIAhBcIAdhcIA2AAIAcBcIAihcIAtAAIg0CGg");
	this.shape_1.setTransform(111.2,24.9);

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E1E0DF").s().p("AAAB0IlpBAIAAkmIFphBIFpBBIAAEmg");
	this.shape_2.setTransform(36.2,18);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6B6B6A").s().p("AloBzIAAkmIFoBAIFphAIAAEmIlpBAg");
	this.shape_3.setTransform(110.8,24.9);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,147,42.9);


(lib.gbcurve = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EAvWAHCIiRAAMhDaAAAI5TAAIirAAInLAAQhVmwBLnJIABgHIHUgDICrAAIZTAAMBDaAAAICRAAIK2AAIAAODg");
	this.shape.setTransform(369,45);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.5,0,745,90);


(lib.bgimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg11111();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib._bg = function() {
	this.initialize();

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu2AAAMAAAAnDg");
	this.shape.setTransform(364,45,2.427,0.36);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib._clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_46 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(46).call(this.frame_46).wait(1));

	// t3c
	this.instance = new lib.t3c();
	this.instance.setTransform(574.7,46.8,1,1,0,0,0,98.7,13.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({x:554.7,alpha:1},7,cjs.Ease.get(0.9)).wait(30));

	// t3b
	this.instance_1 = new lib.t3b();
	this.instance_1.setTransform(342.2,46.8,1,1,0,0,0,96.2,13.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({x:329.2,alpha:1},7,cjs.Ease.get(0.9)).wait(35));

	// t3a
	this.instance_2 = new lib.t3a();
	this.instance_2.setTransform(158.8,46.8,1,1,0,0,0,62.8,13.8);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:138.8,alpha:1},7,cjs.Ease.get(0.9)).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(96,40,122,17.5);


(lib.t2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_49 = function() {
		this.stop();
		exportRoot.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(1));

	// t2.2
	this.instance = new lib.t22();
	this.instance.setTransform(426.5,22.1,1,1,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(33).to({_off:false},0).to({x:316.5,alpha:1},5,cjs.Ease.get(0.9)).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
		exportRoot.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// %
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQEbQgRgSAAgcIAAg2QAAggARgSQASgRAigBQAgABATARQATASAAAgIAAA2QAAAcgTASQgTAQggABQgigBgSgQgAA1CrQgGAGAAAKIAAAqQAAAIAGAGQAGAHAJAAQAIAAAGgHQAGgGAAgIIAAgqQAAgKgGgGQgGgFgIgBQgJABgGAFgAh/EnIDIpNIA3AAIjJJNgAh2iEQgTgRAAgcIAAg2QAAgfATgSQASgTAhAAQAhAAATATQARASAAAfIAAA2QAAAcgRARQgTASghAAQghAAgSgSgAhRjzQgGAHgBAJIAAApQABAKAGAFQAGAHAIAAQAJAAAGgHQAGgFAAgKIAAgpQAAgJgGgHQgGgFgJgBQgIABgGAFg");
	this.shape.setTransform(379.1,45.2);

	this.instance = new lib.Symbol1();
	this.instance.setTransform(410.1,45.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape,p:{x:379.1}}]},1).to({state:[{t:this.shape,p:{x:396.1}}]},16).to({state:[{t:this.instance}]},8).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance}]},5).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25).to({_off:false},0).wait(3).to({x:285.1},5,cjs.Ease.get(0.9)).wait(12));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9EcQgdgPgRgdQgRgcgBgnIAAlZQABgnARgcQARgdAdgPQAdgQAgAAQAiAAAcAQQAcAPARAdQASAcAAAnIAAFZQAAAngSAcQgRAdgcAPQgcAQgiAAQggAAgdgQgAgcjKQgMAMAAASIAAFZQAAATAMALQALAMARAAQASAAALgMQAMgLgBgTIAAlZQABgSgMgMQgLgMgSAAQgRAAgLAMg");
	this.shape_1.setTransform(223.6,45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9EdQgdgQgRgcQgRgcAAgoIAAlZQAAgnARgdQARgcAdgQQAcgPAhAAQAiAAAcAPQAcAQARAcQASAdAAAnIAAFZQAAAogSAcQgRAcgcAQQgcAPgiAAQghAAgcgPgAgcjKQgMAMAAASIAAFZQAAASAMAMQALAMARAAQARAAAMgMQAMgMAAgSIAAlZQAAgSgMgMQgMgLgRgBQgRABgLALg");
	this.shape_2.setTransform(255.6,44.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah8EpIAAhQICWkdQALgVACgRQACgRgBgXQABgQgCgPQgCgPgIgJQgKgKgTgBQgSAAgLAMQgKAKgBAUIAAAxIhUAAIAAgvQAAgkARgcQAQgeAdgRQAdgRAhgBQAsABAcAVQAbAUANAhQAOAjAAAoQAAAbgCATQgCARgGASQgFARgOAYIh6DuICXAAIAABUg");
	this.shape_3.setTransform(193.7,44.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},33).wait(12));

	// 1
	this.instance_1 = new lib.t2roll();
	this.instance_1.setTransform(353,708.6,1,1,0,0,0,71,640);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({y:634.6},2).wait(1).to({y:-100.4},0).to({x:228},5,cjs.Ease.get(0.9)).to({_off:true},1).wait(11));

	// 10
	this.instance_2 = new lib.t2roll();
	this.instance_2.setTransform(338,655.6,1,1,0,0,0,71,640);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(17).to({_off:false},0).to({y:-562.4},7).wait(1).to({x:321.6,y:-100.4},0).wait(3).to({x:196.6},5,cjs.Ease.get(0.9)).to({_off:true},1).wait(11));

	// 100
	this.instance_3 = new lib.t2roll();
	this.instance_3.setTransform(321,635,1,1,0,0,0,71,640);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).wait(7).to({x:318.6,y:665.6},0).to({x:321,y:-759.4},8).wait(1).to({x:306.6,y:-246.4},0).wait(8).to({x:290.6,y:-247.4},0).wait(3).to({x:165.6},5,cjs.Ease.get(0.9)).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// t1d
	this.instance = new lib.t1d();
	this.instance.setTransform(129,14.1,1,1,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1c
	this.instance_1 = new lib.t1c();
	this.instance_1.setTransform(50,14.1,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1b
	this.instance_2 = new lib.t1b();
	this.instance_2.setTransform(-41,14.1,1,1,0,0,0,0,11.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1a
	this.instance_3 = new lib.t1a();
	this.instance_3.setTransform(-120,14.1,1,1,0,0,0,0,11.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{on:1,off:7});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6).call(this.frame_6).wait(6).call(this.frame_12).wait(1));

	// GET STARTED
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C2F35").s().p("AixAhIANgQQAQAOAOAAQAGAAADgDQADgDAAgEQAAgEgDgDQgEgDgLgCQgRgEgIgFQgIgGAAgOQAAgOALgIQAKgHAOAAQAKAAAKADQAKADAHAHIgLAQQgNgKgNAAQgGAAgDACQgDADAAAFQAAAEAEADQAEACAOADQAOADAHAFQAIAIAAANQAAANgKAIQgKAIgQAAQgXAAgTgRgAoHAkQgPgPAAgVQAAgUAPgPQAPgOAVAAQAVAAAQANIgMARQgGgFgGgDQgFgCgHAAQgMAAgJAJQgIAIAAAMQAAAOAIAIQAIAJALAAQAMAAAHgFIAAgaIAWAAIAAAiQgOAQgaAAQgWAAgOgOgAG+AxIAAhgIAiAAQAbAAAOANQAOANAAAVQAAAWgOANQgOAOgcAAgAHUAeIANAAQAQAAAIgIQAIgHAAgPQAAgMgIgIQgIgIgRAAIgMAAgAFYAxIAAhgIBHAAIAAATIgxAAIAAAVIAsAAIAAAQIgsAAIAAAVIAyAAIAAATgAENAxIAAhNIgcAAIAAgTIBNAAIAAATIgbAAIAABNgADEAxIgWgfIgPAAIAAAfIgWAAIAAhgIAlAAQAXAAAKAIQAKAIAAAQQAAAWgTAHIAZAjgACfAAIAQAAQALAAAEgCQAEgFAAgIQAAgHgEgDQgEgDgLAAIgQAAgABdAxIgKgVIgpAAIgJAVIgXAAIAqhgIAWAAIAqBggAAzAIIAYAAIgMgagAgzAxIAAhNIgbAAIAAgTIBNAAIAAATIgcAAIAABNgAkkAxIAAhNIgcAAIAAgTIBNAAIAAATIgbAAIAABNgAmdAxIAAhgIBGAAIAAATIgwAAIAAAVIArAAIAAAQIgrAAIAAAVIAyAAIAAATg");
	this.shape.setTransform(95.7,46.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13));

	// gb-curve
	this.instance = new lib.gbcurve();
	this.instance.setTransform(150,134.8,1,1,0,0,0,150,134.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},6).to({alpha:1},6).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F0F0F0").s().p("A1NHCI5TAAIirAAInLAAQhVmwBLnJIABgHIHUgDICrAAIZTAAMBORAAAIAAODg");
	this.shape_1.setTransform(361.8,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.5,0,745,90);


// stage content:
(lib.highlow_728x901b_AUDandUSD = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.enableMouseOver(20);
		
		this.loopNumber = 0 ;
		
		// CLICKTHROUGH
		this.clickTagBtn.addEventListener("click", function () {
			console.log("clickthrough");
			window.open(window.clickTAG);
		});
		
		// CTA
		this.clickTagBtn.addEventListener("mouseover", function () {
			exportRoot.bt.gotoAndPlay("on");
		});
		
		this.clickTagBtn.addEventListener("mouseout", function () {
			exportRoot.bt.gotoAndPlay("off");
		});
	}
	this.frame_56 = function() {
		this.stop();
	}
	this.frame_200 = function() {
		if(this.loopNumber >= 1){
			console.log("STOP BANNER");
			this.stop();
		} else {
			this.loopNumber++;
			console.log("RESTART: " + this.loopNumber);
		}
	}
	this.frame_207 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(56).call(this.frame_56).wait(144).call(this.frame_200).wait(7).call(this.frame_207).wait(1));

	// clickTagBtn
	this.clickTagBtn = new lib._clicktag();
	this.clickTagBtn.setTransform(0,0,4.55,0.15);
	new cjs.ButtonHelper(this.clickTagBtn, 0, 1, 2, false, new lib._clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickTagBtn).wait(208));

	// Border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("Eg43gHBMBxvAAAIAAODMhxvAAAg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(208));

	// bt
	this.bt = new lib.btn();
	this.bt.setTransform(888,149.5,1,1,0,0,0,150,149.5);

	this.timeline.addTween(cjs.Tween.get(this.bt).wait(162).to({x:688,y:149.6,alpha:0},0).to({alpha:1},7).wait(32).to({x:888,y:149.5},6,cjs.Ease.get(-0.9)).wait(1));

	// t6
	this.instance = new lib.t6();
	this.instance.setTransform(239.1,58.1,1,1,0,0,0,0,12.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(158).to({_off:false},0).to({alpha:1},6).wait(37).to({x:-250.9},6,cjs.Ease.get(-0.9)).wait(1));

	// t5
	this.instance_1 = new lib.t5();
	this.instance_1.setTransform(240.3,35.1,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(155).to({_off:false},0).to({alpha:1},6).wait(40).to({x:-249.7},6,cjs.Ease.get(-0.9)).wait(1));

	// logo
	this.instance_2 = new lib.logo_mc();
	this.instance_2.setTransform(110.5,42.8,1,1,0,0,0,64.5,18.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(151).to({_off:false},0).to({alpha:1},7).wait(43).to({x:-379.5},6,cjs.Ease.get(-0.9)).wait(1));

	// t4
	this.instance_3 = new lib.t3();
	this.instance_3.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(64).to({_off:false},0).wait(45).to({y:349},8,cjs.Ease.get(0.9)).to({_off:true},1).wait(90));

	// bg
	this.instance_4 = new lib.gbcurve();
	this.instance_4.setTransform(170.8,-16.5,0.6,1.349);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(62).to({_off:false},0).wait(1).to({scaleX:0.86,x:50.8},0).wait(1).to({regX:150,regY:134.8,scaleX:1,scaleY:1,x:148.5,y:134.8},0).wait(45).to({x:149.5},0).to({x:891},8,cjs.Ease.get(0.9)).wait(26).to({x:688},10,cjs.Ease.get(-1)).to({_off:true},16).wait(39));

	// bg
	this.instance_5 = new lib.gbcurve();
	this.instance_5.setTransform(891,134.8,1,1,0,0,0,150,134.8);
	this.instance_5._off = true;
	this.instance_5.filters = [new cjs.ColorFilter(0, 0, 0, 1, 63, 63, 63, 0)];
	this.instance_5.cache(-5,-2,749,94);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(143).to({_off:false},0).to({x:150.5},10,cjs.Ease.get(-1)).wait(48).to({alpha:0},6).wait(1));

	// web-img
	this.instance_6 = new lib.webimg();
	this.instance_6.setTransform(132,70,1,1,0,0,0,132,70);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(109).to({_off:false},0).to({y:-20},44).to({_off:true},1).wait(54));

	// t2
	this.instance_7 = new lib.t2copy();
	this.instance_7.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(38).to({_off:false},0).wait(19).to({scaleX:8.77,scaleY:8.77,x:-1515,y:750},4,cjs.Ease.get(-1)).to({_off:true},1).wait(146));

	// 728x90_mask
	this.instance_8 = new lib._728x90_mask();
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(42).to({_off:false},0).to({_off:true},15).wait(151));

	// t2
	this.instance_9 = new lib.t2();
	this.instance_9.setTransform(150,215,1,1,0,0,0,150,125);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(38).to({_off:false},0).to({y:170},4,cjs.Ease.get(-0.9)).to({y:125},4,cjs.Ease.get(0.9)).wait(11).to({scaleX:8.77,scaleY:8.77,x:-1515,y:750},4,cjs.Ease.get(-1)).to({_off:true},1).wait(146));

	// t1
	this.instance_10 = new lib.t1();
	this.instance_10.setTransform(364.5,69.5,1,1,0,0,0,0,38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(38).to({y:39.5},4,cjs.Ease.get(-0.9)).to({y:-0.5},4,cjs.Ease.get(0.9)).to({_off:true},1).wait(161));

	// bg
	this.instance_11 = new lib.bgimg();
	this.instance_11.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(208));

	// bg
	this.instance_12 = new lib._bg();
	this.instance_12.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(208));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(363,44,1480.5,92);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;