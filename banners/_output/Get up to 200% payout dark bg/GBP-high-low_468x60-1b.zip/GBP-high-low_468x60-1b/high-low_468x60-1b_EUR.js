(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 468,
	height: 60,
	fps: 18,
	color: "#FFFFFF",
	manifest: [
		{src:"images/_468x60_mask.png", id:"_468x60_mask"},
		{src:"images/bg1111.jpg", id:"bg1111"},
		{src:"images/web.jpg", id:"web"}
	]
};



// symbols:



(lib._468x60_mask = function() {
	this.initialize(img._468x60_mask);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib.bg1111 = function() {
	this.initialize(img.bg1111);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib.web = function() {
	this.initialize(img.web);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,468,162);


(lib.webimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.web();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,468,162);


(lib.t6 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ALBAoQgJgKAAgPIAAgCQAAgNAJgKQAIgKAPAAQANAAAIAIQAHAHAAAKIgRAAQAAgFgDgCQgDgDgFAAQgHAAgDAFQgDAEAAAJIAAACQAAAJADAGQADAFAHAAQAFAAADgDQADgCAAgFIARAAIAAAAQAAALgIAHQgIAHgMAAQgPAAgIgKgAJ4AsQgGgGAAgJQAAgKAIgGQAIgFAPAAIAKAAIAAgGQAAgDgDgCQgCgDgFAAQgFAAgCACQgDACAAACIgSAAIAAAAQAAgHAIgGQAIgHANAAQAMAAAIAHQAIAGAAAJIAAAdIAAAJIADAIIgTAAIgCgFIgBgFQgCAFgFADQgFAEgGAAQgLAAgGgGgAKIAVQgDADAAAEQAAAEACACQACACAEAAQAFAAAEgDQAEgCABgDIAAgKIgKAAQgGAAgDADgAJGAvQgFgCgDgFIgBAIIgQAAIAAhhIASAAIAAAmQADgEAFgCQAEgDAFAAQANAAAHAKQAHAKAAAOIAAACQAAAPgHAJQgHAKgNAAQgGAAgEgDgAJEgEQgDACgCACIAAAdQACADADACQADABAEAAQAIAAACgFQADgFAAgJIAAgCQAAgKgDgEQgDgFgHAAQgEAAgDABgAFzArQgIgHAAgJIAAgBIARAAQABAGADACQADADAGAAQAFAAADgCQACgCAAgEQAAgDgCgCQgDgCgIgCQgNgCgGgFQgGgFAAgIQAAgHAIgGQAHgHAMAAQAOAAAHAGQAIAHAAAHIgSAAQAAgCgDgCQgCgDgGAAQgEAAgDACQgCACAAADQAAACADACQACACAIACQANACAGAFQAGAFAAAJQAAAJgHAGQgIAGgNAAQgOAAgIgHgAErAsQgGgGAAgJQAAgKAIgGQAIgFAPAAIAKAAIAAgGQAAgDgDgCQgCgDgFAAQgFAAgCACQgDACAAACIgSAAIAAAAQAAgHAIgGQAIgHANAAQAMAAAIAHQAIAGAAAJIAAAdIAAAJIADAIIgTAAIgCgFIgBgFQgCAFgFADQgFAEgGAAQgLAAgGgGgAE7AVQgDADAAAEQAAAEACACQACACAEAAQAFAAAEgDQAEgCABgDIAAgKIgKAAQgGAAgDADgADrAoQgIgKAAgPIAAgCQAAgNAIgKQAIgKAQAAQAMAAAIAIQAIAHAAAKIgRAAQAAgFgDgCQgDgDgFAAQgIAAgDAFQgDAEAAAJIAAACQAAAJADAGQADAFAIAAQAFAAADgDQADgCAAgFIAQAAIABAAQAAALgIAHQgIAHgMAAQgQAAgIgKgACDAoQgJgJAAgTIAAgSQAAgSAJgKQAIgKAPAAQAOAAAIAKQAJAKAAASIAAASQAAATgJAJQgIAKgOAAQgPAAgIgKgACQgYQgDAFAAALIAAAWQAAALADAFQADAFAHAAQAGAAADgFQADgFAAgLIAAgWQAAgLgDgFQgDgFgGAAQgHAAgDAFgAA5ArQgJgHABgNIASgBQAAAGADAEQAEADAFAAQAHAAADgEQADgFAAgHQAAgIgDgFQgEgFgGAAQgFAAgDACQgDACgBADIgRgBIAGgxIAzAAIAAAPIgkAAIgDAVIAHgDIAIgBQANgBAHAJQAHAGAAAPQAAANgIAJQgIAJgPAAQgMAAgKgHgAh9AsQgGgGAAgJQAAgKAIgGQAHgFAPAAIALAAIAAgGQAAgDgDgCQgDgDgFAAQgEAAgDACQgCACAAACIgSAAIAAAAQgBgHAIgGQAIgHANAAQANAAAHAHQAIAGAAAJIAAAdIABAJIACAIIgSAAIgCgFIgBgFQgDAFgFADQgEAEgHAAQgLAAgFgGgAhuAVQgDADAAAEQAAAEACACQADACAEAAQAFAAADgDQAEgCACgDIAAgKIgLAAQgGAAgDADgAjdAoQgJgJAAgPIAAgDQAAgNAIgKQAIgKAPAAQAOAAAHAJQAIAIAAAMIAAAKIgpAAIAAABQAAAHAEAEQAEAEAHAAIAKgBIAJgEIAFAMQgEADgHACQgGADgJAAQgPAAgIgKgAjQgBQgCABgBAHIAAAAIAXAAIAAgBQAAgGgDgCQgDgDgFAAQgGAAgDAEgAmGAoQgJgJAAgPIAAgDQAAgNAIgKQAIgKAPAAQAOAAAHAJQAIAIAAAMIAAAKIgpAAIAAABQAAAHAEAEQAEAEAHAAIAKgBIAJgEIAFAMQgEADgHACQgGADgJAAQgPAAgIgKgAl5gBQgCABgBAHIAAAAIAXAAIAAgBQAAgGgDgCQgDgDgFAAQgGAAgDAEgAnLAoQgIgKAAgPIAAgCQAAgNAIgKQAIgKAQAAQAMAAAIAIQAIAHAAAKIgRAAQAAgFgDgCQgDgDgFAAQgIAAgDAFQgDAEAAAJIAAACQAAAJADAGQADAFAIAAQAFAAADgDQADgCAAgFIAQAAIABAAQAAALgIAHQgIAHgMAAQgQAAgIgKgAoOAoQgJgJAAgPIAAgDQAAgNAJgKQAIgKAOAAQAOAAAIAJQAHAIAAAMIAAAKIgpAAIAAABQABAHAEAEQAEAEAHAAIAKgBIAJgEIAFAMQgEADgHACQgHADgIAAQgPAAgJgKgAoAgBQgDABgBAHIAAAAIAXAAIAAgBQAAgGgDgCQgCgDgGAAQgFAAgDAEgAqnAoQgHgJAAgPIAAgCQAAgOAHgKQAHgKANAAQAFAAAEADQAEACADAEIAAgmIATAAIAABhIgQAAIgCgIQgDAFgEACQgFADgFAAQgNAAgHgKgAqYAAQgEAFAAAJIAAACQAAAJAEAFQADAFAGAAQAEAAADgBQADgCACgDIAAgdQgCgCgDgCQgDgBgDAAQgHAAgDAFgAs3AsQgGgGAAgJQAAgKAIgGQAHgFAPAAIALAAIAAgGQAAgDgDgCQgDgDgFAAQgEAAgDACQgCACAAACIgSAAIAAAAQgBgHAIgGQAIgHANAAQANAAAHAHQAIAGAAAJIAAAdIABAJIACAIIgSAAIgCgFIgBgFQgDAFgFADQgEAEgHAAQgLAAgFgGgAsoAVQgDADAAAEQAAAEACACQADACAEAAQAFAAADgDQAEgCACgDIAAgKIgLAAQgGAAgDADgAMpAwIgTgdIgFAAIAAAdIgTAAIAAhhIATAAIAAA2IAEAAIAQgXIAWAAIgWAdIAZAlgAHaAwIAAgpQAAgHgDgCQgCgDgGAAIgHABIgFAEIAAAwIgSAAIAAhhIASAAIAAAnQAEgEAEgDQAFgDAGAAQALAAAGAHQAGAIAAAMIAAApgAgXAwIAAgOIAAAAQADgBACgFQABgFAAgGIAAgGIgKAAIAAgMIAJAAIAAgOQAAgNAIgIQAHgIALAAQAOAAAHAIQAIAHgBALIAAABIgSAAQAAgGgDgDQgDgDgEAAQgEAAgDAEQgBADAAAHIAAAOIAWAAIAAAMIgWAAIAAAFQAAAFAAAFQgCAEgDAEIArAAIAAAOgAkVAwIgXhCIATAAIAMApIABAGIAAAAIANgvIATAAIgXBCgAlIAwIAAhCIATAAIAABCgApCAwIAAhCIARAAIABAKQACgGAEgDQAEgDAFAAIAFABIgCARIgHgBQgEAAgDACQgCABgCACIAAAugArLAwIAAgrQAAgFgDgCQgDgDgFAAQgEAAgDABIgFAEIAAAwIgSAAIAAhCIARAAIABAJQADgFAFgDQAFgDAGAAQALAAAGAHQAFAGAAAMIAAArgAH6AQIAAgOIAkAAIAAAOgAlIgjIAAgOIATAAIAAAOg");
	this.shape.setTransform(-3.4,-8.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-88.8,-19,170.6,21.1);


(lib.t5 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ACVAhQgLgKAAgSIAAgtIATAAIAAAsQAAAKAFAHQAEAFAIAAQAIAAAFgFQAFgHAAgKIAAgsIASAAIAAAtQAAASgKAKQgKAKgQAAQgPAAgKgKgAiOAfQgMgNAAgSQAAgRANgNQAMgMASAAQASAAAOAMIgKAOQgGgFgEgBQgFgCgGAAQgKgBgIAIQgHAHAAAKQAAAMAHAHQAHAHAKAAQAKAAAGgEIAAgWIATAAIAAAdQgNAOgWAAQgSAAgNgMgAk/AcIALgOQANAMAMAAQAFAAADgCQADgCAAgEQAAgDgDgDQgDgCgKgDQgOgDgHgEQgHgFAAgMQAAgMAJgHQAIgGANAAQAJAAAIADQAIADAHAFIgKAOQgLgJgLAAQgFAAgDADQgDACAAADQAAAFAEABQADACAMAEQAMACAHAFQAGAGAAAKQAAAMgIAHQgJAHgOAAQgTAAgQgPgAD+AqIAAhSIAdAAQAUAAAIAIQAJAHAAAPQAAAOgJAIQgJAGgTABIgLAAIAAAXgAEQADIANAAQAJAAAEgDQADgDAAgIQAAgGgEgEQgFgDgJAAIgLAAgAAVAqIgmgzIAAAzIgSAAIAAhSIARAAIAnA0IAAg0IATAAIAABSgAjVAqIAAhSIATAAIAABSg");
	this.shape.setTransform(-54.9,-3.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-89.4,-13,66.6,18.6);


(lib.t3c = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("AgNANQgFgFgBgIQABgHAFgGQAGgGAHAAQAHAAAHAGQAFAGAAAHQAAAIgFAFQgHAHgHAAQgHAAgGgHg");
	this.shape.setTransform(2,14);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiEBDIgLgEIADgLIAJAEIAKABQAKAAAFgFQAEgEAAgJIAAgIQgEAEgFACQgFADgGAAQgOAAgIgKQgHgKAAgPIAAgCQAAgQAHgLQAIgLAOAAQAHAAAFADQAGADADAFIACgKIALAAIAABJQAAAOgJAIQgIAIgQAAIgLgCgAiFgQQgFAIAAALIAAACQAAAKAFAHQAEAHAKAAQAGAAAEgDQAEgCADgGIAAggQgDgFgEgCQgEgDgGAAQgJAAgFAIgAKhAhQgIgHAAgKIAAAAIANAAQABAGAFAEQAFADAGAAQAHAAAEgDQAFgDAAgEQAAgFgEgDQgDgDgKgBQgNgEgHgDQgHgEAAgJQAAgJAIgGQAIgHAMAAQANAAAHAHQAIAGAAAKIAAABIgNAAQAAgGgEgDQgEgEgHAAQgHAAgEADQgDADAAAEQAAAFADACQADADAJACQAOACAHAEQAHAFAAAJQAAAKgIAGQgIAGgNAAQgOAAgIgHgAJyAjQgFgFAAgLIAAgrIgLAAIAAgKIALAAIAAgSIAOAAIAAASIAOAAIAAAKIgOAAIAAArQAAAGACABQACADAEAAIACgBIADAAIABAJIgEACIgGABQgIAAgFgFgAIjAdQgJgJAAgRIAAgDQAAgOAJgLQAKgKANAAQAPAAAHAJQAIAJAAAQIAAAGIgwAAIAAAAQAAAKAFAIQAFAGAKAAQAHAAAFgCQAFgCAEgDIAFAJQgEADgHADQgGADgJAAQgQAAgJgLgAIugSQgFAFgBAIIAAABIAiAAIAAgCQAAgHgEgGQgEgFgIAAQgHAAgFAGgAFWAiQgHgGAAgLQAAgKAJgGQAJgEAOAAIAPAAIAAgHQAAgGgEgEQgEgEgHAAQgHAAgEADQgEADAAAFIgNAAIAAgBQAAgHAIgHQAIgHANAAQAMAAAIAHQAHAGAAAMIAAAiIABAIIABAGIgOAAIgBgFIAAgGQgEAGgGADQgGAEgHAAQgLAAgGgGgAFiAIQgFAEAAAGQAAAFADADQADACAGAAQAHABAGgEQAGgEACgFIAAgLIgPAAQgIAAgFADgAAyAdQgJgKAAgRIAAgBQAAgOAJgLQAJgLAPAAQAPAAAJALQAJALAAAOIAAABQAAARgJAKQgJALgPAAQgPAAgJgLgAA7gRQgFAIAAAKIAAABQAAAMAFAIQAFAHAKAAQAKAAAFgHQAFgIAAgMIAAgBQAAgKgFgIQgFgHgKAAQgKAAgFAHgAg9AdQgJgJAAgRIAAgDQAAgOAJgLQAKgKANAAQAPAAAHAJQAIAJAAAQIAAAGIgwAAIAAAAQAAAKAFAIQAFAGAKAAQAHAAAFgCQAFgCAEgDIAFAJQgEADgHADQgGADgJAAQgQAAgJgLgAgygSQgFAFgBAIIAAABIAiAAIAAgCQAAgHgEgGQgEgFgIAAQgHAAgFAGgAkxAiQgHgGAAgLQAAgKAJgGQAJgEAOAAIAPAAIAAgHQAAgGgEgEQgEgEgHAAQgHAAgEADQgEADAAAFIgNAAIAAgBQAAgHAIgHQAIgHANAAQAMAAAIAHQAHAGAAAMIAAAiIABAIIABAGIgOAAIgBgFIAAgGQgEAGgGADQgGAEgHAAQgLAAgGgGgAklAIQgFAEAAAGQAAAFADADQADACAGAAQAHABAGgEQAGgEACgFIAAgLIgPAAQgIAAgFADgAnSAdQgJgJAAgRIAAgDQAAgOAJgLQAKgKANAAQAPAAAHAJQAIAJAAAQIAAAGIgwAAIAAAAQAAAKAFAIQAFAGAKAAQAHAAAFgCQAFgCAEgDIAFAJQgEADgHADQgGADgJAAQgQAAgJgLgAnHgSQgFAFgBAIIAAABIAiAAIAAgCQAAgHgEgGQgEgFgIAAQgHAAgFAGgAolAeQgIgKAAgPIAAgCQAAgQAIgLQAIgLANAAQAHAAAFACQAFADAEAEIAAgoIANAAIAABoIgLAAIgCgJQgDAGgFACQgGADgHAAQgNAAgIgKgAoagQQgFAIAAALIAAACQAAAKAEAIQAFAGAKAAQAGAAAEgDQAEgCADgGIAAggQgDgEgEgDQgEgDgGAAQgKAAgEAIgAIBAmIgYghIgIAAIAAAhIgOAAIAAhoIAOAAIAAA9IAIAAIAUgdIARAAIgaAiIAdAmgAGhAmIAAhIIAMAAIABALQAEgFAEgEQAFgDAGAAIADAAIACABIgCANIgHgBQgFAAgEADQgEACgCAFIAAAygAEsAmIAChNIgBAAIggBNIgJAAIgghNIAAAAIABBNIgNAAIAAhhIARAAIAgBPIAghPIARAAIAABhgACDAmIAAg+IgLAAIAAgKIALAAIAAgJQAAgMAGgGQAHgHALAAIAEABIAFABIgBAKIgDAAIgEAAQgGgBgDAEQgCADAAAHIAAAJIAPAAIAAAKIgPAAIAAA+gAi3AmIAAgsQAAgJgEgFQgEgEgIAAQgGAAgEADQgFACgDAFIAAA0IgNAAIAAhIIAMAAIABALQAEgFAFgEQAGgDAHAAQAMAAAGAHQAHAHAAAPIAAAsgAlnAmIAAhIIAMAAIABALQAEgFAEgEQAFgDAGAAIADAAIACABIgCANIgHgBQgFAAgEADQgEACgCAFIAAAygApOAmIAAhIIAOAAIAABIgAqDAmIgWhLIgWBLIgMAAIgYhhIAOAAIAPA/IACAMIAAAAIADgMIASg/IAMAAIAVBMIABAAIAQhMIAOAAIgYBhgApOg1IAAgNIAOAAIAAANg");
	this.shape_1.setTransform(83.8,16.8);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,4,156.2,22.5);


(lib.t3b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("AgNANQgFgFgBgIQABgHAFgGQAGgGAHAAQAHAAAHAGQAFAGAAAHQAAAIgFAFQgHAHgHAAQgHAAgGgHg");
	this.shape.setTransform(2,14);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AjVBCIgLgEIADgKIAJADIAKABQALAAAEgEQAFgFgBgJIAAgIQgDAEgGADQgFACgGAAQgOAAgHgKQgIgKAAgPIAAgCQAAgQAIgLQAHgLAOAAQAHAAAFADQAGADADAFIACgJIALAAIAABIQAAAOgIAIQgJAIgQAAIgLgCgAjWgRQgFAIAAALIAAACQAAALAFAGQAFAHAJAAQAGAAAFgCQAEgDACgFIAAggQgCgFgEgDQgFgDgGAAQgJAAgFAIgAnQBDIgDAAIABgLIACAAIAEAAQAEAAADgEIAFgIIADgIIgchGIAQAAIASA2IASg2IAPAAIgfBTQgDAIgFAFQgGAGgIAAIgFgBgAJUAdQgJgKAAgRIAAgCQAAgPAJgKQAKgLANAAQAPAAAHAJQAIAJAAAQIAAAGIgwAAIAAAAQAAALAFAHQAGAHAJAAQAHAAAFgCQAFgCAEgEIAFAJQgEAEgGADQgHACgJAAQgPAAgKgKgAJfgTQgEAFgBAJIAAAAIAhAAIAAgBQAAgIgDgGQgEgFgJAAQgHAAgFAGgAG5AdQgKgLABgQIAAgCQgBgOAKgLQAIgLAPAAQAQAAAJALQAJALAAAOIAAACQAAAQgJALQgJAKgPAAQgQAAgIgKgAHCgRQgFAHAAAKIAAACQAAALAFAIQAFAIAKAAQAKAAAEgIQAFgIABgLIAAgCQgBgKgFgHQgEgIgLAAQgJAAgFAIgAC0AdQgJgJABgQIAAgCQgBgQAJgLQAHgLANAAQAHAAAFADQAFACAEAFIAAgpIANAAIAABpIgLAAIgCgJQgDAFgFADQgFACgIAAQgNAAgHgKgAC+gRQgFAIAAALIAAACQAAALAFAHQAEAGAKAAQAGAAAEgCQAEgDADgFIAAghQgDgEgEgDQgEgDgGAAQgJAAgFAIgABpAdQgJgKAAgRIAAgCQAAgPAJgKQAKgLANAAQAOAAAIAJQAIAJgBAQIAAAGIgwAAIAAAAQABALAFAHQAFAHAJAAQAIAAAFgCQAEgCAFgEIAEAJQgDAEgHADQgGACgKAAQgPAAgJgKgAB0gTQgFAFgBAJIAAAAIAiAAIAAgBQAAgIgEgGQgEgFgIAAQgHAAgFAGgAA5AiQgEgFAAgKIAAgrIgMAAIAAgKIAMAAIAAgSIANAAIAAASIAOAAIAAAKIgOAAIAAArQAAAFACACQACACAEAAIACAAIADgBIACAJIgFACIgFABQgIAAgGgFgAgZAhQgGgGgBgKQAAgLAJgGQAJgEAOAAIANAAIAAgHQAAgGgDgEQgEgEgGAAQgGAAgFADQgDAEAAAEIgNAAIAAAAQgBgIAIgHQAIgHAMAAQAMAAAHAHQAIAGAAAMIAAAiIAAAIIACAHIgPAAIgBgGIAAgFQgDAFgHAEQgEADgGAAQgMAAgGgGgAgNAIQgFAEAAAFQAAAFAEADQADADAGAAQAFAAAFgEQAHgEABgEIAAgMIgNAAQgIAAgFAEgAiNAfQgHgHAAgRIAAgpIAOAAIAAAqQgBALAEAFQADAEAIAAQAHAAAFgDQAFgDACgFIAAgzIANAAIAABIIgMAAIgBgLQgDAGgGADQgFADgIAAQgLAAgHgIgAkrAdQgJgKAAgRIAAgCQAAgPAJgKQAKgLANAAQAOAAAIAJQAHAJAAAQIAAAGIgvAAIAAAAQAAALAFAHQAFAHAJAAQAIAAAEgCQAGgCADgEIAFAJQgDAEgHADQgGACgKAAQgPAAgJgKgAkggTQgFAFgBAJIAAAAIAiAAIAAgBQAAgIgEgGQgEgFgIAAQgIAAgEAGgApnAfQgGgHAAgRIAAgpIANAAIAAAqQAAALADAFQAEAEAIAAQAGAAAFgDQAFgDADgFIAAgzIAMAAIAABIIgLAAIgBgLQgDAGgGADQgGADgHAAQgMAAgHgIgAKbAmIAAhIIALAAIABALQAEgGAEgDQAFgEAGAAIADABIACAAIgBANIgIgBQgFAAgEADQgEACgCAFIAAAzgAIyAmIgXgiIgJAAIAAAiIgOAAIAAhpIAOAAIAAA+IAJAAIAUgdIAQAAIgZAhIAcAngAGBAmIAAhIIAMAAIABALQAEgGAEgDQAFgEAFAAIADABIADAAIgCANIgHgBQgGAAgDADQgEACgCAFIAAAzgAEoAmIAAhiIAgAAQAQAAAJAHQAJAHgBANQAAAHgDAFQgFAFgHADQAJACAGAHQAEAEAAAKQAAANgJAIQgIAHgPAAgAE1AbIAYAAQAIAAAGgEQAFgFAAgIQAAgJgEgDQgEgFgKAAIgZAAgAE1gRIAWAAQAIAAAFgFQAEgEAAgHQAAgIgFgEQgFgEgKAAIgTAAgAhBAmIAAhpIAOAAIAABpgAljAmIAAhIIAMAAIABALQADgGAFgDQAEgEAHAAIACABIACAAIgBANIgHgBQgGAAgDADQgEACgCAFIAAAzgAn1AmIAAhpIANAAIAABpgAoaAmIAAhpIANAAIAABpgAq+AmIAAhiIBCAAIAAALIg1AAIAAAiIAtAAIAAALIgtAAIAAAqg");
	this.shape_1.setTransform(82.6,16.8);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,4,153,22.5);


(lib.t3a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE683A").s().p("AgNANQgFgFgBgIQABgHAFgGQAGgGAHAAQAHAAAHAGQAFAGAAAHQAAAIgFAFQgHAHgHAAQgHAAgGgHg");
	this.shape.setTransform(2,14);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhlBEIAAhlIAKAAIACAKQAEgFAFgDQAFgDAIAAQANAAAIALQAIALAAAQIAAABQAAAQgIAKQgIAKgNAAQgHAAgFgDQgFgCgEgEIAAAkgAhRgVQgEADgDAFIAAAhQADAFAEADQAEACAGAAQAJAAAFgHQAFgHAAgLIAAgBQAAgLgFgIQgFgIgJAAQgGAAgEACgADJAeQgJgKAAgRIAAgBQAAgPAJgKQAJgLAPAAQAQAAAJALQAJAKAAAPIAAABQAAARgJAKQgJALgPAAQgQAAgJgLgADTgQQgFAIAAAKIAAABQAAAMAFAHQAFAIAKAAQAJAAAFgIQAFgHAAgMIAAgBQAAgKgFgIQgFgHgKAAQgJAAgFAHgABoAkQgFgFAAgLIAAgrIgMAAIAAgKIAMAAIAAgSIANAAIAAASIAOAAIAAAKIgOAAIAAArQAAAFACACQADADADAAIADgBIACAAIACAJIgEACIgGABQgIAAgFgFgAATAjQgGgGAAgLQAAgKAJgGQAIgEAPAAIAOAAIAAgHQAAgHgDgEQgEgDgIAAQgGAAgEADQgEADAAAFIgNAAIAAgBQgBgIAIgGQAIgHANAAQANAAAHAGQAIAHAAAMIAAAhIAAAIIACAHIgOAAIgBgGIgBgFQgDAGgGADQgGAEgHAAQgMAAgGgGgAAfAJQgFAEAAAGQAAAFAEACQADADAGAAQAHAAAGgDQAGgEABgFIAAgMIgPAAQgIAAgFAEgAi0AkQgFgFAAgLIAAgrIgLAAIAAgKIALAAIAAgSIAOAAIAAASIAOAAIAAAKIgOAAIAAArQAAAFACACQACADAEAAIACgBIADAAIABAJIgEACIgGABQgIAAgFgFgAkDAiQgIgIABgJIAAgBIANAAQAAAHAFAEQAFADAHAAQAHAAAEgDQAEgDAAgEQAAgFgDgDQgEgDgJgCQgOgDgGgEQgHgEAAgIQAAgJAHgHQAIgGAMAAQANAAAIAHQAIAGgBAKIAAAAIgNAAQAAgFgEgEQgEgDgHAAQgHAAgDADQgEADAAAEQAAAFADACQADADAKACQAOABAHAFQAGAFAAAJQAAAKgHAGQgIAGgNAAQgOAAgJgHgAlOAeQgJgKAAgQIAAgDQAAgOAJgLQAKgKANAAQAPAAAHAJQAIAJAAAPIAAAGIgwAAIAAABQAAAKAFAHQAFAHAKAAQAHAAAFgCQAFgCAEgDIAFAJQgEADgHADQgGADgJAAQgQAAgJgLgAlDgSQgFAGgBAIIAAABIAiAAIAAgCQAAgIgEgFQgEgFgIAAQgHAAgFAFgAGgAnIAAgqQAAgLgDgFQgEgEgIAAQgHAAgEAFQgEAEgBAIIAAAtIgNAAIAAgqQAAgLgEgEQgEgFgHAAQgGAAgEACQgEADgDAEIAAA1IgNAAIAAhIIAMAAIABAKQAEgFAFgDQAGgDAHAAQAIAAAFADQAFAEADAHQADgHAGgDQAGgEAHAAQAMAAAGAIQAHAHAAAQIAAAqgAEVAnIAAhIIAMAAIABALQAEgGAEgDQAFgDAGAAIADAAIACABIgCAMIgHAAQgFAAgEACQgEADgCAEIAAAzgACXAnIAAg+IgMAAIAAgKIAMAAIAAgJQAAgMAGgGQAGgHALAAIAFABIAFABIgCAKIgDgBIgDAAQgGAAgDAEQgDADAAAHIAAAJIAPAAIAAAKIgPAAIAAA+gAgTAnIAAhoIAOAAIAABogAmtAnIAAhhIAhAAQAPAAAJAGQAJAHAAAOQAAAGgEAGQgFAFgHACQAJACAGAHQAFAFAAAJQAAAOgJAHQgJAHgPAAgAmfAdIAXAAQAJAAAFgFQAFgEAAgJQAAgIgEgDQgEgFgJAAIgZAAgAmfgQIAVAAQAIAAAFgEQAEgEAAgIQAAgIgFgEQgFgEgJAAIgTAAg");
	this.shape_1.setTransform(56.3,16.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,4,99.7,22.5);


(lib.t22 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AHPEiQgZgLgTgTQgTgTgKgYQgLgbAAgcIAAnIIBVAAIAAHAQAAAeAPAQQANAPAYAAQAXAAAOgPQAPgQAAgeIAAnAIBVAAIAAHIQAAAcgLAbQgKAYgTATQgTATgZALQgZAKgcAAQgcAAgZgKgABvEjQgagKgTgRQgVgUgMgZQgMgdAAgiIAAk3QAAgiAMgdQAMgaAVgTQATgSAagJQAZgJAaAAQAbAAAZAJQAZAJAUASQAVATAMAaQAMAdAAAiIAAE3QAAAigMAdQgMAZgVAUQgUARgZAKQgZAJgbAAQgaAAgZgJgAB6jIQgRARAAAcIAAE3QAAAdARAQQAQAOAYAAQAZAAAQgOQARgQAAgdIAAk3QAAgcgRgRQgQgOgZAAQgYAAgQAOgAMUEnIAAn9IhiAAIAAhQIEZAAIAABQIhiAAIAAH9gAjYEnIAAj5Ih0lUIBaAAIBEDrIABAAIBFjrIBZAAIh0FUIAAD5gAmkEnIgZh/Ih0AAIgYB/IhVAAICEpNIBHAAICDJNgAnNBZIgpjUIgCAAIgqDUIBVAAgAvKEnIAApNICAAAQAjAAAaAKQAbAJAVAWQAWAXAIAgQAIAeAAA2QAAAqgEAYQgFAdgPAWQgSAegdAPQgeARgtAAIgsAAIAADmgAt1gOIApAAQAZABAPgIQAOgGAGgOQAKgSAAg2QAAg1gJgTQgGgOgOgHQgOgIgYAAIgsAAg");
	this.shape.setTransform(99.6,34.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.5,2.8,202.2,102.5);


(lib.t2roll = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgBeBxwIBej4IAAgBIgMAEQgJACgOAAQgXAAgSgLQgTgKgLgRQgHgLgEgOQgFgOgBgaQgBgaAAguQAAgmABgWQABgWAFgNQAEgNAIgNQAQgbAcgPQAbgPAiAAQAiABAbAPQAcAOARAbQAIANAEANQAEANACAWQACAWAAAmQAAAkgCAVQgCAUgDAPQgDAOgGAPIhuEpgEgAbBp9QgMALgBATIAABuQABATAMAMQAMALAPAAQAQAAAMgLQANgMAAgTIAAhuQAAgTgNgLQgMgMgQAAQgPAAgMAMgEgA9BmGQgagOgOgXQgJgMgFgOQgFgNgCgVQgCgVAAglQgBgrADgbQACgaAJgRQAJgRAUgPQgUgPgJgQQgJgQgCgWQgDgWABgjQAAgfACgVQAEgTAHgOQAGgPALgNQARgWAZgMQAZgMAbAAQAcAAAZAMQAZAMARAWQALANAHAPQAHAOADATQADAVAAAfQAAAjgCAWQgCAWgKAQQgJAQgTAPQATAPAJARQAKARACAaQACAbAAArQAAAkgCAWQgDAVgFANQgFAOgIAMQgPAXgaAOQgZAPglABQgjgBgagPgEgAbBiGQgMAMgBARIAAB1QABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAh1QAAgRgNgMQgMgMgQAAQgPAAgMAMgEgAbBeeQgMAMgBARIAABXQABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAhXQAAgRgNgMQgMgMgQAAQgPAAgMAMgEgBpBayICSn/IhbAAIAABEIhKAAIAAiUID6AAIAABVIiOH6gEgA8BPIQgcgPgRgbQgIgMgEgNQgEgNgCgWQgBgWAAgmQAAgkABgVQACgUADgOQAEgPAFgPIBtkpIBfAAIhfD4IAAACQAFgDAIgCQAJgCAOAAQAXAAASALQAUAKAKARQAIAKAEAOQAEAPABAaQACAaAAAuQAAAmgCAWQgBAWgFANQgEANgHAMQgRAdgcAOQgbAPgjAAQghgBgbgPgEgAbBLMQgMAMgBATIAABuQABAUAMALQAMALAPAAQAQAAAMgLQANgLAAgUIAAhuQAAgTgNgMQgMgLgQAAQgPAAgMALgEgA9BDpQgdgPgRgcQgRgdgBgnIAAgZIBVAAIAAAWQAAAWAMALQAMAMARAAQATAAAKgMQALgLAAgVIAAiLQAAgSgLgLQgLgNgSAAQgMAAgJAGQgJAGgEAIIgHAMIhLAAIAAk+IDxAAIAABQIimAAIAACfQAMgMASgHQAQgIAWgBQAsAAAbAbQAaAbABAzIAACZQgBAngRAdQgSAcgcAPQgcAQgiAAQghAAgcgQgEAAVA4VIAAhYIimAAIAAhQIB6mnIBYAAIh+GnIBSAAIAAioIBVAAIAACoIAoAAIAABQIgoAAIAABYgEgA3AsuQgdgMgUgcQgUgbAAguIAAgxIBUAAIAAAsQAAAVALAMQALANASAAQATAAALgNQALgMAAgXIAAhUQABghgOgMQgOgMgmACIAAhLQAjABAPgLQAPgKAAgfIAAhNQAAgSgLgLQgLgMgTAAQgVABgJANQgKAOAAANIAAAwIhUAAIAAgwQAAgkARgcQARgcAdgRQAdgQAhgBQAjABAXANQAXANALAPQAMANAHAOQAHAPADAXQAEAXAAAlQAAAogDAWQgDAWgMAMQgLANgYAOQAaAQALAPQALAPADAYQACAZAAApQAAAmgCAWQgCAWgFANQgFAOgJAMQgPAXgaAPQgZAPglABIgBAAQgbAAgbgNgEgB8AhXIAAhQICWkfQALgWACgQQACgSAAgXQAAgPgCgPQgBgPgJgKQgJgJgUgBQgRAAgLALQgLAKgBAVIAAAxIhUAAIAAgvQAAgkARgcQARgeAcgRQAdgRAhgBQAsAAAcAWQAcAUANAhQANAiAAAoQAAAbgCATQgCASgGARQgFARgOAZIh6DvICXAAIAABVgAgYV4IAAn2IhVA/IAAhaIBVg+IBSAAIAAJPgAg9KOQgcgPgSgdQgRgcAAgnIAAlbQAAgnARgcQASgdAcgPQAdgQAgAAQAiAAAcAQQAcAPASAdQARAcABAnIAAFbQgBAngRAcQgSAdgcAPQgcAQgiAAQggAAgdgQgAgcCmQgLAMgBASIAAFbQABATALALQALAMARAAQASAAALgMQAMgLAAgTIAAlbQAAgSgMgMQgLgMgSAAQgRAAgLAMgAhehEIBej4IAAgBIgMAEQgJADgOAAQgXgBgSgLQgTgKgLgRQgHgKgEgOQgFgPgBgaQgBgaAAguQAAgmABgWQABgWAFgMQAEgNAIgNQAQgcAcgPQAbgPAiAAQAiABAbAOQAcAPARAcQAIANAEANQAEAMACAWQACAWAAAmQAAAkgCAVQgCAUgDAPQgDAOgGAPIhuEpgAgbo4QgMAMgBATIAABuQABAUAMAKQAMAMAPAAQAQAAAMgMQANgKAAgUIAAhuQAAgTgNgMQgMgLgQAAQgPAAgMALgAg9stQgagPgOgWQgJgMgFgOQgFgOgCgVQgCgWAAgjQgBgtADgaQACgaAJgRQAJgRAUgPQgUgPgJgQQgJgQgCgWQgDgWABgjQAAggACgTQAEgVAHgNQAGgPALgNQARgWAZgMQAZgMAbAAQAcAAAZAMQAZAMARAWQALANAHAPQAHANADAVQADATAAAgQAAAjgCAWQgCAWgKAQQgJAQgTAPQATAPAJARQAKARACAaQACAaAAAtQAAAjgCAWQgDAVgFAOQgFAOgIAMQgPAWgaAPQgZAPglAAQgjAAgagPgAgbwuQgMALgBATIAAB0QABARAMAMQAMAMAPAAQAQAAAMgMQANgMAAgRIAAh0QAAgTgNgLQgMgMgQAAQgPAAgMAMgAgb0WQgMALgBATIAABVQABATAMALQAMALAPABQAQgBAMgLQANgLAAgTIAAhVQAAgTgNgLQgMgLgQgBQgPABgMALgAhp4CICSn/IhbAAIAABEIhKAAIAAiUID6AAIAABVIiOH6gEgA8gjsQgcgPgRgaQgIgNgEgNQgEgOgCgVQgBgWAAgmQAAgjABgWQACgVADgOQAEgOAFgPIBtkpIBfAAIhfD4IAAACQAFgDAIgDQAJgBAOAAQAXAAASAKQAUALAKAQQAIAMAEAOQAEAOABAaQACAaAAAuQAAAmgCAWQgBAVgFAOQgEANgHANQgRAcgcAOQgbAPgjAAQghAAgbgQgEgAbgnoQgMAMgBATIAABuQABATAMAMQAMALAPAAQAQAAAMgLQANgMAAgTIAAhuQAAgTgNgMQgMgKgQgBQgPABgMAKgEgA9gvKQgdgQgRgcQgRgcgBgoIAAgZIBVAAIAAAVQAAAXAMAMQAMALARAAQATAAAKgLQALgMAAgVIAAiKQAAgTgLgLQgLgMgSgBQgMAAgJAHQgJAGgEAGIgHAOIhLAAIAAk/IDxAAIAABQIimAAIAACfQAMgMASgHQAQgIAWAAQAsAAAbAbQAaAaABAzIAACZQgBAogRAcQgSAcgcAQQgcAPgiAAQghAAgcgPgEAAVg6fIAAhYIimAAIAAhQIB6mnIBYAAIh+GnIBSAAIAAioIBVAAIAACoIAoAAIAABQIgoAAIAABYgEgA3hGFQgdgNgUgcQgUgbAAguIAAgwIBUAAIAAAsQAAATALANQALANASAAQATAAALgNQALgMAAgXIAAhUQABghgOgMQgOgLgmABIAAhLQAjABAPgKQAPgLAAgfIAAhNQAAgSgLgMQgLgLgTAAQgVABgJANQgKANAAAOIAAAxIhUAAIAAgyQAAgjARgcQARgcAdgRQAdgQAhgBQAjABAXANQAXANALAPQAMAMAHAPQAHAPADAXQAEAXAAAlQAAAogDAWQgDAWgMANQgLANgYAOQAaAPALAPQALAQADAXQACAYAAAqQAAAmgCAWQgCAWgFANQgFAOgJAMQgPAXgaAPQgZAQglAAIgBAAQgbAAgbgMgEgB8hRdIAAhQICWkgQALgUACgRQACgRAAgYQAAgPgCgPQgBgPgJgKQgJgJgUgBQgRAAgLALQgLALgBAUIAAAwIhUAAIAAgvQAAgjARgcQARgeAcgRQAdgSAhAAQAsABAcAUQAcAVANAhQANAiAAAoQAAAcgCASQgCASgGARQgFARgOAZIh6DwICXAAIAABUgEgAYhc8IAAn1IhVA+IAAhZIBVg/IBSAAIAAJPgEgA9homQgcgPgSgcQgRgdAAgnIAAlbQAAgnARgcQASgdAcgQQAdgPAgAAQAiAAAcAPQAcAQASAdQARAcABAnIAAFbQgBAngRAdQgSAcgcAPQgcAQgiAAQggAAgdgQgEgAchwOQgLAMgBASIAAFbQABASALAMQALAMARAAQASAAALgMQAMgMAAgSIAAlbQAAgSgMgMQgLgMgSAAQgRAAgLAMg");
	this.shape.setTransform(98.5,748.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(55,0,621.2,1476.3);


(lib.t1d = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ADaA0IAAgpIgpAAIAAApIgYAAIAAhnIAYAAIAAAsIApAAIAAgsIAYAAIAABngAA1A0IAAhTIgeAAIAAgUIBTAAIAAAUIgdAAIAABTgAgsA0IAAhnIAXAAIAABngAiNA0IgXhHIgXBHIgRAAIglhnIAaAAIAUA7IATg7IAYAAIATA7IAVg7IAZAAIglBng");
	this.shape.setTransform(-2.2,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-26.4,0,48.8,22.3);


(lib.t1c = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFhAjIAOgRQARAPAOAAQAGAAAFgDQADgDAAgFQAAgEgEgDQgEgDgMgCQgRgFgJgFQgJgGAAgPQAAgPALgJQALgHAQgBQALAAAKAEQALAEAHAGIgMARQgOgKgOAAQgGAAgDACQgEADABAFQAAAFADACQAFADAOADQAQAEAIAGQAIAHAAAOQAAAOgKAJQgLAJgRgBQgZAAgUgSgABAAmQgQgQAAgWQAAgVAQgQQAQgPAXgBQAXABAQAPQAQAQAAAVQAAAWgQAQQgQAPgXAAQgXAAgQgPgABRgWQgJAKAAAMQAAANAJAKQAJAKANAAQANAAAJgKQAJgKAAgNQAAgMgJgKQgJgKgNAAQgNAAgJAKgAmjAmQgQgQAAgWQAAgVAQgQQAQgPAXgBQAXABAQAPQAQAQAAAVQAAAWgQAQQgQAPgXAAQgXAAgQgPgAmSgWQgJAKAAAMQAAANAJAKQAJAKANAAQANAAAJgKQAJgKAAgNQAAgMgJgKQgJgKgNAAQgNAAgJAKgAEaA0Igzg/IAAA/IgXAAIAAhmIAWAAIA0BBIAAhBIAWAAIAABmgAgWA0IAAhmIAWAAIAABmgAh6A0IAAhSIgfAAIAAgUIBTAAIAAAUIgdAAIAABSgAkTA0IAAhmIAlAAQAYAAALAJQALAKAAATQAAARgLAJQgMAKgXgBIgOAAIAAAdgAj8ADIAQAAQAMAAAEgDQAEgFAAgIQAAgJgFgFQgGgDgLAAIgOAAg");
	this.shape.setTransform(-1.5,11.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-45.1,0,87.3,22.3);


(lib.t1b = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEvA0IAAgqIgkg9IAZAAIAXAnIAWgnIAaAAIgkA9IAAAqgADNA0IgXgiIgQAAIAAAiIgXAAIAAhnIAnAAQAZAAAKAIQAKAIAAATQAAAXgTAIIAaAlgACmAAIARAAQAMAAAEgEQAFgEgBgIQABgJgFgCQgEgDgMgBIgRAAgABLA0IgKgXIgsAAIgKAXIgWAAIArhnIAXAAIAtBngAAeAJIAaAAIgMgcgAhNA0Igyg/IAAA/IgXAAIAAhnIAWAAIAzBCIAAhCIAYAAIAABngAjlA0IAAhnIAYAAIAABngAlqA0IAAhnIApAAQALAAAHACQAIADADAEQAIAJAAAKQgBAMgHAGIgEADIgEACQAKAAAGAHQAGAGAAAKQAAALgIAJQgJAJgVAAgAlSAgIAQAAQAJAAAFgDQAGgCAAgHQgBgIgFgCQgFgCgMAAIgNAAgAlSgIIAKAAQAKAAAFgCQAFgCgBgHQAAgIgDgCQgFgCgLAAIgKAAg");
	this.shape.setTransform(-0.7,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-37.1,0,72.7,22.3);


(lib.t1a = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC539").s().p("ADvA0IAAhnIBMAAIAAAVIg0AAIAAAWIAvAAIAAARIgvAAIAAAXIA1AAIAAAUgABeA0IAAhnIAlAAQAcAAAPAOQAPAOAAAXQAAAXgPAOQgPAPgdAAgAB1AgIAPAAQAQAAAJgJQAIgIAAgPQAAgOgIgIQgJgJgSAAIgNAAgAAaA0IgJgXIgqAAIgKAXIgZAAIAthnIAVAAIAtBngAgQAJIAYAAIgLgcgAh7A0IgXgiIgQAAIAAAiIgXAAIAAhnIAnAAQAZAAAKAIQALAIAAATQAAAXgUAIIAaAlgAiiAAIARAAQAMAAAEgEQAFgEAAgIQAAgJgFgCQgEgDgLgBIgSAAgAkdA0IAAhTIgeAAIAAgUIBTAAIAAAUIgeAAIAABTg");
	this.shape.setTransform(-1.7,11.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-33.3,0,63.7,22.3);


(lib.Symbol1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQEaQgRgRAAgdIAAg1QAAgfARgSQASgSAigBQAgABATASQATASAAAfIAAA1QAAAdgTARQgTASggAAQgiAAgSgSgAA1CrQgGAHAAAJIAAApQAAAKAGAFQAGAHAJAAQAIAAAGgHQAGgFAAgKIAAgpQAAgJgGgHQgGgFgIgBQgJABgGAFgAh/EnIDIpNIA3AAIjJJNgAh2iEQgTgQAAgdIAAg2QAAgfATgSQASgSAhgBQAhABATASQARASAAAfIAAA2QAAAdgRAQQgTARghABQghgBgSgRgAhRjyQgGAFgBAKIAAApQABAJAGAHQAGAGAIAAQAJAAAGgGQAGgHAAgJIAAgpQAAgKgGgFQgGgHgJAAQgIAAgGAHg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-13.8,-30,27.8,60.1);


(lib.logo_mc = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("AgmA1QgmAAgHgBQgNgCgGgHQgGgFgCgMQgCgHAAgTIABgSQAAgEABgGQAEgLAHgGQAJgGAVgBIAdAAQAmAAAIABQAPADAFAHQAGAIACAKIABAYQAAAYgEAJQgEAJgIAEIgNAFIgRABgAhAgaQgJABgDAGQgDAFAAAOQAAAOADAGQADAFAKACIAZABQAYAAAFgCQAIgBABgFQACgEAAgHIAAgJQAAgOgCgFQAAgEgCgBQgEgCgGAAIgaAAIgaAAgAj2A1IAAhoIAiAAIAABNIBaAAIAAAbgACgA0IgThAIgUBAIgtAAIgphoIAkAAIAaBIIAYhIIApAAIAXBIIAahIIAkAAIgpBog");
	this.shape.setTransform(59.7,9.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2E").s().p("AATA1QgfAAgHgBQgOgDgFgHQgHgGAAgMQgBgEAAgTQAAgSABgFQACgNAHgHQAHgHAXgCIAfgBQAlAAAJADQAPADAEAKQADAHAAAOIggAAQAAgFgCgDQgEgEgJAAIgxABQgGABgCAFQgDAEAAASQABAOACAEQABAHAJABQAFABAOAAIAeAAQALgCACgHIAAgHIgqAAIAAgSIBKAAIAAANQAAAWgDAHQgCAIgHAEQgHADgNABgADUA0IAAgoIhMAAIAAAoIggAAIAAhnIAgAAIAAAnIBMAAIAAgnIAhAAIAABngAhaA0IAAhnIAiAAIAABngAiHA0IAAgoIhLAAIAAAoIgiAAIAAhnIAiAAIAAAnIBLAAIAAgnIAiAAIAABng");
	this.shape_1.setTransform(0.6,4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6B6B6A").s().p("AkcBZIAAjkIEcAyIEdgyIAADkIkdAzg");
	this.shape_2.setTransform(59.4,9.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E1E0DF").s().p("AAABaIkcAyIAAjlIEcgyIEdAyIAADlg");
	this.shape_3.setTransform(0.6,4.1);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-28,-10,116,33.5);


(lib.gbcurve = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg48AEsQgljbgBhHQgChFAdjoIABgIMByqAAAIAAJXg");
	this.shape.setTransform(368.6,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.2,0,736.8,60);


(lib.bgimg = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg1111();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib._bg = function() {
	this.initialize();

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu2AAAMAAAAnDg");
	this.shape.setTransform(234,30,1.56,0.24);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,468,60);


(lib._clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(47).call(this.frame_47).wait(1));

	// t3c
	this.instance = new lib.t3c();
	this.instance.setTransform(411.7,28.8,1,1,0,0,0,98.7,13.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).to({x:391.7,alpha:1},7,cjs.Ease.get(0.9)).wait(30));

	// t3b
	this.instance_1 = new lib.t3b();
	this.instance_1.setTransform(238.2,28.8,1,1,0,0,0,96.2,13.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(6).to({_off:false},0).to({x:225.2,alpha:1},7,cjs.Ease.get(0.9)).wait(35));

	// t3a
	this.instance_2 = new lib.t3a();
	this.instance_2.setTransform(99.8,28.8,1,1,0,0,0,62.8,13.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({x:79.8,alpha:1},7,cjs.Ease.get(0.9)).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_49 = function() {
		this.stop();
		exportRoot.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(1));

	// t2.2
	this.instance = new lib.t22();
	this.instance.setTransform(236.5,22.1,1,1,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(33).to({_off:false},0).wait(1).to({regX:99.6,regY:34.4,x:298.2,y:45.4,alpha:0.344},0).wait(1).to({x:268.3,alpha:0.616},0).wait(1).to({x:246.3,alpha:0.816},0).wait(1).to({x:232.2,alpha:0.944},0).wait(1).to({regX:0,regY:11.1,x:126.5,y:22.1,alpha:1},0).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
		exportRoot.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQEbQgRgSAAgcIAAg2QAAggARgSQASgRAigBQAgABATARQATASAAAgIAAA2QAAAcgTASQgTAQggABQgigBgSgQgAA1CrQgGAGAAAKIAAAqQAAAIAGAGQAGAHAJAAQAIAAAGgHQAGgGAAgIIAAgqQAAgKgGgGQgGgFgIgBQgJABgGAFgAh/EnIDIpNIA3AAIjJJNgAh2iEQgTgRAAgcIAAg2QAAgfATgSQASgTAhAAQAhAAATATQARASAAAfIAAA2QAAAcgRARQgTASghAAQghAAgSgSgAhRjzQgGAHgBAJIAAApQABAKAGAFQAGAHAIAAQAJAAAGgHQAGgFAAgKIAAgpQAAgJgGgHQgGgFgJgBQgIABgGAFg");
	this.shape.setTransform(189.1,45.2);

	this.instance = new lib.Symbol1();
	this.instance.setTransform(220.1,45.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape,p:{x:189.1}}]},1).to({state:[{t:this.shape,p:{x:206.1}}]},16).to({state:[{t:this.instance}]},8).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance}]},5).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25).to({_off:false},0).wait(3).to({x:95.1},5,cjs.Ease.get(0.9)).wait(12));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9EdQgcgQgSgcQgRgcAAgoIAAlZQAAgnARgdQASgcAcgQQAdgPAgAAQAhAAAdAPQAcAQASAcQARAdABAnIAAFZQgBAogRAcQgSAcgcAQQgdAPghAAQggAAgdgPgAgcjKQgMAMAAASIAAFZQAAASAMAMQALAMARAAQARAAAMgMQAMgMgBgSIAAlZQABgSgMgMQgMgLgRgBQgRABgLALg");
	this.shape_1.setTransform(33.7,44.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9EcQgcgPgSgdQgRgcAAgnIAAlZQAAgnARgcQASgdAcgPQAcgQAhAAQAhAAAdAQQAcAPASAdQARAcABAnIAAFZQgBAngRAcQgSAdgcAPQgdAQghAAQghAAgcgQgAgcjKQgLAMgBASIAAFZQABATALALQALAMARAAQARAAAMgMQALgLAAgTIAAlZQAAgSgLgMQgMgLgRgBQgRABgLALg");
	this.shape_2.setTransform(66,44.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah9EpIAAhQICXkdQAKgVADgRQACgRAAgXQAAgQgCgPQgBgPgKgKQgIgJgUgBQgRAAgLAMQgMAKAAAUIAAAxIhVAAIAAgvQABgjARgdQARgeAcgQQAcgSAiAAQAsAAAbAVQAcAUAOAhQANAjgBAnQABAcgCATQgCARgGARQgGASgNAYIh6DuICWAAIAABUg");
	this.shape_3.setTransform(2.9,44.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},34).wait(11));

	// 1
	this.instance_1 = new lib.t2roll();
	this.instance_1.setTransform(163,707.8,1,1,0,0,0,71,640);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({y:634.8},2).wait(1).to({y:-100.4},0).wait(1).to({regX:98.5,regY:748.2,x:147.5,y:7.8},0).wait(1).to({x:113.5},0).wait(1).to({x:88.5},0).wait(1).to({x:72.5},0).wait(1).to({regX:71,regY:640,x:38,y:-100.4},0).to({_off:true},1).wait(11));

	// 10
	this.instance_2 = new lib.t2roll();
	this.instance_2.setTransform(148,655.6,1,1,0,0,0,71,640);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(17).to({_off:false},0).to({y:-388.4},6).to({y:-562.4},1).wait(1).to({x:131.6,y:-100.4},0).wait(4).to({regX:98.5,regY:748.2,x:116.1,y:7.8},0).wait(1).to({x:82.1},0).wait(1).to({x:57.1},0).wait(1).to({x:41.1},0).wait(1).to({regX:71,regY:640,x:6.6,y:-100.4},0).to({_off:true},1).wait(11));

	// 100
	this.instance_3 = new lib.t2roll();
	this.instance_3.setTransform(131,635,1,1,0,0,0,71,640);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).wait(7).to({x:128.6,y:665.6},0).to({x:131,y:-759.4},8).wait(1).to({x:116.6,y:-246.4},0).wait(8).to({x:100.6,y:-247.4},0).wait(4).to({regX:98.5,regY:748.2,x:85.1,y:-139.2},0).wait(1).to({x:51.1},0).wait(1).to({x:26.1},0).wait(1).to({x:10.1},0).wait(1).to({regX:71,regY:640,x:-24.4,y:-247.4},0).to({_off:true},1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// t1d
	this.instance = new lib.t1d();
	this.instance.setTransform(-1,1.1,1,1,0,0,0,0,11.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1c
	this.instance_1 = new lib.t1c();
	this.instance_1.setTransform(-80,1.1,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1b
	this.instance_2 = new lib.t1b();
	this.instance_2.setTransform(-171,1.1,1,1,0,0,0,0,11.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

	// t1a
	this.instance_3 = new lib.t1a();
	this.instance_3.setTransform(-250,1.1,1,1,0,0,0,0,11.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({alpha:1},6).wait(38));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{on:1,off:7});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6).call(this.frame_6).wait(6).call(this.frame_12).wait(1));

	// GET STARTED
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C2F35").s().p("AiMAaIAKgNQAMALAKAAQAFAAADgCQADgCAAgEQAAgDgDgCQgDgCgIgCQgOgDgGgEQgGgFAAgLQAAgLAIgFQAHgGAMAAQAIAAAIACQAHADAGAFIgJAMQgKgHgKAAQgEAAgDACQgDACABADQAAADACACQADACAMADQAKADAHADQAFAGAAAKQABAKgIAHQgIAGgNAAQgSAAgOgNgAmiAcQgMgLAAgRQAAgQANgLQALgLARAAQAQAAAMAKIgJANQgFgEgEgCQgFgCgFAAQgKAAgGAHQgHAHAAAJQABALAFAGQAHAHAJAAQAJAAAGgEIAAgUIARAAIAAAaQgMANgTAAQgRAAgMgLgAFpAmIAAhLIAbAAQAVAAAKAKQAMAKgBARQAAARgKALQgLAKgWAAgAF6AXIALAAQAMAAAGgGQAHgGgBgLQABgJgHgHQgGgGgOAAIgJAAgAEXAmIAAhLIA4AAIAAAQIgnAAIAAAPIAiAAIAAANIgiAAIAAAQIAoAAIAAAPgADaAmIAAg8IgXAAIAAgPIA+AAIAAAPIgXAAIAAA8gACeAmIgRgYIgMAAIAAAYIgRAAIAAhLIAdAAQASAAAIAGQAHAGABAOQgBAQgPAGIAUAbgACBAAIAMAAQAKAAACgCQAEgDAAgGQAAgGgEgDQgDgCgIAAIgNAAgABLAmIgHgQIghAAIgHAQIgSAAIAhhLIARAAIAhBLgAAqAHIATAAIgKgVgAgnAmIAAg8IgXAAIAAgPIA9AAIAAAPIgVAAIAAA8gAjrAmIAAg8IgWAAIAAgPIA9AAIAAAPIgWAAIAAA8gAlNAmIAAhLIA4AAIAAAQIgnAAIAAAPIAjAAIAAANIgjAAIAAAQIAoAAIAAAPg");
	this.shape.setTransform(68.7,32.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13));

	// gb-curve
	this.instance = new lib.gbcurve();
	this.instance.setTransform(150,134.8,1,1,0,0,0,150,134.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},6).to({alpha:1},6).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F0F0F0").s().p("Eg48AEsQgljbgBhHQgChFAdjoIABgIMByqAAAIAAJXg");
	this.shape_1.setTransform(368.6,30);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,0,736.8,60);


// stage content:
(lib.highlow_468x601b_GBP = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.enableMouseOver(20);
		
		this.loopNumber = 0 ;
		
		// CLICKTHROUGH
		this.clickTagBtn.addEventListener("click", function () {
			console.log("clickthrough");
			window.open(window.clickTAG);
		});
		
		// CTA
		this.clickTagBtn.addEventListener("mouseover", function () {
			exportRoot.bt.gotoAndPlay("on");
		});
		
		this.clickTagBtn.addEventListener("mouseout", function () {
			exportRoot.bt.gotoAndPlay("off");
		});
	}
	this.frame_56 = function() {
		this.stop();
	}
	this.frame_200 = function() {
		if(this.loopNumber >= 1){
			console.log("STOP BANNER");
			this.stop();
		} else {
			this.loopNumber++;
			console.log("RESTART: " + this.loopNumber);
		}
	}
	this.frame_207 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(56).call(this.frame_56).wait(144).call(this.frame_200).wait(7).call(this.frame_207).wait(1));

	// clickTagBtn
	this.clickTagBtn = new lib._clicktag();
	this.clickTagBtn.setTransform(0,0,2.925,0.1);
	new cjs.ButtonHelper(this.clickTagBtn, 0, 1, 2, false, new lib._clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickTagBtn).wait(208));

	// Border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("EgkjgErMBJHAAAIAAJXMhJHAAAg");
	this.shape.setTransform(234,30);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(208));

	// bt
	this.bt = new lib.btn();
	this.bt.setTransform(685,149.5,1,1,0,0,0,150,149.5);

	this.timeline.addTween(cjs.Tween.get(this.bt).wait(162).to({x:485,y:149.6,alpha:0},0).to({alpha:1},7).wait(32).to({x:685,y:149.5},6,cjs.Ease.get(-0.9)).wait(1));

	// t6
	this.instance = new lib.t6();
	this.instance.setTransform(239.1,58.1,1,1,0,0,0,0,12.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(158).to({_off:false},0).to({alpha:1},6).wait(37).to({x:-250.9},6,cjs.Ease.get(-0.9)).wait(1));

	// t5
	this.instance_1 = new lib.t5();
	this.instance_1.setTransform(240.3,35.1,1,1,0,0,0,0,11.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(155).to({_off:false},0).to({alpha:1},6).wait(40).to({x:-249.7},6,cjs.Ease.get(-0.9)).wait(1));

	// logo
	this.instance_2 = new lib.logo_mc();
	this.instance_2.setTransform(110.5,42.8,1,1,0,0,0,64.5,18.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(151).to({_off:false},0).to({alpha:1},7).wait(43).to({x:-379.5},6,cjs.Ease.get(-0.9)).wait(1));

	// t4
	this.instance_3 = new lib.t3();
	this.instance_3.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(64).to({_off:false},0).wait(45).to({y:349},8,cjs.Ease.get(0.9)).to({_off:true},1).wait(90));

	// bg
	this.instance_4 = new lib.gbcurve();
	this.instance_4.setTransform(10.8,-15.5,0.6,1.409,0,0.8,0);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(62).to({_off:false},0).wait(1).to({scaleX:0.86,scaleY:1.35,skewX:0,x:-85.2,y:-10.5},0).wait(1).to({regX:150,regY:134.8,scaleX:1,scaleY:1,x:145,y:134.8},0).wait(45).to({x:146.5},0).to({x:891},8,cjs.Ease.get(0.9)).wait(26).to({x:621},0).to({x:485},10,cjs.Ease.get(-1)).to({_off:true},16).wait(39));

	// bg
	this.instance_5 = new lib.gbcurve();
	this.instance_5.setTransform(621,134.8,1,1,0,0,0,150,134.8);
	this.instance_5._off = true;
	this.instance_5.filters = [new cjs.ColorFilter(0, 0, 0, 1, 63, 63, 63, 0)];
	this.instance_5.cache(-2,-2,741,64);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(143).to({_off:false},0).to({x:140.5},10,cjs.Ease.get(-1)).wait(48).to({x:150.5},0).to({alpha:0},6).wait(1));

	// web-img
	this.instance_6 = new lib.webimg();
	this.instance_6.setTransform(132,70,1,1,0,0,0,132,70);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(109).to({_off:false},0).to({y:-11},44).to({_off:true},1).wait(54));

	// t2
	this.instance_7 = new lib.t2copy();
	this.instance_7.setTransform(219.2,82.3,0.634,0.634,0,0,0,150.1,125);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(38).to({_off:false},0).wait(19).to({regX:150,scaleX:8.77,scaleY:8.77,x:-16,y:727.1},4,cjs.Ease.get(-1)).to({_off:true},1).wait(146));

	// 468x60_mask
	this.instance_8 = new lib._468x60_mask();
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(42).to({_off:false},0).to({_off:true},15).wait(151));

	// t2
	this.instance_9 = new lib.t2();
	this.instance_9.setTransform(219.2,152.3,0.634,0.634,0,0,0,150.1,125);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(38).to({_off:false},0).to({y:117.3},4,cjs.Ease.get(-0.9)).to({y:82.3},4,cjs.Ease.get(0.9)).wait(11).to({regX:150,scaleX:8.77,scaleY:8.77,x:-16,y:727.1},4,cjs.Ease.get(-1)).to({_off:true},1).wait(146));

	// t1
	this.instance_10 = new lib.t1();
	this.instance_10.setTransform(364.5,69.5,1,1,0,0,0,0,38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(38).to({y:39.5},4,cjs.Ease.get(-0.9)).to({y:-0.5},4,cjs.Ease.get(0.9)).to({_off:true},1).wait(161));

	// bg
	this.instance_11 = new lib.bgimg();
	this.instance_11.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(208));

	// bg
	this.instance_12 = new lib._bg();
	this.instance_12.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(208));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(233,29,1273,62);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;