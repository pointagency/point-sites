(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 300,
	height: 250,
	fps: 18,
	color: "#FFFFFF",
	manifest: [
		{src:"images/bg1.png", id:"bg1"},
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/bg2_blur.jpg", id:"bg2_blur"}
	]
};



// symbols:



(lib.bg1 = function() {
	this.initialize(img.bg1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,375,250);


(lib.bg2_blur = function() {
	this.initialize(img.bg2_blur);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,375,250);


(lib.t5b = function() {
	this.initialize();

	// Layer 2 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AirBfQgJgCgGgDIAEgQQAFADAIACQAHACAHAAQAOAAAGgHQAHgGAAgNIAAgMQgFAHgHADQgIADgJAAQgUABgKgOQgMgOAAgYIAAgCQAAgXAMgPQAKgQAUAAQAKAAAIAEQAIAEAEAIIADgOIAPAAIAABoQAAAVgMAKQgLALgXAAQgHAAgJgCgAitgYQgGAMgBAPIAAACQAAARAHAJQAHAKAOAAQAJAAAFgEQAGgEAEgHIAAgvQgEgHgGgEQgFgDgJAAQgOAAgHALgACTApQgNgPAAgXIAAgCQAAgWANgPQANgPAVAAQAWAAANAPQAMAPAAAWIAAACQAAAXgMAPQgNAQgVgBQgXABgMgQgACggZQgHALAAAPIAAABQAAARAHALQAIALAOAAQANAAAHgLQAHgLABgRIAAgBQgBgPgHgLQgHgLgOAAQgNAAgIALgAFSA3IgZhRIAAABIgYBQIgQAAIgehoIATAAIAUBOIAAAAIACgNIAWhBIAPAAIAWBBIACAOIABAAIACgOIARhBIATAAIgeBogAAiA3IAAiNIAUAAIAAB9IBCAAIAAAQgAgOA3IAAhBQAAgNgGgGQgGgHgLABQgHAAgHADQgHAEgEAGIAABNIgTAAIAAiXIATAAIAAA9QAFgHAIgFQAJgEAJAAQARAAAKAKQAHAKAAAWIAABAgAjzA3IAAhoIAUAAIAABogAknA3IAAg9IhFAAIAAA9IgTAAIAAiNIATAAIAABAIBFAAIAAhAIATAAIAACNgAjzhMIAAgUIAUAAIAAAUg");
	this.shape.setTransform(21,45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABJBSQAAgDgDgJQAUAAAOgBQAPgBAJgEQAJgCAHgFQAHgDAEgGIAEgJQACgEAAgEQAAgFgCgFQgCgEgEgEQgIgHgPAAQgJAAgIACIgTAHQgRAJgPATIgPgHIALhSIAVAGIgJAeQgDALgBAOQAOgJAWgJIAPgEIAPAAQALgBAJADQAJADAHADQAGAHADAHQADAHAAAIQAAAMgFAKQgEAJgKAIQgNAJgWAFQgWAFgfABgAhjBVQgIgDgGgFQgFgDgDgEQgCgFAAgFQAAgGACgFQADgEAFgFQAEgEAHgBQAHgCAKAAQAKAAALADIgCgkIABgRIAUACQgCAMAAAKIABAhIAOAFIAGACIAIAFIAQAIIgLATQgZgRgIgEQgBAJgCAFQgBAFgEADQgFADgHACQgHADgJAAQgJAAgIgDgAhkAzQgGAFAAADIACAGQACADAFACQAHACAGABQAGgBAEgBQAEgBADgDQACgCABgEQABgEgBgFQgMgGgLAAQgIAAgFAFgAizA9QANgYAKgYQALgUAIgXIgfAAIAAgSIAXACIANgCQAIgWACgLIAVAEIgKAbIAcgFIABASIgjAFIgWA4QgNAdgKARgAgrgaIgegIIAEgRQAUAEANAEIAfAKIgIASQgQgHgOgEgABlg7IgfgMIAIgRQATAIAIADIAkAKIgGASQgUgFgOgFg");
	this.shape_1.setTransform(-41.4,42.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-64.2,30.9,226.7,98);


(lib.t5 = function() {
	this.initialize();

	// Layer 2 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmHBJIAMAAIADgBIACgCIAAg2Ih8AAIAABKIgSAAIAAhaIChAAIAABIQAAAFgBAEQgCAEgDABQgDACgXAEQgBgKgDgJgAqYBKQAJgCALgGIAQgLQgLgPgCgEIgGgSIgMAAIAAgPIBCAAIADgCIAMAMIgQAdQgGAKgFADQAIAGAJAFIASAIIgFAGIgGAKIgUgKIgQgNQgRAQgVAHQgCgHgHgJgApwAfQADAHAFAGQAEgEAMgWIgdAAQACAHADAGgAqrBaIAAgWIhCAMIgCgSIARgCIAAhEIgRAAIAAgOICxAAIAAAOIhdAAIAABigArNA7IAigFIAAgMIgiAAgArNAdIAiAAIAAgMIgiAAgArNAEIAiAAIAAgMIgiAAgAKFBYIAAirIAXAAIAAA3QAiAMALAGIAnASIgLATQgSgMgTgJQgVgIgPgFIAABfgAHYBFQARgFAVgHIAbgSIAKgMIAKgQQADgJACgJQACgLAAgPIheAAIAAAxIgUAAIAAhCIA5AAIAAgiIAVAAIAAAiIA7AAQgDAjgCAJQgFAWgFAKQgMARgGAHQgRAOgNAIQgTAKgXAGQgGgOgEgFgAEVBLIgGgGQANgEAOgGQAJgGAFgIQAHgIADgKQADgIABgQIABgdIAVAAIAAAKIAlgjIh5AAIAAgSICMAAIADgBIAMAQIgaAZIglAdIgIgIQgDAegDALQgDAOgJAJQgHAJgLAIQgIAHgUAIgACeBXIAAhdQgTANgSAKQgXANgMAGQgEgLgHgIQAdgLAUgNIAUgNIAXgSIAUgVIAVgXIARAOIguAtIAABugAjkBBIAWgFQAJgDAEgDQAHgDAFgFQAGgFAEgGQAFgIACgIQACgIAAgKQAAgXgOgOQgIgIgKgFQgKgEgNAAIgJArQgFAQgFALQgFAPgHALQgGALgHAGIgHAFQgEACgEAAQgGAAgFgDQgGgDgEgHQgHgIgDgLQgCgLAAgNQAAgPAFgOQAHgPANgLQAYgXApgBQAUAAAUAKQANAFAIAJQAEAEADAFIAFAMQAEAOAAAJQAAAMgDALQgCAKgGAJQgFAIgGAHQgIAHgKAGQgNAIgZAFQgEgKgEgIgAkGgqQgKAGgHAIQgGAJgEALQgCAIAAALQgBAJACAHQACAIAEAFQADAHAGAAQADAAACgDQAEgEAEgJIALgXQAFgNAEgPIAGgfQgOADgMAGgAnfBJIAAgvIBSAAIAAApIhAAAIAAAGgAnNA2IAuAAIAAgOIguAAgAgpgeQgEgDgBAAIgEACIgxA6IgPgPIAmgqQAQgSAFgDQAEgDAEABQAFgBAFADIBfBmIgRAOQgvg6gjglgAnrgIIAAgqIBqAAIAAAqgAnYgWIBEAAIAAgOIhEAAgArVgeIAAg1IB7AAIAAA1gArFgrIBZAAIAAgIIhZAAgArFg+IBZAAIAAgJIhZAAgAAJghIgHgFIgDgHQgCgEABgEQgBgFACgEIADgHQADgDAEgBQAEgBAEAAQAFAAADABIAHAEQADADACAEQACAEAAAFQAAAEgCAEQgCAEgDADIgHAFQgDABgFAAQgEAAgEgBgAAJg+QgDAEAAAFQAAAEADAEQAEACAEAAQAFAAADgCQADgEABgEQgBgFgDgEQgDgCgFAAQgEAAgEACgAoKg7IAAgPIBMAAIAAgRIAVAAIAAARIBKAAIAAAPg");
	this.shape.setTransform(0,10.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-75.3,-1.6,291.9,98);


(lib.t3 = function() {
	this.initialize();

	// Layer 1 copy 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC538").s().p("AD4BqQgLgCgKgFQgKgDgJgHQgJgFgHgHQgIgIgGgJQgFgIgFgKQgEgKgCgKQgCgLAAgLIAAAAQAAgJACgLQACgLAFgJQAEgKAGgJQAFgJAIgHQAHgHAJgHQAJgFAKgFQALgEALgCQALgCAMAAQAMAAALACQAMACAKAEQAKAFAJAFQAIAGAIAIQAHAHAGAJQAGAIAEAKQAEAKACAKQACALAAAKIAAAAQAAAKgCAMQgCAKgEAJQgEALgGAIQgGAJgHAHQgIAIgJAFQgJAHgKADQgKAFgLACQgMACgMAAQgMAAgLgCgAD2g7QgMAEgIAJQgIAKgFALQgFAMAAANIAAAAQAAANAFAMQAFAMAIAJQAJAKALAEQAMAFAOABQAOgBAMgFQALgFAJgIQAIgKAEgMQAFgMAAgNIAAAAQAAgMgFgMQgEgMgJgJQgIgJgMgFQgMgGgOABQgNgBgMAGgAk9BqQgMgCgKgEQgKgEgJgGIgQgNIgNgQQgFgIgEgKQgEgJgCgLQgCgLAAgMIAAAAQAAgJACgLQACgLAEgJQAEgKAGgJQAFgJAIgHQAHgHAJgHQAJgFAKgFQAKgEALgCQALgCAMAAQAOAAAMACQALACAKADQANAFAWAQIgdAkQgNgLgLgFQgOgFgRAAQgMgBgLAGQgLAEgJAJQgIAKgEALQgFAMAAANIAAAAQAAANAFANQAEAMAJAJQAIAJAMAFQAMAFANAAQANAAALgDQALgDAJgHIAAgdIguAAIAAgmIBbAAIAABZQgYASgPAFQgLAFgNACQgNADgOAAQgMAAgLgCgAI5BqIgviHIgwCHIgoAAIhIjRIAyAAIArCLIAviMIAoAAIAvCMIAsiLIAwAAIhIDRgAAWBpIAAjQIAuAAIAAClIBpAAIAAArgAgxBpIAAhUIhVAAIAABUIguAAIAAjQIAuAAIAABTIBVAAIAAhTIAuAAIAADQgAnWBpIAAjQIAvAAIAADQgAokBpIAAhUIhVAAIAABUIgvAAIAAjQIAvAAIAABTIBVAAIAAhTIAuAAIAADQg");
	this.shape.setTransform(68.5,108.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AkwHPIgJgvIBHAAQAHAAAEgCQADgCADgFQACgFABgMIACgcIh3AAQAHgiAJhLIBnAAIAAgYIhzAAIAAgrICgAAIAABtIhrAAIgFAYIByAAQgEBfgIAWQgFALgIAHQgFAEgGACQgGADgIAAgAodGuIAAAgIgrAAIAAgvQg8AQghAEIgFgtIAPgBIAAijIgNAAIAAgpICaAAIAAANIB/AAIAAAqQgHAvgHAYIgLAhQgHARgIANQAWAaAbAPIgbAuQgdgUgWgbQgPAQgQAOIgXATgAodGhQAbgUAUgYQgPgfgGgSQgFgQgDgQQgDgSgCgTIAngLQACAuAUApQAIgQAFgSQAFgPAHgqIhYAAIAAgOIgLAAgApwGAIAogHIAAgYIgoAAgApwE8IAoAAIAAgbIgoAAgApwD8IAoAAIAAgaIgoAAgAh3HOIAAkcIAvAAIAAEcgABkHAQgOgFgKgJQgJgHgEgMQgFgKAAgMQAAgLAEgLQAEgLAIgJQAKgJAOgGIARgDIAUgCIASABIgDhsIAfgGQAbgDAmAAIAEAzIgYgCIgcACIACBRQAmAVASARIgaAuIghggIgBAGQAAAMgGAKQgFAJgJAFQgIAFgMADQgLADgNAAQgSAAgOgEgABkGHQAAAIAFAFQADADAGACQAGACAJABQAJAAAFgCQAFgDADgDQADgEAAgIIAAgRQgLgFgLAAQggAAAAAVgAEvHCIgJgvQAfADAnAAQAVABAfgEQAVgEANgGQALgHAFgJQAFgJAAgLQAAghgqgCQgMAAgLACQgMACgLAFQgMAEgJAGQgKAGgIAJIAAAJIgwgCQABhQAGguIAxAEIgFAiIgCAfQAogaA1AAQANAAAXAHQALADAQANQAKAKAGAOQAFAOAAARQAAAOgDANQgEALgGAJQgGAJgJAIQgIAGgKAFQgRAIgTADQgvAHgsAAgAgSGVQAGgNAQgxQAIgZANg2IgmAAIAAguIAuAAIAEgiIAyACIgFAgIA0AAIAAAuIg8AAQgMAzgIAbQgMApgNAlgAG6DzIglgIIhBgHIAIgsQBNACA9ARIgLAxQgNgFgUgEgAo9CDIgJgvIAqACQAGAAAEgCQAEgCAAgIIAAhGQgPATgSASQgQAPgSANQgOAKgQAKIgYANIgdglQAUgJASgLQASgLARgNQARgNAPgNQAPgPAOgQIh4AAIAAguICIAAIAAguIAvAAIAAAuIBEAAIAAAuIhEAAIABB9QAAAOgGALQgFAHgJAFQgIADgMACIgUABgAlpBVQAYgDAUgFQATgGAQgIQAPgHAMgJQAMgJAJgKQAJgKAHgLQAGgJAFgNQAGgPAGgiIi5AAIAAgwIC9AAQABANAEAKQAEAIAHAFQAGAFAJACQAHACAKAAQgGAmgGATQgFANgHAOQgIAPgKANQgKAPgOAMQgPANgSALQgTAMgXAIQgiALgUAEgAhTBOIAigFQASgCAOgDQAQgFALgFQAPgHAMgHQAMgKALgLQAMgMAJgNQAKgQAJgUQAJgUAHgZIAtAVQgJAbgKAWQgKATgLATQgMARgNAOQgMAOgPALQgOALgQAHQgQAJgSAFQgPAGgUAEIgoAGgAGoBNQAWgDATgDQAUgEARgFQARgFAPgIQAPgIAMgKQANgKALgNQALgLAJgQQAKgQAHgTQAIgUAHgWIAtAXQgIAXgGAPIgGAPQgKAVgNATQgJAOgLAMIgHAIQgOAOgQAMQgPAKgSAIQgQAIgSAGQgRAFgUAFIgmAGgADLB8IAAgqICKAAIAAgmIiCAAIAAgnICCAAIAAghIiHAAIAAgpIC1AAIAADBgAg1ABQgWgHgYgHIAQgoQAUAFAXAHQAQAFAeAQIgRAoQgTgKgXgJgAHVg3QgYgMgZgIIAVgpQAXAHAjAOQAVAKAUANIgaAsQgUgOgZgNgAhMhTIARgoQAXAEAYAIQAYAJAUAKIgSAqQgkgTg2gOgAighPQgHgDgEgEQgFgFgCgGQgDgGAAgHQAAgHADgHQACgFAFgFQAFgEAGgDQAGgDAHAAQAHAAAGADQAGADAEAEQAFAFADAGQACAGAAAHQAAAHgCAGQgDAGgEAEQgFAFgGADQgGACgHAAQgHAAgGgCgAidh4QgEAEAAAGQAAAGAEAEQAEAEAGAAQAGAAAEgEQAEgEAAgGQAAgGgEgEQgFgEgFAAQgGAAgEAEgAC9joQAVgCAigFIAXgFQAKgEAIgEQAIgFAGgGQAHgGAEgIQAEgIACgJQACgJAAgLIAAiEIAzAAIAAB8QAAAUgEARQgDAQgHANQgHANgJAKQgJAKgMAHQgLAHgOAFQgMAFgPADQgnAIgUACgAhujiQAvgOAZgZQAHgGAGgJQAFgIAEgJQAEgNACgaIAAgHIhrAAIAAguIBrAAIAAg8IAwAAIAAA8IBkAAIAAAuIhkAAQAAB3h4AmgAkMi9IAAh7QgaAPgXAKQgVAKgeAJIgagoQB/gkBehuIArAeQgnAqgwAkIAACdgAqmjiQAfgmAOg8QAMgxAChDIAwAGQgGA+gDAZQgIAvgFAUQgLAigIAPQgQAcgKANgAnTjnQgOgfgGgSQgGgUgKgvQgFgZgGhAIAjgEQAIAYADAUIAFgCQAFAiAEAQQAJAjALAYQAPAkAVAbIgtAiQgOgTgKgUgACtkVIAAikIAzAAIAACkgAGiklIAAgyIEJAAIAAAygAnOmrQgEgQgFgJIAagGQAMAeADASIgbAGgAmwnJIAZgFIALAdIAFATIgZAFQgIgdgIgTg");
	this.shape_1.setTransform(68.4,46.4);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,309.4,177.8);


(lib.t2 = function() {
	this.initialize();

	// Layer 1 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC538").s().p("AhDCOIAAgLIhXAAIAAALIgtAAIAAh9ICxAAIAAB9gAiaBbIBXAAIAAgiIhXAAgAkMCOIAAiBIgOAPIgLg9QAIgKAGgLQAHgMAFgNQAGgNAEgPQAEgPACgTIAsADQgIArgKAeIAADPgACRBVIAdgEIAQgEIARgHQAIgFAGgGQAHgHAFgIQAFgJADgMQADgLAAgMIAAgCQAAgSgFgOQgFgNgJgKQgIgIgMgFQgLgFgNgBQgDArgIAhIgGAXQgFARgHAOQgHAPgJALQgKAMgLAGQgNAHgOAAQgIAAgHgCQgHgBgGgEQgMgHgIgMQgJgMgFgQQgEgQAAgSIABgRIABgGQACgNAFgMQAEgMAHgLQAHgMAIgKQAKgKALgIQALgJAOgFQAOgGAQgEQAQgDASAAQANAAANACQAMACALADQAMAEAKAGQAKAFAJAIQAIAHAHAKQAHAKAFALQAFAMADAOQACANAAAOIAAAAQAAAOgCAMQgCAOgFAMQgEAMgIAMQgIAMgMAKQgKAJgOAGQgMAGgOAEQgRAEgXADgABxhBQgJAGgHAHIgMAOIgHAPQgFALgCAMIgBABIgBAPQAAANAEALQACAHAEADQAFAFAGAAQAIAAAIgLQAHgJAGgTIAFgQIAFgXQAEgYACgbQgMAEgKAFgAjWAAIAAgmIApAAQgEgXgFgQIgWAAIAAgoIBHAAIAAgXIAuAAIAAAXIBIAAIAAAoIgYAAQgEATgFAUIArAAIAAAmgAiCgmIAoAAQAFgRADgWIg5AAg");
	this.shape.setTransform(80.7,46.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFC538").s().p("AB0BqQgKgCgIgEQgJgEgHgGQgHgGgHgHQgFgIgFgIQgFgIgDgLQgDgJgCgLIgBgWIAAAAQAAgKABgKQACgLADgKQADgKAFgIQAFgKAGgGIAOgOQAHgFAJgFQAJgEAJgCQAKgCAKAAQAKAAAKACQAJACAJAEQAIAEAIAGQAHAGAGAHQAGAHAFAJQAFAJADAKQADAJACALQACAKgBALIAAAAQABALgCALQgCALgDAJQgDAKgFAIQgFAJgGAIQgGAHgHAGQgIAFgJAEQgIAFgKACQgKACgKAAQgKAAgKgCgAB2g9QgJAGgGAJQgGAIgDAMQgEANABANIAAAAQgBAOAEAMQADANAGAJQAHAIAIAFQAJAGAKAAQAKAAAJgGQAIgFAGgIQAGgKADgMQADgMAAgOIAAAAQAAgNgDgMQgDgMgGgJQgHgJgIgGQgIgEgLAAQgKAAgIAEgAgmBpIAAgwIAvAAIAAAwgAjlBpIAAglIBHg5QAUgQAHgJQAFgGACgGQACgFAAgHQAAgNgIgHQgHgHgNAAQgMAAgKAHQgJAGgMAPIghgaQAIgLAIgIQAIgIAJgFQAKgGAKgCQAMgEANAAQARAAANAFQAOAFAJAIQAKAIAFANQAFAMAAAPIAAAAQAAANgDAKQgDAKgHAIQgHAJgLAJIg7AvIBcAAIAAAog");
	this.shape_1.setTransform(24.1,48.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEFEFE").s().p("ApRBoQASgGAMgHQALgHAGgIQAIgKADgWIgeAQIgXAKIgVgtQAugLAXgSIguAAIAAiCID2AAIAACCIgwAAQAOAIAYAMQAOAGAUAEIgVAsQgdgKgZgOIAABfIguAAIAAh3IANAAQgNgMgLgOIgdAAQgMAPgOALIAQAAQgBAYgDAQQgDATgIAOQgNATgKAIQgXAPgPAGgAm6gmIA6AAIAAgQIg6AAgAodgmIA6AAIAAgQIg6AAgAm6hSIA6AAIAAgQIg6AAgAodhSIA6AAIAAgQIg6AAgAL5COIAAgtIh4AAIAAgrIB4AAIAAgOIgQAAIAAhUIgMAJIgZgmQANgLAKgMQAIgKAGgKQAIgNAEgNIAyAEIgGARIAWAAIAIgVIAxACIgIATIAwAAIAAAjIg1AAIAAANIAvAAIAAAbIgvAAIAAANIAvAAIAAAbIgvAAIAAALIA5AAIAAAjIh2AAIAAAOIB4AAIAAArIh4AAIAAAtgAMVAHIAlAAIAAgNIglAAgAMVgfIAlAAIAAgPIglAAgAMVhIIAlAAIAAgOIglAAgADfCNIgFgZIh5AAIAAhLICJAAIAAA5IALAAQAGAAAAgGIAAg+IisAAIAABvIgtAAIAAiOIEGAAIAABvQAAAfgcAAgACMBWIA0AAIAAgRIg0AAgAhTB1QgOAIgQAHQgLAEgPAEIgQgkIAAAkIgqAAIAAgTQgyAHgvABIgDglIASgBIAAhbIgQAAIAAgiIEeAAIAAAiIiSAAIAABmQAUgFATgHQgKgLgHgLIgJgRIAjgKIgpAAIAAggICBAAIAAAgQgLAdgSATQAJAEAiAJIgXAnQgigLgVgNgAjuBaIApgCIAAgOIgpAAgAhhA1IAPAPQALgKAKgRIgsAAgAjuAxIApAAIAAgNIgpAAgAjuALIApAAIAAgLIgpAAgAGZCNIgJgvIAsAAQAIAAAAgHIAAjkIAvAAIAAAjQAAAFAIAdIAJAdIAhgfQAQgRAOgRIAnAeQgcAegQAOQgXAVgOAKQAcAoA4AmIgbAuQgPgKgPgOQgPgNgNgPQgNgQgJgPQgKgQgFgOIAABnQAAAIgDAHQgCAFgFAEQgHAGgMAAgAsjCNIAAg2QgVARgPAJQgjAQgdAKIgWgpQAygLAmgVIhWAAIAAgjIB4AAIAAgMIhkAAIAAgbIBkAAIAAgMIhsAAIAAghIA8AAIgGgQIhCAAIAAglIAmAAQgGgOgHgNIArgIQAIAQAFATIANAAIAAgiIAnAAIAAAiIARAAIAAgiIAoAAIAAAiIAMAAQAIgPAFgUIAsAIIgNAbIAkAAIAAAlIhBAAIgFAQIA8AAIAAAhIhsAAIAAAMIBkAAIAAAbIhkAAIAAAMIB2AAIAAAjIhVAAQAiAUA3ALIgXApQgogNgPgIQgLgGgLgHIgWgSIAAA3gAslg1IAxAAIAFgQIg8AAgAFJBKIALgIIAWgUQAMgOAIgQQAKgRAGggIg/AAIAAgtIBqAAIAAAtIgGAgIgIAZQgOAfgHAMQgLARgPANQgLALgOAKgAKGARQAOgKASgSQAMgMATgaIAZAjQgKAOgSAUQgTAVgOAMgABAgMIAAhGIDLAAIAABGgABsgoIByAAIAAgPIhyAAgAJ+gyIAUgkQAgAMASANIgVAiQgSgMgfgLgAkQgsIAAhbIDwAAIAABbgAjjhDICWAAIAAgMIiWAAgAjjhiICWAAIAAgLIiWAAgAKlhgQgQgHgLgEIAUgiQAfAKAVAOIgVAkgAAYhbIAAgkIB1AAIAAgPIAvAAIAAAPIB4AAIAAAkg");
	this.shape_2.setTransform(92.7,14.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEFEFE").s().p("AhaBgIAagMQALgGAKgHQAJgHAHgIQAHgIAFgKQAFgIAEgLQAEgLACgJQABgRAAglIAyABIgCAmQANgGALgIQAJgHAIgIQAJgLAJgTIjIAAIAAguIEFAAQgGAjgFAPQgLAagIALQgQAWgKAIQgOALgUAMIgfggQgDAWgFASQgKAagIANIgOASQgIAJgIAIQgKAKgMAHQgNAJgQAHgADlBZQAWgBASgEQAVgDASgHQATgHAPgLIAOgLQAHgIAFgIQARgYAFgwIiOAAIAAA9IgvAAIAAhqIBeAAIAAgqIAxAAIAAAqIBhAAIAAAUQgCAtgIAbQgKAdgIAOQgHAMgHAIQgIALgKAHQgZATgWAKQgRAHgVAFQggAGgTACgAHkCFIAAkHIA1AAIAABHQAYAIAzAUQAZALAsAWIgaAzQgkgXgVgMQgrgUgSgFIAACMgAkECBIAAh6QgaAPgXAJQgWAKgdAKIgbgpQB/ghBehuIAsAdQgoArgwAkIAACagAolgfQgMgNgGAAQgEgBgFAEIgGAHIg8BRIgmgsIAxg4QANgQAUgTQAHgHAIgDQAHgEAJAAQAUAAAZAZICBCKIglAsgAnLhDQgGgCgEgFQgFgEgCgHQgDgGAAgGQAAgIADgGQACgGAFgEQAFgFAGgCQAGgDAGAAQAHAAAGADQAGACAFAFQAEAEADAGQACAGAAAIQAAAGgCAGQgDAHgEAEQgFAFgGACQgGADgHAAQgGAAgHgDgAnHhqQgEADAAAGQAAAFAEAEQAEAEAFAAQAGAAAEgEQADgEAAgFQAAgGgEgDQgDgEgGgBQgFABgEAEg");
	this.shape_3.setTransform(68.1,78.2);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,221.6,486.1);


(lib.t1 = function() {
	this.initialize();

	// Layer 1 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC538").s().p("ACyBqQAlgWAKgZIgsAAIAAgnIAzAAIABgQIAnAAIgBAQIAxAAIAAAnIgpAAQARAVAVAMIgKAOQAQgFAPgHQAOgHAJgIIgeAAIAAidIAmAAIADgPIgyAAIAAgoICOAAIAAAoIgxAAIgEAPIAtAAIAACdIggAAQAQAOAdALIgTAmQgrgYgNgPIAXgYIgxAAIAWAZQgVAQgMAGQgQAJgRAHIgTghIgOASQgUgQgRgZQgQAfgiAagAF0AvIAqAAIAAgPIgqAAgAF0AHIAqAAIAAgNIgqAAgAF0ghIAqAAIAAgOIgqAAgAhvCOIAAhjQgGARgHAOIgNAYIgQg6QAXgcAPglIgfAAIAAgpIAjAAIAAgaIgfACIgEgoQA4gCAjgKIAMAoIgcAGIAAAeIAZAAIAAgZIBEAAIAAgKIg4AAIgFgfQAiABAkgCIAvgDQAagCAQgDIAKAhQgiADghACIAAAMIBIAAIAAAhIhIAAIAAALIA/AAIAABgIg/AAIAAALIBCAAIAAAdIhCAAIAAAMIBIAAIAAAhIi+AAIAAghIBNAAIAAgMIhCAAIAAgdIBCAAIAAgLIg8AAIAAgaIgPAhQgLgQgHgOIAAB0gAA/AXIAXAAIAAgNIgXAAgAAAAXIAWAAIAAgNIgWAAgAgmARIAAhAIA8AAIAAgLIhEAAIAAAhIgYAAQAOAZASARgAA/gIIAXAAIAAgNIgXAAgAAAgIIAWAAIAAgNIgWAAgAlZBUIAdgDIAQgFIARgHQAIgEAGgGQAHgHAFgJQAFgJADgLQADgNAAgMQAAgSgFgPQgFgNgJgJQgIgJgMgFQgLgEgNgBQgEA6gNApQgFARgHAOQgHAPgJALQgKAMgLAGQgNAHgOAAQgIAAgHgCQgHgCgGgDQgMgHgIgNQgJgMgFgQQgEgQAAgRQAAgNACgLQACgMAFgMQAEgNAHgLQAHgLAIgKQAKgLALgIQALgIAOgGQAOgGAQgDQAQgDASAAQANAAANABQAMACALAEQAMAEAKAFQAKAGAJAHQAIAIAHAJQAHAKAFAMQAFALADAOQACAOAAAOQAAANgCANQgCANgFAMQgEANgIALQgIAMgMAKQgKAJgOAHQgMAFgOAEQgRAFgXADgAl5hBQgJAFgHAHIgMAOIgHAPQgGANgCAMIgBAPQAAANAEAKQACAHAEAEQAFAEAGAAQAIAAAIgKQAHgKAGgSQAGgQAEgYQAEgXACgbQgMADgKAGgACwgXIARgKQAMgIAKgLIgiAAIAAglIA0AAIAAg0IAnAAIAAA0IAwAAIAAAlIggAAIASAQQAJAHAKAFIgVAdQgXgQgJgQIAAAbIgnAAIAAgaQgIALgIAIIgRANgAEShkQAIgRAFgWIAjAJQgGAVgJATgAC1h/IAigMQAJARAGAVIgiAKQgEgPgLgVg");
	this.shape.setTransform(48,110.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AoqHHIgJguIAqABQAGAAAEgBQAFgDAAgHIAAhGQgQATgSARQgQAPgSANQgOALgQAKIgYANIgdglQAUgJASgLQASgLARgNQARgNAQgPQAOgPAOgRIh3AAIAAgtICHAAIAAgvIAwAAIAAAvIBDAAIAAAtIhDAAIAAB/QAAAPgGAKQgEAIgKAFQgIADgLABIgVABgAlcGaQAYgDAUgGQATgFAQgIQAPgHAMgJQANgJAIgKQAKgKAGgMQAHgKAEgNQAHgQAFghIi5AAIAAgwIC9AAQABANAEAJQAEAJAHAFQAGAFAJACQAIACAJAAQgFAlgHAUQgFAPgHAOQgHAPgKANQgLAPgOAMQgPANgSALQgTALgXAJQgiAKgTAFgAhOGSIAigEQASgCAPgEQAOgEANgFQAOgHAMgIQANgJAKgLQAMgMAKgPQAKgQAIgUQAJgVAIgYIAtAVQgKAbgJAWQgKAVgMASQgMASgNAOQgMAOgPAKQgOALgQAIQgQAIgSAGQgOAFgVAEIgoAHgAGZGRQAWgCATgDQATgEARgFQARgGAQgHQAOgIANgKQANgKALgNQALgNAJgQQAKgQAHgTQAIgUAGgWIAtAWQgMAlgHAQQgLAYgNATQgMASgPAQQgNAOgRALQgPALgRAIQgQAIgSAGQgSAFgTAEIgmAHgAC9HBIAAgqICLAAIAAgmIiDAAIAAgnICDAAIAAgkIiHAAIAAgoIC0AAIAADDgAgvFGQgXgJgYgHIAQgoQAUAEAXAIQARAFAdAPIgRArQgTgLgWgIgAHGEMQgYgMgagIIAWgpQAXAGAjAPQAVAKATAMIgZAsQgVgOgYgMgAhHDwIARgoQAXAEAYAIQAYAIAUAKIgSArQgjgTg3gOgAiTD0QgGgDgFgEQgEgFgDgGQgDgGAAgHQAAgHADgHQACgGAFgEQAFgFAGgCQAHgDAGAAQAHAAAGADQAGACAFAFQAFAFACAGQACAGABAHQgBAHgCAGQgCAGgFAEQgEAFgGADQgHACgHAAQgHAAgGgCgAiQDLQgEAEAAAGQAAAFAEAFQAFAEAFAAQAGAAAEgEQAEgEAAgGQAAgGgEgEQgFgEgFAAQgFAAgFAEgAlXBvQAWgBAegEQAOgDAOgFIg0AAIAAhyIgSAHIgJgsQATgEA7gVIADAnIgXAKIApAAIgLgbQA6gHAKgcIgWAAQgMAKgIAGIgPAIIgXgeQAPgIAOgLQANgKAHgKIAtACIgIALIB1AAIAAAcQgEAOgNATIgngNQAGgGAFgKIgiAAQAEAHAFAGQAGAGAKAFQALAGAOAEQAQAEAXACIgTApIgLgDIAABvIgzAAQAMAEAQADIAYADIAdACIgTAnQgggFgVgGQgfgLgTgJIARgUIhUAAIASAUQgoAYg9AIgAkOBHICOAAIAAgMIiOAAgAkOAlICOAAIAAgLIiOAAgAkOAFICOAAIAAgJIiOAAgAi2grQgLAIgOAGIBUAAQgZgPgOgSQgJALgLAIgAoUCSIgJgoQgPAWgRAQIgjgdQANgLAMgQQAMgQAHgQIAoASQgGAPgKAPIAYAAQAEAAABgCIABgHIAAgoIhHAAIAAh9IA/AAIAEgQIhRAAIAABhQgBBTgfA0IgngjQAGgKAFgNQAGgNACgOQAFgSACgjIAAiHIEHAAIAAApIhYAAIgFAQIBNAAIAAB9IhGAAIAAA+QAAANgEAGQgDAFgGADQgHACgLAAgAoaAUIBnAAIAAgPIhnAAgAoagVIBnAAIAAgPIhnAAgAghBxQAUglABg0IAAhXIAuAAQgCgKgEgKIgqAAIAAgmIBmAAIAAgQIAuAAIAAAQIBpAAIAAAmIgrAAIgIAUIBAAAIAAAmIhaAAIAAAUIBPAAIAAAiIhPAAIAAASIBEAAIAAAiIhEAAIAAASIBaAAIAAAoIjjAAIAAgoIBdAAIAAgSIhEAAIAAgiIgWgQQgBBNgZAmgAA/AvIA3AAIAAgSIgrAAQgFAKgHAIgAAdAVQAJgIAHgNQAHgLAEgOIgbAAgABhgSIgFANIAaAAIAAgUIg6AAgABPg/IA/AAIAGgUIhKAAgAmxBuQgMgSgGgSIAngSIASAfQAKAOANAMIgjAfQgUgWgHgMgAF1CGQgRgBgOgDIgVgFIgQgHQgHgEgHgGQgGgGgFgHQgEgHgCgIQgDgIAAgIQAAgKADgJQACgIAEgIQAIgNANgMQAQgMAfgPQgGgFgCgGQgFgKgBgRQgBgYAAgnIA0AAIgBAnIABAgQABAJAFAFQAagIBEgNIAKAxQgeADgbAFQgnAHgRAGQgfANgLAIQgIAGgEAHQgFAHAAAIQAAAKAHAGQAFAGAMADQAOAEAsAAIArgBQAegBAagDIAAAxQguADgnAAgAlQhkIASgjQAaAHAeANIgWAkQgQgJgkgMgAiBirIAAgKIihAAIAAAKIgrAAIAAhxID2AAIAABxgAi9jQIA8AAIAAgOIg8AAgAkijQIA7AAIAAgOIg7AAgAi9j1IA8AAIAAgNIg8AAgAkij1IA7AAIAAgNIg7AAgAqTixIAAgkIBAAAIgGgQIggAAIAAg9IDlAAIAAA9IgfAAIgGAQIBAAAIAAAkgAomjVIBAAAIAFgQIhKAAgApMj9ICLAAIAAgMIiLAAgABDi6QgOgEgKgJQgJgIgFgLQgEgKAAgNQAAgLADgKQAFgLAIgJQAJgJAOgGIARgEIAUgCIASACIgDhtIAggFQAagDAngBIAEAzIgYgBIgcACIACBQQAmAWASARIgaAtIgigfIAAAGQAAAMgGAKQgFAIgJAGQgJAFgLADQgLADgNAAQgSAAgOgFgABDjyQAAAHAFAFQADAEAFACQAHACAJAAQAIAAAGgCQAFgCACgDQADgEABgJIAAgRQgMgEgKAAQggAAAAAVgAg0jkQAHgNASgxQAIgZANg2IgoAAIAAguIAuAAIAEgiIAyACIgFAgIAzAAIAAAuIg7AAQgMAygIAcQgMApgLAkgAk5kmIAAg+IDPAAIAAA+gAkOk9IB6AAIAAgPIh6AAgAqTksIAAghIEaAAIAAAhgAqBlXIAAhkIBDAAIAAgMIAqAAIAAAMIAcAAIAAgMIApAAIAAAMIBFAAIAABkgAnRlxIAeAAIAAgNIgeAAgAoUlxIAcAAIAAgNIgcAAgApZlxIAdAAIAAgNIgdAAgAnRmTIAeAAIAAgNIgeAAgAoUmTIAcAAIAAgNIgcAAgApZmTIAdAAIAAgNIgdAAgAkjlvIAAgaICkAAIAAAagAh0lwIAAgkIi6AAIAAAkIgqAAIAAhHIBwAAIAAgQIAuAAIAAAQIByAAIAABHg");
	this.shape_1.setTransform(66.7,45.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,220.7,169.2);


(lib.strip = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC538").s().p("AgdTiMAAAgnDIA7AAMAAAAnDg");
	this.shape.setTransform(3,125);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6,250);


(lib.logo_mc = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2E").s().p("AAVA8QgjAAgIgCQgPgDgGgHQgGgIgCgNQgBgFAAgUQAAgVABgGQADgPAHgIQAJgIAZgCIAjgBQAoAAALADQARADAEANQADAHAAAPIgkAAQAAgEgCgFQgEgEgJAAIgzAAIgFABQgGACgDAFQgCAFAAAVQAAAPACAEQACAIAJABIAWABIAiAAQAMgBABgJIAAgIIguAAIAAgUIBSAAIAAAPQAAAZgDAHQgDAJgGAFQgJAEgOABgADrA7IAAguIhTAAIAAAuIglAAIAAh1IAlAAIAAAsIBTAAIAAgsIAlAAIAAB1gAhkA7IAAh1IAlAAIAAB1gAiWA7IAAguIhUAAIAAAuIgmAAIAAh1IAmAAIAAAsIBUAAIAAgsIAlAAIAAB1g");
	this.shape.setTransform(31.8,15.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AheA6QgOgCgGgIQgHgFgCgOQgCgIAAgVIABgUQgBgFADgHQADgMAJgHQAKgGAXgCIAhAAQAqAAAKABQAPADAGAIQAHAJABAMQACAKAAARQAAAbgFAKQgEAKgJAFQgIAEgFABIgVACIgdAAQgqAAgKgCgAhHgdQgLABgDAHQgCAFAAAQQAAAQACAGQADAGAMACQAHABAUAAQAbAAAHgCQAHgBACgFQACgFgBgIIABgKQAAgQgCgGQAAgEgDgBQgFgDgHAAIgbAAQgZAAgEABgAkSA7IAAh1IAlAAIAABXIBkAAIAAAegACyA7IgVhJIgXBJIgzAAIgsh2IAoAAIAdBRIAahRIAuAAIAZBRIAdhRIAoAAIgtB2g");
	this.shape_1.setTransform(97.6,21.9);

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E1E0DF").s().p("AAABlIk8A5IAAkCIE8g5IE9A5IAAECg");
	this.shape_2.setTransform(31.8,15.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6B6B6A").s().p("Ak8BlIAAkCIE8A5IE9g5IAAECIk9A5g");
	this.shape_3.setTransform(97.2,21.8);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,129,37.7);


(lib.btnbg = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F0F0F0").s().p("A0TDvIAAneMAonAAAIAAHeg");
	this.shape.setTransform(130,24);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FCCD2A").s().p("A0TAPIAAgdMAonAAAIAAAdg");
	this.shape_1.setTransform(130,49.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,260,51);


(lib.bg2b = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg2_blur();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,375,250);


(lib.bg2a = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg2();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,375,250);


(lib.bg1_1 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.bg1();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib._bg = function() {
	this.initialize();

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu2AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib._clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#424242").s().p("A3bTiMAAAgnDMAu2AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{on:1,off:7});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6).call(this.frame_6).wait(6).call(this.frame_12).wait(1));

	// t
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah4AwQgQgPgWgRIgIgGIgDgFQgCgEAAgCIABgHIAEgGIAMgKIAUgQIAOgMIAGgIIAWAPIgQAOIggAZQgEAEAAABIABABIALAIQAOAKAZAVIAEAEIgSATQgEgGgJgIgAmAA9IAAgRIAAgKIgIAAIgPABIAAgUIAPABIAIAAIAAgJIgTABIAAgRIATABIAAgIIgJAAIgNAAIAAgTIALABQgCgGgIgNIASgHIALAUIgOAGIASAAQAFgJAFgSIAUAHIgJAUIABAAIAMgBIAAATIgOAAIgMAAIAAAIIAKAAIANgBIAAARIgNgBIgKAAIAAAJIANAAIAPgBIAAAUIgOgBIgOAAIAAAKIABARgAnHA9IAAgsIAlABIAIgBIAAAqIgRAAIAAgEIgJAAIAAAGgAm1AoIAKAAIAAgIIgKAAgAGHA4IgRgDIgDgXIATAEIAQACIAMgBIAJgDQADgCACgDQADgDAAgEQAAAAAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAIgDgEIgGgCIgIAAIgPABQgHACgGAEQgEACgEAEIgVgBIAAgCIAHg0IAXACIgGAeIAIgDIAJgDQAGgCAOgBQAJAAAHACQAHADAFAEQAFACADAFQADAGAAAHIgBAIIgDAHQgCAEgDADIgGAFIgHAEIgJADQgNADgIAAIgQgBgAECA3IgQgDQAAgJgDgNIATAEIAQACIAMgBIAJgDIAGgEQACgDAAgDQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAIgGgCIgIAAQgHAAgHABQgGACgGADQgGACgCAEIgWgHQADgFAFgMQAGgLACgJIgWgBIgBABIAAgWIALACIARABIADgUIAYACIgEARIAfgCQALgBAGgCIABAWIgJABIgtADIgIASIANgDIAQgBQAJAAAHABQAGACAGABQAFAEADAGQACAGAAAGIAAAIIgDAHIgFAFIgFAFIgIAEIgJADQgNADgIAAQgJAAgIgCgAgxAHIABgXIAEgcIACgLIAAAAIAYABIgEANIgFAZQgBAMAAAMIAKADQgDAJgBAJQgCAJAAANIABAFIgWABgAkQA2IgHgDIgGgEIgEgGIgDgHQgCgFgBgQIACg6IgBgKIAZABIgCAbIgBAjIABAOQAAAEACADQACADAEABQAEACAFAAIAKgBQAEgCAEgDQAEgDACgEIAFgJQADgHACgPIAMAJIALADIgIAXQgFAKgEAEIgIAHQgFAEgFACIgKADIgNABQgMgBgFgCgAAAA2QgEgBgEgDQgEgEgCgEQgCgFAAgFQAAgGACgFQADgFAFgDQADgDADgBQAFgCAHAAIAHABIAAgIIgBgLIgHAAIgZgBIAAgVQAGACARABIAJgBIAAgRIgBgHIAXAAIgBAXQAMgCAJgCIAAAUIgFABIgQADIABAZQAJAEAMAIIADACIgJAWIgGgGIgJgHIAAACQAAAEgCADQgCADgEADQgDACgFACQgGABgGAAQgHAAgFgCgAAFAbQgDACAAADQAAAAAAABQAAABAAAAQABABAAAAQABAAAAABQADABAEAAQAEAAACgCQADgBAAgEIAAgDIgIgBQgFAAgCABgAB+A1IgOgEIgIgEQgDgCgCgDQgDgDgBgEIgBgIIABgIIAEgIIAGgHIAIgGIAQAKQgFAEgDAEQgDAEAAAEQAAAAAAABQAAABAAAAQAAABABAAQAAAAAAABQACACADABIAJACIANAAIAYgBQAHgBALgEIACAZIgNACIggACIgTgBgAm+ANIgIABIAAgOIAIAAIAkAAIAAAOgAmigDIgkAAIAAgOIAsAAIAAAOgACCgSIAOgJIACgBIgLABIgdgCIgFAAIACgWIASACIAZABIAWgBIAOgBIABAUIgRAJIgUAOgAmjgWIgnABIAAgSIALABIAmgBIAAASIgKgBgAGRgfIgZgJIAKgTIALAFIAQAEQAOAEAMACIgHAVIgfgIgAnGgqIAAgPIAMAAIAUAAIAMAAIAAAPg");
	this.shape.setTransform(0,25.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13));

	// Layer 4
	this.instance = new lib.btnbg();
	this.instance.setTransform(0,25.5,1,1,0,0,0,130,25.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},6).to({alpha:0},6).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FC9E09").s().p("A0SAPIAAgdMAolAAAIAAAdg");
	this.shape_1.setTransform(0,49.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(13));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FCCD2A").s().p("A0SDvIAAneMAolAAAIAAHeg");
	this.shape_2.setTransform(0,24);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130,0,260,51);


(lib.bg2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_27 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(27).call(this.frame_27).wait(1));

	// Layer 2
	this.instance = new lib.bg2b();
	this.instance.setTransform(187.5,125,1,1,0,0,0,187.5,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).to({alpha:1},11).wait(1));

	// Layer 1
	this.instance_1 = new lib.bg2a();
	this.instance_1.setTransform(187.5,125,1,1,0,0,0,187.5,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(28));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,375,250);


// stage content:
(lib.HighLow_300x250_4b_JA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.enableMouseOver(20);
		
		this.loopNumber = 0 ;
		
		// CLICKTHROUGH
		this.clickTagBtn.addEventListener("click", function () {
			console.log("clickthrough");
			window.open(window.clickTAG);
		});
		
		// CTA
		this.clickTagBtn.addEventListener("mouseover", function () {
			exportRoot.bt.gotoAndPlay("on");
		});
		
		this.clickTagBtn.addEventListener("mouseout", function () {
			exportRoot.bt.gotoAndPlay("off");
		});
	}
	this.frame_243 = function() {
		if(this.loopNumber >= 1){
			console.log("STOP BANNER");
			this.stop();
		} else {
			this.loopNumber++;
			console.log("RESTART: " + this.loopNumber);
		}
	}
	this.frame_251 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(243).call(this.frame_243).wait(8).call(this.frame_251).wait(1));

	// Border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A3bTiMAAAgnDMAu2AAAMAAAAnDgA3RTYMAuiAAAMAAAgmvMguiAAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(252));

	// clickTagBtn
	this.clickTagBtn = new lib._clicktag();
	new cjs.ButtonHelper(this.clickTagBtn, 0, 1, 2, false, new lib._clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickTagBtn).wait(252));

	// btn
	this.bt = new lib.btn();
	this.bt.setTransform(150,261);
	this.bt.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.bt).wait(191).to({y:181},0).to({alpha:1},7).wait(46).to({y:331},7,cjs.Ease.get(0.9)).wait(1));

	// t5
	this.instance = new lib.t5b();
	this.instance.setTransform(150,123.4,1,1,0,0,0,0,28.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(158).to({_off:false},0).to({alpha:1},7).wait(79).to({y:-96.6},7,cjs.Ease.get(0.9)).wait(1));

	// t5
	this.instance_1 = new lib.t5();
	this.instance_1.setTransform(245,122.1,1,1,0,0,0,95,25.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(153).to({_off:false},0).to({alpha:1},7).wait(84).to({y:-97.9},7,cjs.Ease.get(0.9)).wait(1));

	// logo
	this.instance_2 = new lib.logo_mc();
	this.instance_2.setTransform(148.5,57.8,1,1,0,0,0,64.5,18.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(191).to({_off:false},0).to({alpha:1},7).wait(46).to({y:-162.2},7,cjs.Ease.get(0.9)).wait(1));

	// strip
	this.instance_3 = new lib.strip();
	this.instance_3.setTransform(-5,125,1,1,0,0,0,3,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).to({x:3},5,cjs.Ease.get(0.9)).wait(122).to({x:153},4,cjs.Ease.get(-1)).to({x:303},4,cjs.Ease.get(1)).to({_off:true},1).wait(104).to({_off:false},0).to({x:-3},7,cjs.Ease.get(0.9)).wait(1));

	// t3
	this.instance_4 = new lib.t3();
	this.instance_4.setTransform(-149.2,125.8,1,1,0,0,0,78.8,94.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(85).to({_off:false},0).to({x:120.8},7,cjs.Ease.get(1)).wait(39).to({x:270.8},4,cjs.Ease.get(-1)).to({x:420.8},4,cjs.Ease.get(1)).to({_off:true},1).wait(112));

	// t2
	this.instance_5 = new lib.t2();
	this.instance_5.setTransform(-120.5,124.5,1,1,0,0,0,87.5,77.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(39).to({_off:false},0).to({x:129.5},7,cjs.Ease.get(1)).wait(37).to({x:429.5},7,cjs.Ease.get(-1)).to({_off:true},1).wait(161));

	// t1
	this.instance_6 = new lib.t1();
	this.instance_6.setTransform(-145.6,124.5,1,1,0,0,0,92.4,77.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:134.4},7,cjs.Ease.get(1)).wait(30).to({x:484.4},7,cjs.Ease.get(-1)).to({_off:true},1).wait(207));

	// bg1
	this.instance_7 = new lib.bg1_1();
	this.instance_7.setTransform(150.5,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(131).to({x:300.5},4,cjs.Ease.get(-1)).to({x:450.5},4,cjs.Ease.get(1)).to({_off:true},1).wait(104).to({_off:false,x:455.5},0).to({x:150},7,cjs.Ease.get(0.9)).wait(1));

	// Layer 26
	this.instance_8 = new lib.bg2_1();
	this.instance_8.setTransform(-112.5,125,1,1,0,0,0,187.5,125);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(131).to({_off:false},0).to({x:37.5},4,cjs.Ease.get(-1)).to({x:187.5},4,cjs.Ease.get(1)).to({x:112.5},105).to({x:-187.5},7,cjs.Ease.get(0.9)).wait(1));

	// bg
	this.instance_9 = new lib._bg();
	this.instance_9.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(252));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88,125,538.5,312);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;